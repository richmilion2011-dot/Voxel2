Shader "VoxelWorld/VoxelUnlit"
{
    Properties { _MainTex ("Atlas", 2D) = "white" {} }
    SubShader
    {
        Tags { "RenderType"="TransparentCutout" "Queue"="AlphaTest" "RenderPipeline"="UniversalPipeline" }
        Pass
        {
            Name "ForwardLit"
            Tags { "LightMode"="UniversalForward" }
            Cull Back
            HLSLPROGRAM
            #pragma vertex vert
            #pragma fragment frag
            #include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Core.hlsl"

            TEXTURE2D(_MainTex); SAMPLER(sampler_MainTex);
            float _DayLight;

            struct A { float4 pos : POSITION; float3 n : NORMAL; float2 uv : TEXCOORD0; float2 t : TEXCOORD1; };
            struct V { float4 pos : SV_POSITION; float2 uv : TEXCOORD0; float tile : TEXCOORD1; float shade : TEXCOORD2; float lit : TEXCOORD3; };

            V vert(A i)
            {
                V o;
                o.pos = TransformObjectToHClip(i.pos.xyz);
                o.uv = i.uv; o.tile = i.t.x; o.lit = i.t.y;
                float3 n = TransformObjectToWorldNormal(i.n);
                o.shade = n.y > 0.5 ? 1.0 : (n.y < -0.5 ? 0.5 : (abs(n.x) > 0.5 ? 0.8 : 0.65));
                return o;
            }

            half4 frag(V i) : SV_Target
            {
                float2 f = clamp(frac(i.uv), 0.001, 0.999);
                float t = floor(i.tile + 0.5);
                if (t == 5.0 || t == 124.0) f = clamp(frac(f + float2(_Time.y * 0.12, sin(_Time.y * 0.7) * 0.15 + _Time.y * 0.05)), 0.001, 0.999); // анимация воды
                float col = fmod(t, 32.0), row = floor(t / 32.0);
                float2 uv = float2((col + f.x) / 32.0, 1.0 - (row + 1.0 - f.y) / 32.0);
                half4 c = SAMPLE_TEXTURE2D_LOD(_MainTex, sampler_MainTex, uv, 0);
                clip(c.a - 0.5);
                float em = (t == 122.0 || t == 124.0 || t == 261.0 || t == 287.0 || t == 291.0 || t == 292.0 || t == 327.0 || t == 328.0) ? 1.0 : 0.0;
                c.rgb *= lerp(i.shade * max(lerp(0.18, 1.0, saturate(_DayLight)), i.lit), 1.0, em);
                return c;
            }
            ENDHLSL
        }
    }
}
