using System.Collections.Generic;
using System.IO;
using UnityEngine;
using VoxelWorld.Core;
using VoxelWorld.Save;
using VoxelWorld.World;

namespace VoxelWorld.UI
{
    /// Главное меню: анимированный воксельный пейзаж на фоне, список миров, создание/удаление, настройки, титры.
    public class MainMenu : MonoBehaviour
    {
        enum Page { Main, Worlds, Create, Settings, Credits }
        GameBootstrap boot; Camera cam; Transform rig; GameObject bg;
        Page page; float yaw;
        readonly List<string> folders = new List<string>(), labels = new List<string>();
        int selected = -1; bool confirmDelete; Vector2 scroll;
        string newName = "New World", newSeed = ""; bool newCreative; int newDiff = 2;

        public void Init(GameBootstrap b, Camera c, Material mat)
        {
            boot = b; cam = c;
            rig = new GameObject("MenuRig").transform; rig.position = new Vector3(0, 85, 0);
            cam.transform.SetParent(rig, false); cam.transform.localPosition = Vector3.zero; cam.transform.localRotation = Quaternion.Euler(25, 0, 0);
            bg = new GameObject("MenuWorld");
            var cm = bg.AddComponent<ChunkManager>();
            cm.player = rig; cm.chunkMaterial = mat; cm.seed = 777; cm.renderDistance = 2;
            RefreshWorlds();
        }

        public void Shutdown() { cam.transform.SetParent(null, true); Destroy(bg); Destroy(rig.gameObject); }

        void Update()
        {
            yaw += 5f * Time.deltaTime;
            rig.rotation = Quaternion.Euler(0, yaw, 0);
            rig.position += Vector3.right * 6f * Time.deltaTime;
        }

        void RefreshWorlds()
        {
            folders.Clear(); labels.Clear(); selected = -1; confirmDelete = false;
            foreach (var f in WorldSave.ListNames())
            {
                var m = new WorldSave(f).LoadMeta();
                if (m == null) continue;
                folders.Add(f);
                labels.Add(f + "     " + (m.creative ? "Creative" : "Survival") + "     " + (m.lastPlayed ?? "").Replace('T', ' '));
            }
        }

        void CreateWorld()
        {
            string n = WorldSave.Sanitize(newName); if (string.IsNullOrEmpty(n)) n = "World";
            string name = n; int i = 2; while (WorldSave.Exists(name)) name = n + " (" + (i++) + ")";
            int seed;
            if (string.IsNullOrWhiteSpace(newSeed)) seed = new System.Random().Next();
            else if (!int.TryParse(newSeed.Trim(), out seed)) { unchecked { seed = 17; foreach (char ch in newSeed) seed = seed * 31 + ch; } }
            seed &= 0x7FFFFFFF;
            new WorldSave(name).SaveMeta(new SaveData
            {
                name = name, seed = seed, dayT = 0.2f, pos = new Vector3(8, 110, 8), health = 20, hunger = 20, saturation = 5,
                items = new SlotData[0], furnaces = new FurnaceData[0], creative = newCreative, difficulty = newDiff
            });
            GameSession.WorldName = name; boot.BeginGame();
        }

        void OnGUI()
        {
            MenuUI.Begin();
            float cx = MenuUI.W / 2f;
            switch (page)
            {
                case Page.Main:
                    GUI.color = new Color(0, 0, 0, 0.6f); GUI.Label(new Rect(cx - 298, 52, 600, 100), "VOXEL WORLD", MenuUI.Title);
                    GUI.color = Color.white; GUI.Label(new Rect(cx - 300, 50, 600, 100), "VOXEL WORLD", MenuUI.Title);
                    if (MenuUI.B(cx - 180, 190, 360, 56, "Singleplayer")) { RefreshWorlds(); page = Page.Worlds; }
                    if (MenuUI.B(cx - 180, 260, 360, 56, "Settings")) page = Page.Settings;
                    if (MenuUI.B(cx - 180, 330, 360, 56, "Credits")) page = Page.Credits;
                    if (Application.platform != RuntimePlatform.IPhonePlayer && MenuUI.B(cx - 180, 400, 360, 56, "Exit")) Application.Quit();
                    break;

                case Page.Worlds:
                    GUI.Label(new Rect(cx - 300, 20, 600, 40), "Select World", MenuUI.Lbl);
                    var view = new Rect(cx - 300, 60, 600, 280);
                    GUI.Box(view, "");
                    scroll = GUI.BeginScrollView(view, scroll, new Rect(0, 0, 580, Mathf.Max(280, folders.Count * 60)));
                    for (int i = 0; i < folders.Count; i++)
                        if (MenuUI.Toggle(4, i * 60 + 4, 570, 54, labels[i], i == selected)) { selected = i; confirmDelete = false; }
                    GUI.EndScrollView();
                    if (folders.Count == 0) GUI.Label(new Rect(cx - 250, 180, 500, 40), "No worlds yet — create one!", MenuUI.Lbl);
                    if (selected >= 0 && MenuUI.B(cx - 300, 360, 190, 54, "Play")) { GameSession.WorldName = folders[selected]; boot.BeginGame(); }
                    if (MenuUI.B(cx - 95, 360, 190, 54, "New World")) { newName = "New World"; newSeed = ""; page = Page.Create; }
                    if (selected >= 0 && MenuUI.B(cx + 110, 360, 190, 54, confirmDelete ? "Confirm?" : "Delete"))
                    {
                        if (confirmDelete) { WorldSave.Delete(folders[selected]); RefreshWorlds(); } else confirmDelete = true;
                    }
                    if (MenuUI.B(cx - 100, 450, 200, 50, "Back")) page = Page.Main;
                    break;

                case Page.Create:
                    GUI.Label(new Rect(cx - 300, 20, 600, 40), "Create New World", MenuUI.Lbl);
                    GUI.Label(new Rect(cx - 300, 70, 600, 30), "World name", MenuUI.Lbl);
                    newName = GUI.TextField(new Rect(cx - 300, 100, 600, 44), newName, 24, MenuUI.Field);
                    GUI.Label(new Rect(cx - 300, 150, 600, 30), "Seed (empty = random)", MenuUI.Lbl);
                    newSeed = GUI.TextField(new Rect(cx - 300, 180, 600, 44), newSeed, 24, MenuUI.Field);
                    if (MenuUI.Toggle(cx - 300, 240, 295, 50, "Survival", !newCreative)) newCreative = false;
                    if (MenuUI.Toggle(cx + 5, 240, 295, 50, "Creative", newCreative)) newCreative = true;
                    string[] diffs = { "Peaceful", "Easy", "Normal", "Hard" };
                    for (int i = 0; i < 4; i++)
                        if (MenuUI.Toggle(cx - 300 + i * 152, 305, 146, 50, diffs[i], newDiff == i)) newDiff = i;
                    if (MenuUI.B(cx - 300, 400, 295, 56, "Create")) CreateWorld();
                    if (MenuUI.B(cx + 5, 400, 295, 56, "Cancel")) page = Page.Worlds;
                    break;

                case Page.Settings:
                    GUI.Label(new Rect(cx - 300, 20, 600, 40), "Settings", MenuUI.Lbl);
                    MenuUI.Settings(cx - 300, 70, 600);
                    if (MenuUI.B(cx - 100, 450, 200, 50, "Back")) { GameSettings.Save(); page = Page.Main; }
                    break;

                case Page.Credits:
                    GUI.Box(new Rect(cx - 320, 60, 640, 330), "");
                    GUI.Label(new Rect(cx - 300, 80, 600, 300),
                        "VOXEL WORLD  v0.9\n\nOriginal code, textures and game design.\nWritten with Claude (Anthropic).\n\nAll block, item and mob art is generated\nby original scripts — no third-party assets.", MenuUI.Lbl);
                    if (MenuUI.B(cx - 100, 450, 200, 50, "Back")) page = Page.Main;
                    break;
            }
            MenuUI.End();
        }
    }
}
