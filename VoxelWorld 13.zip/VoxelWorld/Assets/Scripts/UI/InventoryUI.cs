using UnityEngine;
using VoxelWorld.Items;

namespace VoxelWorld.UI
{
    /// Хотбар всегда на экране. INV — инвентарь + крафт 2x2; тап (PLACE) по верстаку — крафт 3x3, по печи — печь.
    public class InventoryUI : MonoBehaviour
    {
        enum Mode { Craft2, Craft3, Furnace, Chest, Trade, Creative }
        public Inventory inv; public int selected; public bool open;
        Texture2D atlas; ItemStack held; GUIStyle cnt, lbl;
        readonly ItemStack[] craft = new ItemStack[9]; Mode mode; FurnaceState furnace; ItemStack[] chest; Trade[] trades; string tradeName;
        public bool creativeUI; public System.Action<ItemStack> onDrop; Vector2 cscroll; int ctab;
        readonly System.Collections.Generic.Dictionary<string, System.Collections.Generic.List<ushort>> clists = new System.Collections.Generic.Dictionary<string, System.Collections.Generic.List<ushort>>();

        void Start() { atlas = Resources.Load<Texture2D>("VoxelAtlas"); }

        public void Toggle() { if (open) Close(); else Open(false); }
        public void Open(bool tableMode) { open = true; mode = tableMode ? Mode.Craft3 : (creativeUI ? Mode.Creative : Mode.Craft2); }
        public void OpenFurnace(FurnaceState f) { open = true; mode = Mode.Furnace; furnace = f; }
        public void OpenTrade(Trade[] t, string name) { open = true; mode = Mode.Trade; trades = t; tradeName = name; }
        public void OpenChest(ItemStack[] c) { open = true; mode = Mode.Chest; chest = c; }
        void Close()
        {
            open = false;
            for (int i = 0; i < 9; i++) if (!craft[i].Empty) { inv.Add(craft[i].id, craft[i].count, craft[i].dur); craft[i] = default; }
            if (!held.Empty) { inv.Add(held.id, held.count, held.dur); held = default; }
        }

        public static Rect HotbarSlot(int i)
        {
            float s = Screen.height * 0.1f, x0 = (Screen.width - 9 * s) / 2f;
            return new Rect(x0 + i * s, Screen.height - s - 4, s, s);
        }

        float S => Mathf.Min(Screen.width * 0.064f, Screen.height * 0.125f);
        float X0 => (Screen.width - 13.8f * S) / 2f;
        float Y0 => (Screen.height - 4.4f * S) / 2f;
        Rect GridSlot(int i)
        {
            float s = S;
            if (i < 9) return new Rect(X0 + 1.2f * s + i * s, Y0 + 3.4f * s, s, s);
            int j = i - 9; return new Rect(X0 + 1.2f * s + (j % 9) * s, Y0 + (j / 9) * s, s, s);
        }

        void Icon(Rect r, ushort id)
        {
            if (atlas == null) return;
            int t = ItemDatabase.IconTile(id); float u = 1f / 32f, pad = r.width * 0.15f;
            GUI.DrawTextureWithTexCoords(new Rect(r.x + pad, r.y + pad, r.width - 2 * pad, r.height - 2 * pad), atlas,
                new Rect((t % 32) * u, 1f - ((t / 32) + 1) * u, u, u));
        }

        void Slot(Rect r, ItemStack st)
        {
            if (st.Empty) return;
            Icon(r, st.id);
            var def = ItemDatabase.Get(st.id);
            if (def != null && def.Durability > 0 && st.dur > 0 && st.dur < def.Durability)
                Bar(new Rect(r.x + r.width * 0.12f, r.yMax - r.height * 0.14f, r.width * 0.76f, r.height * 0.07f),
                    (float)st.dur / def.Durability, Color.green);
            if (st.count > 1) { cnt.fontSize = Mathf.RoundToInt(r.width * 0.28f); GUI.Label(r, st.count.ToString(), cnt); }
        }

        static void Bar(Rect r, float f, Color c)
        {
            GUI.color = new Color(0, 0, 0, 0.6f); GUI.DrawTexture(r, Texture2D.whiteTexture);
            GUI.color = c; GUI.DrawTexture(new Rect(r.x, r.y, r.width * Mathf.Clamp01(f), r.height), Texture2D.whiteTexture);
            GUI.color = Color.white;
        }

        void TakeResult(Recipe rc, int gw)
        {
            int max = ItemDatabase.MaxStack(rc.result);
            if (!held.Empty && (held.id != rc.result || held.count + rc.count > max)) return;
            for (int i = 0; i < gw * gw; i++) if (!craft[i].Empty && --craft[i].count <= 0) craft[i] = default;
            if (held.Empty) held = new ItemStack { id = rc.result, count = rc.count, dur = ItemDatabase.Get(rc.result)?.Durability ?? 0 };
            else held.count += rc.count;
        }

        void TakeOutput()
        {
            var o = furnace.slots[2];
            if (o.Empty) return;
            if (held.Empty) { held = o; furnace.slots[2] = default; }
            else if (held.id == o.id)
            {
                int m = Mathf.Min(o.count, ItemDatabase.MaxStack(o.id) - held.count);
                held.count += m; furnace.slots[2].count -= m;
                if (furnace.slots[2].count <= 0) furnace.slots[2] = default;
            }
        }

        static readonly string[] Tabs = { "Building", "Natural", "Functional", "Tools", "Weapons", "Armor", "Food", "Materials" };

        System.Collections.Generic.List<ushort> CList(string cat)
        {
            if (!clists.TryGetValue(cat, out var l))
            {
                l = new System.Collections.Generic.List<ushort>();
                foreach (var id in VoxelWorld.Blocks.BlockDatabase.All()) if (VoxelWorld.Blocks.BlockDatabase.Get(id).Cat == cat) l.Add(id);
                foreach (var id in ItemDatabase.AllIds()) if (ItemDatabase.Category(id) == cat) l.Add(id);
                clists[cat] = l;
            }
            return l;
        }

        void GiveCreative(ushort id) { inv.Add(id, ItemDatabase.MaxStack(id) > 1 ? 64 : 1, ItemDatabase.Get(id)?.Durability ?? 0); }

        void ClickArmor(int a)
        {
            if (held.Empty) { held = inv.armor[a]; inv.armor[a] = default; }
            else if ((ItemDatabase.Get(held.id)?.ArmorSlot ?? -1) == a) { var t = inv.armor[a]; inv.armor[a] = held; held = t; }
        }

        void DropAction()
        {
            if (!held.Empty) { onDrop?.Invoke(held); held = default; return; }
            var st = inv.slots[selected];
            if (!st.Empty) { onDrop?.Invoke(new ItemStack { id = st.id, count = 1, dur = st.dur }); inv.TakeOne(selected); }
        }

        void DrawCreative()
        {
            float s = Screen.height * 0.085f, x0 = (Screen.width - 9 * s) / 2f, y0 = Screen.height * 0.05f;
            GUI.Box(new Rect(x0 - 10, y0 - 8, 9 * s + 20, 7.9f * s), "");
            var small = new GUIStyle(GUI.skin.button) { fontSize = Mathf.RoundToInt(s * 0.26f) };
            for (int t = 0; t < Tabs.Length; t++)
            {
                var tr = new Rect(x0 + (t % 4) * 2.25f * s, y0 + (t / 4) * 0.58f * s, 2.2f * s, 0.52f * s);
                GUI.color = t == ctab ? Color.yellow : Color.white;
                if (GUI.Button(tr, Tabs[t], small)) { ctab = t; cscroll = Vector2.zero; }
                GUI.color = Color.white;
            }
            var list = CList(Tabs[ctab]);
            var view = new Rect(x0, y0 + 1.25f * s, 9 * s, 4.6f * s); int rows = (list.Count + 8) / 9;
            cscroll = GUI.BeginScrollView(view, cscroll, new Rect(0, 0, 9 * s - 18, Mathf.Max(4.6f * s, rows * s)));
            for (int i = 0; i < list.Count; i++)
            {
                var r = new Rect((i % 9) * s, (i / 9) * s, s, s);
                if (GUI.Button(r, GUIContent.none)) GiveCreative(list[i]);
                Icon(r, list[i]);
            }
            GUI.EndScrollView();
            float hy = y0 + 6.0f * s;
            for (int j = 0; j < 9; j++)
            {
                var r = new Rect(x0 + j * s, hy, s, s);
                GUI.color = j == selected ? Color.yellow : Color.white;
                if (GUI.Button(r, GUIContent.none)) selected = j;
                GUI.color = Color.white; Slot(r, inv.slots[j]);
            }
            if (GUI.Button(new Rect(x0, hy + 1.05f * s, 2 * s, 0.6f * s), "CLEAR SLOT")) inv.slots[selected] = default;
            if (GUI.Button(new Rect(x0 + 7f * s, hy + 1.05f * s, 2 * s, 0.6f * s), "CLOSE")) Close();
        }

        void DrawTrade()
        {
            float s = Screen.height * 0.1f, x0 = (Screen.width - 8 * s) / 2f, y0 = Screen.height * 0.22f;
            GUI.Box(new Rect(x0 - 10, y0 - s * 1.1f, 8 * s + 20, s * 1.3f * trades.Length + s * 1.5f), "");
            lbl.fontSize = Mathf.RoundToInt(s * 0.32f);
            GUI.Label(new Rect(x0, y0 - s * 1.0f, 6 * s, s * 0.7f), tradeName + "   (Emeralds: " + inv.Count((ushort)ItemId.Emerald) + ")", lbl);
            if (GUI.Button(new Rect(x0 + 6.5f * s, y0 - s, 1.5f * s, 0.7f * s), "CLOSE")) { Close(); return; }
            lbl.fontSize = Mathf.RoundToInt(s * 0.26f);
            for (int i = 0; i < trades.Length; i++)
            {
                var t = trades[i]; var r = new Rect(x0, y0 + i * 1.3f * s, 8 * s, 1.15f * s);
                bool ok = inv.Count(t.cost) >= t.costN;
                GUI.color = ok ? Color.white : new Color(1, 1, 1, 0.4f);
                if (GUI.Button(r, GUIContent.none) && ok)
                {
                    inv.Remove(t.cost, t.costN);
                    inv.Add(t.res, t.resN, ItemDatabase.Get(t.res)?.Durability ?? 0);
                }
                Slot(new Rect(r.x + 0.1f * s, r.y + 0.075f * s, s, s), new ItemStack { id = t.cost, count = t.costN });
                GUI.Label(new Rect(r.x + 1.2f * s, r.y, 2.2f * s, r.height), ItemDatabase.Name(t.cost), lbl);
                GUI.Label(new Rect(r.x + 3.5f * s, r.y, 0.9f * s, r.height), "=>", lbl);
                Slot(new Rect(r.x + 4.4f * s, r.y + 0.075f * s, s, s), new ItemStack { id = t.res, count = t.resN, dur = ItemDatabase.Get(t.res)?.Durability ?? 0 });
                GUI.Label(new Rect(r.x + 5.5f * s, r.y, 2.4f * s, r.height), ItemDatabase.Name(t.res), lbl);
                GUI.color = Color.white;
            }
        }

        void DrawChest()
        {
            float s = Screen.height * 0.095f, x0 = (Screen.width - 9 * s) / 2f, y0 = (Screen.height - 7.5f * s) / 2f + 0.4f * s;
            GUI.Box(new Rect(x0 - 10, y0 - s, 9 * s + 20, 8.5f * s), "");
            lbl.fontSize = Mathf.RoundToInt(s * 0.3f);
            GUI.Label(new Rect(x0, y0 - s * 0.95f, 6 * s, s * 0.7f), held.Empty ? "Chest" : "Holding: " + ItemDatabase.Name(held.id) + " x" + held.count, lbl);
            if (GUI.Button(new Rect(x0 + 7.5f * s, y0 - s * 0.95f, 1.5f * s, s * 0.7f), "CLOSE")) { Close(); return; }
            for (int i = 0; i < 27; i++)
            {
                var r = new Rect(x0 + (i % 9) * s, y0 + (i / 9) * s, s, s);
                if (GUI.Button(r, GUIContent.none)) Inventory.ClickSlot(chest, i, ref held);
                Slot(r, chest[i]);
            }
            for (int j = 0; j < Inventory.Size; j++)
            {
                var r = j < 9 ? new Rect(x0 + j * s, y0 + 6.5f * s, s, s) : new Rect(x0 + ((j - 9) % 9) * s, y0 + 3.3f * s + ((j - 9) / 9) * s, s, s);
                GUI.color = j == selected ? Color.yellow : Color.white;
                if (GUI.Button(r, GUIContent.none)) inv.Click(j, ref held);
                GUI.color = Color.white; Slot(r, inv.slots[j]);
            }
        }

        void OnGUI()
        {
            if (inv == null) return;
            if (cnt == null)
            {
                cnt = new GUIStyle(GUI.skin.label) { alignment = TextAnchor.LowerRight, fontStyle = FontStyle.Bold };
                cnt.normal.textColor = Color.white;
                lbl = new GUIStyle(GUI.skin.label) { alignment = TextAnchor.MiddleLeft, fontStyle = FontStyle.Bold };
                lbl.normal.textColor = Color.white;
            }
            if (!open)
            {
                for (int i = 0; i < 9; i++)
                {
                    GUI.color = i == selected ? Color.yellow : Color.white;
                    GUI.Box(HotbarSlot(i), ""); GUI.color = Color.white;
                    Slot(HotbarSlot(i), inv.slots[i]);
                }
                return;
            }
            if (mode == Mode.Creative) { DrawCreative(); return; }
            if (mode == Mode.Trade) { DrawTrade(); return; }
            if (mode == Mode.Chest) { DrawChest(); return; }
            float s = S, x0 = X0, y0 = Y0;
            GUI.Box(new Rect(x0 - 10, y0 - s * 0.95f, 13.8f * s + 20, 5.5f * s), "");
            lbl.fontSize = Mathf.RoundToInt(s * 0.3f);
            string h = held.Empty ? "Inventory" : "Holding: " + ItemDatabase.Name(held.id) + " x" + held.count;
            GUI.Label(new Rect(x0, y0 - s * 0.9f, 7 * s, s * 0.7f), h, lbl);
            if (GUI.Button(new Rect(x0 + 13.8f * s - s * 1.5f, y0 - s * 0.9f, s * 1.5f, s * 0.7f), "CLOSE")) { Close(); return; }
            if (GUI.Button(new Rect(x0 + 8.7f * s, y0 - s * 0.9f, s * 1.6f, s * 0.7f), "DROP")) DropAction();
            if (GUI.Button(new Rect(x0 + 10.4f * s, y0 - s * 0.9f, s * 1.6f, s * 0.7f), "SORT")) inv.Sort();

            for (int i = 0; i < Inventory.Size; i++)
            {
                var r = GridSlot(i);
                GUI.color = i == selected ? Color.yellow : Color.white;
                if (GUI.Button(r, GUIContent.none)) inv.Click(i, ref held);
                GUI.color = Color.white; Slot(r, inv.slots[i]);
            }

            lbl.fontSize = Mathf.RoundToInt(s * 0.22f);
            string[] an = { "Head", "Chest", "Legs", "Feet" };
            for (int a = 0; a < 4; a++)
            {
                var ar = new Rect(x0, y0 + a * s, s, s);
                if (GUI.Button(ar, GUIContent.none)) ClickArmor(a);
                if (inv.armor[a].Empty) { GUI.color = new Color(1, 1, 1, 0.45f); GUI.Label(ar, an[a], lbl); GUI.color = Color.white; }
                Slot(ar, inv.armor[a]);
            }
            var ro = new Rect(x0, y0 + 3.4f * s, s, s);
            if (GUI.Button(ro, GUIContent.none)) Inventory.ClickSlot(inv.off, 0, ref held);
            if (inv.off[0].Empty) { GUI.color = new Color(1, 1, 1, 0.45f); GUI.Label(ro, "Off", lbl); GUI.color = Color.white; }
            Slot(ro, inv.off[0]);
            lbl.fontSize = Mathf.RoundToInt(s * 0.3f);

            float cx0 = x0 + 10.8f * s;
            if (mode == Mode.Furnace)
            {
                var fs = furnace.slots;
                GUI.Label(new Rect(cx0, y0 - s * 0.45f, 3 * s, s * 0.4f), "Furnace", lbl);
                var rIn = new Rect(cx0, y0, s, s); var rFuel = new Rect(cx0, y0 + 1.5f * s, s, s); var rOut = new Rect(cx0 + 1.7f * s, y0 + 0.75f * s, s, s);
                Bar(new Rect(cx0 + 0.1f * s, y0 + 1.12f * s, 0.8f * s, 0.25f * s), furnace.burnMax > 0 ? furnace.burnLeft / furnace.burnMax : 0, new Color(1f, 0.55f, 0.1f));
                Bar(new Rect(cx0 + 1.05f * s, y0 + 1.0f * s, 0.55f * s, 0.25f * s), furnace.cook / FurnaceState.CookTime, Color.white);
                if (GUI.Button(rIn, GUIContent.none)) { if (held.Empty || SmeltingData.TryResult(held.id, out _)) Inventory.ClickSlot(fs, 0, ref held); }
                if (GUI.Button(rFuel, GUIContent.none)) { if (held.Empty || SmeltingData.FuelTime(held.id) > 0) Inventory.ClickSlot(fs, 1, ref held); }
                if (GUI.Button(rOut, GUIContent.none)) TakeOutput();
                Slot(rIn, fs[0]); Slot(rFuel, fs[1]); Slot(rOut, fs[2]);
                return;
            }

            int gw = mode == Mode.Craft3 ? 3 : 2;
            float cy0 = y0 + (gw == 3 ? 0f : 0.5f * s);
            GUI.Label(new Rect(cx0, y0 - s * 0.45f, 3 * s, s * 0.4f), gw == 3 ? "Crafting 3x3" : "Crafting 2x2", lbl);
            for (int cy = 0; cy < gw; cy++)
                for (int cx = 0; cx < gw; cx++)
                {
                    int idx = cy * gw + cx; var r = new Rect(cx0 + cx * s, cy0 + cy * s, s, s);
                    if (GUI.Button(r, GUIContent.none)) Inventory.ClickSlot(craft, idx, ref held);
                    Slot(r, craft[idx]);
                }
            var rc = CraftingSystem.Find(craft, gw);
            var rr = new Rect(cx0 + s, y0 + 3.4f * s, s, s);
            if (GUI.Button(rr, GUIContent.none) && rc != null) TakeResult(rc, gw);
            if (rc != null) Slot(rr, new ItemStack { id = rc.result, count = rc.count, dur = ItemDatabase.Get(rc.result)?.Durability ?? 0 });
        }
    }
}
