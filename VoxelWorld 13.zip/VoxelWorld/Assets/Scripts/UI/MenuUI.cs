using UnityEngine;
using VoxelWorld.Core;

namespace VoxelWorld.UI
{
    /// Общие стили и экран настроек для главного меню и паузы. Рисуем в "виртуальных" координатах высотой 540.
    public static class MenuUI
    {
        public static GUIStyle Btn, Lbl, Title, Field;
        public static float W; public const float H = 540f;

        public static void Begin()
        {
            float k = Screen.height / H;
            GUI.matrix = Matrix4x4.Scale(new Vector3(k, k, 1)); W = Screen.width / k;
            if (Btn != null) return;
            Btn = new GUIStyle(GUI.skin.button) { fontSize = 22 };
            Lbl = new GUIStyle(GUI.skin.label) { fontSize = 20 }; Lbl.normal.textColor = Color.white;
            Title = new GUIStyle(GUI.skin.label) { fontSize = 64, fontStyle = FontStyle.Bold, alignment = TextAnchor.MiddleCenter };
            Title.normal.textColor = Color.white;
            Field = new GUIStyle(GUI.skin.textField) { fontSize = 22 };
        }
        public static void End() { GUI.matrix = Matrix4x4.identity; }

        public static bool B(float x, float y, float w, float h, string t) => GUI.Button(new Rect(x, y, w, h), t, Btn);

        public static bool Toggle(float x, float y, float w, float h, string t, bool on)
        {
            var c = GUI.color; GUI.color = on ? Color.yellow : Color.white;
            bool r = GUI.Button(new Rect(x, y, w, h), t, Btn); GUI.color = c; return r;
        }

        public static void Settings(float x, float y, float w)
        {
            float cw = w / 2f - 12f, rx = x + w / 2f + 12f;
            GUI.Label(new Rect(x, y, cw, 28), "Video / Controls", Lbl); GUI.Label(new Rect(rx, y, cw, 28), "Audio", Lbl);
            GUI.Label(new Rect(x, y + 30, cw, 28), "Render distance: " + GameSettings.RenderDistance, Lbl);
            int rd = Mathf.RoundToInt(GUI.HorizontalSlider(new Rect(x, y + 58, cw, 24), GameSettings.RenderDistance, 2, 8));
            GUI.Label(new Rect(x, y + 92, cw, 28), "Field of view: " + Mathf.RoundToInt(GameSettings.Fov), Lbl);
            float fov = GUI.HorizontalSlider(new Rect(x, y + 120, cw, 24), GameSettings.Fov, 60f, 100f);
            GUI.Label(new Rect(x, y + 154, cw, 28), "Camera sensitivity: " + GameSettings.LookSens.ToString("0.00"), Lbl);
            float look = GUI.HorizontalSlider(new Rect(x, y + 182, cw, 24), GameSettings.LookSens, 0.05f, 0.4f);
            GUI.Label(new Rect(rx, y + 30, cw, 28), "Master volume: " + Mathf.RoundToInt(GameSettings.MasterVol * 100) + "%", Lbl);
            GameSettings.MasterVol = GUI.HorizontalSlider(new Rect(rx, y + 58, cw, 24), GameSettings.MasterVol, 0f, 1f);
            GUI.Label(new Rect(rx, y + 92, cw, 28), "Music: " + Mathf.RoundToInt(GameSettings.MusicVol * 100) + "%", Lbl);
            GameSettings.MusicVol = GUI.HorizontalSlider(new Rect(rx, y + 120, cw, 24), GameSettings.MusicVol, 0f, 1f);
            GUI.Label(new Rect(rx, y + 154, cw, 28), "Sound effects: " + Mathf.RoundToInt(GameSettings.SfxVol * 100) + "%", Lbl);
            GameSettings.SfxVol = GUI.HorizontalSlider(new Rect(rx, y + 182, cw, 24), GameSettings.SfxVol, 0f, 1f);
            GUI.Label(new Rect(x, y + 222, w, 28), "FPS limit", Lbl);
            int[] fps = { 30, 60, 120 };
            for (int i = 0; i < 3; i++)
                if (Toggle(x + i * (w / 3f), y + 250, w / 3f - 8, 38, fps[i].ToString(), GameSettings.FpsLimit == fps[i])) GameSettings.FpsLimit = fps[i];
            if (Toggle(x, y + 296, 240, 38, "Show FPS: " + (GameSettings.ShowFps ? "ON" : "OFF"), GameSettings.ShowFps)) GameSettings.ShowFps = !GameSettings.ShowFps;
            GameSettings.RenderDistance = rd; GameSettings.Fov = fov; GameSettings.LookSens = look;
            GameSettings.Apply();
        }
    }
}
