using UnityEngine;
using VoxelWorld.Core;
using VoxelWorld.Save;

namespace VoxelWorld.UI
{
    /// Кнопка паузы (II), клавиша Esc / Android «Назад». Время останавливается (timeScale = 0).
    public class PauseMenu : MonoBehaviour
    {
        public static Rect ButtonRect => new Rect(10, 10, Screen.height * 0.08f, Screen.height * 0.08f);
        GameBootstrap boot; WorldSaver saver; InventoryUI ui; bool settings;

        public void Init(GameBootstrap b, WorldSaver s, InventoryUI u) { boot = b; saver = s; ui = u; }

        void Update() { if (Input.GetKeyDown(KeyCode.Escape)) SetPaused(!GameSession.Paused); }

        void SetPaused(bool p)
        {
            if (p && ui.open) return;
            GameSession.Paused = p; Time.timeScale = p ? 0f : 1f; settings = false;
            if (!p) GameSettings.Save();
        }

        void OnGUI()
        {
            GUI.depth = -200;
            if (!GameSession.Paused)
            {
                if (!ui.open && GUI.Button(ButtonRect, "II")) SetPaused(true);
                return;
            }
            GUI.color = new Color(0, 0, 0, 0.7f); GUI.DrawTexture(new Rect(0, 0, Screen.width, Screen.height), Texture2D.whiteTexture); GUI.color = Color.white;
            MenuUI.Begin();
            float cx = MenuUI.W / 2f;
            GUI.Label(new Rect(cx - 200, 20, 400, 80), "Paused", MenuUI.Title);
            if (settings)
            {
                MenuUI.Settings(cx - 300, 100, 600);
                if (MenuUI.B(cx - 100, 470, 200, 50, "Back")) { settings = false; GameSettings.Save(); }
            }
            else
            {
                if (MenuUI.B(cx - 170, 130, 340, 54, "Resume")) SetPaused(false);
                if (MenuUI.B(cx - 170, 200, 340, 54, "Settings")) settings = true;
                if (MenuUI.B(cx - 170, 270, 340, 54, "Save Game")) saver.Save();
                if (MenuUI.B(cx - 170, 340, 340, 54, "Save and Quit to Menu")) { SetPaused(false); boot.QuitToMenu(); }
            }
            MenuUI.End();
        }
    }
}
