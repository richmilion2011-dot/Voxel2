using System;
using System.Collections.Generic;
using UnityEngine;
using VoxelWorld.Blocks;

namespace VoxelWorld.World
{
    public struct LightSrc { public int x, y, z, r; }

    /// Greedy meshing для кубов + отдельный проход для блоков особой формы (факел, плиты, ступени, заборы, панели, рельсы, лестница).
    /// Свет от факелов/лавы/светящегося камня: уровень 0..4 в UV1.y (меши с разным светом не склеиваются).
    public static class VoxelMeshGenerator
    {
        static readonly int[] Dims = { ChunkData.SizeX, ChunkData.SizeY, ChunkData.SizeZ };
        struct Box { public Vector3 mn, mx; public int tt, ts, tb; }

        static bool FaceVisible(ushort a, ushort b)
        {
            if (a == 0) return false;
            if (b == 0) return true;
            return BlockDatabase.Get(b).Transparent && a != b;
        }

        static float LightAt(IList<LightSrc> em, float x, float y, float z)
        {
            float best = 0f;
            for (int i = 0; i < em.Count; i++)
            {
                var e = em[i]; float dx = x - (e.x + 0.5f), dy = y - (e.y + 0.5f), dz = z - (e.z + 0.5f);
                float v = 1f - Mathf.Sqrt(dx * dx + dy * dy + dz * dz) / e.r;
                if (v > best) best = v;
            }
            return best;
        }

        static bool SolidCube(ushort v) { if (v == 0) return false; var d = BlockDatabase.Get(v); return d.Shape == Shape.Cube && d.Solid; }
        static bool Opaque(ushort v) { if (v == 0) return false; var d = BlockDatabase.Get(v); return d.Shape == Shape.Cube && d.Solid && !d.Transparent; }
        static bool Is(ushort v, Shape s) => v != 0 && BlockDatabase.Get(v).Shape == s;

        public static Mesh Build(Func<int, int, int, ushort> src, IList<LightSrc> em, bool collision = false)
        {
            Func<int, int, int, ushort> raw = src;
            if (collision) raw = (a0, b0, c0) => { var v0 = src(a0, b0, c0); return BlockDatabase.Get(v0).Solid ? v0 : (ushort)0; };
            Func<int, int, int, ushort> getBlock = (a0, b0, c0) => { var v0 = raw(a0, b0, c0); return v0 == 0 || BlockDatabase.Get(v0).Shape == Shape.Cube ? v0 : (ushort)0; };
            bool lit = !collision && em != null && em.Count > 0;

            var verts = new List<Vector3>(); var uv0 = new List<Vector2>();
            var uv1 = new List<Vector2>(); var tris = new List<int>();

            for (int d = 0; d < 3; d++)
            {
                int u = (d + 1) % 3, v = (d + 2) % 3;
                var x = new int[3]; var q = new int[3]; q[d] = 1;
                var mask = new int[Dims[u] * Dims[v]];

                for (x[d] = -1; x[d] < Dims[d];)
                {
                    int n = 0;
                    for (x[v] = 0; x[v] < Dims[v]; x[v]++)
                        for (x[u] = 0; x[u] < Dims[u]; x[u]++, n++)
                        {
                            ushort a = getBlock(x[0], x[1], x[2]);
                            ushort b = getBlock(x[0] + q[0], x[1] + q[1], x[2] + q[2]);
                            int m = 0, lx = 0, ly = 0, lz = 0;
                            if (FaceVisible(a, b)) { m = a << 1; lx = x[0] + q[0]; ly = x[1] + q[1]; lz = x[2] + q[2]; }
                            else if (FaceVisible(b, a)) { m = (b << 1) | 1; lx = x[0]; ly = x[1]; lz = x[2]; }
                            if (lit && m != 0) m |= ((int)(LightAt(em, lx + 0.5f, ly + 0.5f, lz + 0.5f) * 4f)) << 12;
                            mask[n] = m;
                        }
                    x[d]++;
                    n = 0;
                    for (int j = 0; j < Dims[v]; j++)
                        for (int i = 0; i < Dims[u];)
                        {
                            int m = mask[n];
                            if (m == 0) { i++; n++; continue; }
                            int w = 1; while (i + w < Dims[u] && mask[n + w] == m) w++;
                            int h = 1; bool stop = false;
                            while (j + h < Dims[v] && !stop)
                            {
                                for (int k = 0; k < w; k++) if (mask[n + k + h * Dims[u]] != m) { stop = true; break; }
                                if (!stop) h++;
                            }
                            x[u] = i; x[v] = j;
                            var du = new int[3]; du[u] = w; var dv = new int[3]; dv[v] = h;
                            var p0 = new Vector3(x[0], x[1], x[2]);
                            var p1 = p0 + new Vector3(du[0], du[1], du[2]);
                            var p3 = p0 + new Vector3(dv[0], dv[1], dv[2]);
                            var p2 = p1 + (p3 - p0);

                            int bm = m & 0xFFF; bool neg = (bm & 1) == 1; var def = BlockDatabase.Get((ushort)(bm >> 1));
                            float lt = (m >> 12) / 4f;
                            int tile = d == 1 ? (neg ? def.TexBottom : def.TexTop) : def.TexSide;

                            int bi = verts.Count;
                            verts.Add(p0); verts.Add(p1); verts.Add(p2); verts.Add(p3);
                            if (d == 0) { uv0.Add(new Vector2(0, 0)); uv0.Add(new Vector2(0, w)); uv0.Add(new Vector2(h, w)); uv0.Add(new Vector2(h, 0)); }
                            else { uv0.Add(new Vector2(0, 0)); uv0.Add(new Vector2(w, 0)); uv0.Add(new Vector2(w, h)); uv0.Add(new Vector2(0, h)); }
                            for (int k = 0; k < 4; k++) uv1.Add(new Vector2(tile, lt));

                            if (!neg) { tris.Add(bi); tris.Add(bi + 1); tris.Add(bi + 2); tris.Add(bi); tris.Add(bi + 2); tris.Add(bi + 3); }
                            else { tris.Add(bi); tris.Add(bi + 2); tris.Add(bi + 1); tris.Add(bi); tris.Add(bi + 3); tris.Add(bi + 2); }

                            for (int l = 0; l < h; l++) for (int k = 0; k < w; k++) mask[n + k + l * Dims[u]] = 0;
                            i += w; n += w;
                        }
                }
            }

            // блоки особой формы
            var boxes = new List<Box>();
            for (int y = 0; y < ChunkData.SizeY; y++)
                for (int z = 0; z < ChunkData.SizeZ; z++)
                    for (int x = 0; x < ChunkData.SizeX; x++)
                    {
                        ushort id = raw(x, y, z);
                        if (id == 0) continue;
                        var def = BlockDatabase.Get(id);
                        if (def.Shape == Shape.Cube) continue;
                        boxes.Clear(); Boxes(raw, x, y, z, def, id >> 9, collision, boxes);
                        if (boxes.Count == 0) continue;
                        float lt = lit ? Mathf.Floor(LightAt(em, x + 0.5f, y + 0.5f, z + 0.5f) * 4f) / 4f : 0f;
                        foreach (var bx in boxes) AddBox(verts, uv0, uv1, tris, raw, x, y, z, bx, lt);
                    }

            var mesh = new Mesh { indexFormat = UnityEngine.Rendering.IndexFormat.UInt32 };
            mesh.SetVertices(verts); mesh.SetUVs(0, uv0); mesh.SetUVs(1, uv1);
            mesh.SetTriangles(tris, 0);
            mesh.RecalculateNormals(); mesh.RecalculateBounds();
            return mesh;
        }

        static void Add(List<Box> l, float x0, float y0, float z0, float x1, float y1, float z1, BlockDefinition d, int tile = -1)
        {
            l.Add(new Box { mn = new Vector3(x0, y0, z0), mx = new Vector3(x1, y1, z1), tt = tile >= 0 ? tile : d.TexTop, ts = tile >= 0 ? tile : d.TexSide, tb = tile >= 0 ? tile : d.TexBottom });
        }

        static readonly float[][] DoorB =
        {
            new[] { 0f, 0f, 0f, 1f, 1f, 0.1875f }, new[] { 0f, 0f, 0f, 0.1875f, 1f, 1f }, new[] { 0f, 0f, 0.8125f, 1f, 1f, 1f }, new[] { 0.8125f, 0f, 0f, 1f, 1f, 1f },
            new[] { 0.8125f, 0f, 0f, 1f, 1f, 1f }, new[] { 0f, 0f, 0f, 1f, 1f, 0.1875f }, new[] { 0f, 0f, 0f, 0.1875f, 1f, 1f }, new[] { 0f, 0f, 0.8125f, 1f, 1f, 1f }
        };

        static void Boxes(Func<int, int, int, ushort> raw, int x, int y, int z, BlockDefinition d, int st, bool coll, List<Box> l)
        {
            switch (d.Shape)
            {
                case Shape.Torch:
                    {
                        if (coll) return;
                        float ox = 0, oy = 0, oz = 0;
                        if (!SolidCube(raw(x, y - 1, z)))
                        {
                            if (SolidCube(raw(x - 1, y, z))) { ox = -0.35f; oy = 0.15f; }
                            else if (SolidCube(raw(x + 1, y, z))) { ox = 0.35f; oy = 0.15f; }
                            else if (SolidCube(raw(x, y, z - 1))) { oz = -0.35f; oy = 0.15f; }
                            else if (SolidCube(raw(x, y, z + 1))) { oz = 0.35f; oy = 0.15f; }
                        }
                        Add(l, 0.4375f + ox, oy, 0.4375f + oz, 0.5625f + ox, 0.625f + oy, 0.5625f + oz, d);
                        break;
                    }
                case Shape.Ladder:
                    {
                        if (coll) return;
                        if (SolidCube(raw(x - 1, y, z))) Add(l, 0, 0, 0, 0.1f, 1, 1, d);
                        else if (SolidCube(raw(x + 1, y, z))) Add(l, 0.9f, 0, 0, 1, 1, 1, d);
                        else if (SolidCube(raw(x, y, z + 1))) Add(l, 0, 0, 0.9f, 1, 1, 1, d);
                        else Add(l, 0, 0, 0, 1, 1, 0.1f, d);
                        break;
                    }
                case Shape.Rail:
                    {
                        if (coll) return;
                        bool ax = Is(raw(x - 1, y, z), Shape.Rail) || Is(raw(x + 1, y, z), Shape.Rail);
                        bool az = Is(raw(x, y, z - 1), Shape.Rail) || Is(raw(x, y, z + 1), Shape.Rail);
                        Add(l, 0, 0, 0, 1, 0.0625f, 1, d, ax && !az ? d.TexSide : d.TexTop);
                        break;
                    }
                case Shape.Door:
                    {
                        bool up = (st & 1) != 0, open = (st & 2) != 0; int f = (st >> 2) & 3; var bb = DoorB[open ? f + 4 : f];
                        Add(l, bb[0], bb[1], bb[2], bb[3], bb[4], bb[5], d, up ? d.TexTop : d.TexSide);
                        break;
                    }
                case Shape.Trapdoor:
                    {
                        bool top = (st & 1) != 0, open = (st & 2) != 0; int f = (st >> 2) & 3;
                        if (open) { var bb = DoorB[f]; Add(l, bb[0], bb[1], bb[2], bb[3], bb[4], bb[5], d, d.TexSide); }
                        else if (top) Add(l, 0, 0.8125f, 0, 1, 1, 1, d, d.TexSide);
                        else Add(l, 0, 0, 0, 1, 0.1875f, 1, d, d.TexSide);
                        break;
                    }
                case Shape.Gate:
                    {
                        bool open = (st & 2) != 0, alongX = (((st >> 2) & 3) & 1) == 0; float hh = coll ? 1.5f : 1f;
                        if (alongX)
                        {
                            Add(l, 0, 0.3125f, 0.4375f, 0.125f, hh, 0.5625f, d, d.TexSide); Add(l, 0.875f, 0.3125f, 0.4375f, 1, hh, 0.5625f, d, d.TexSide);
                            if (!open) { if (coll) Add(l, 0.125f, 0, 0.4375f, 0.875f, 1.5f, 0.5625f, d, d.TexSide); else { Add(l, 0.125f, 0.375f, 0.4375f, 0.875f, 0.5625f, 0.5625f, d, d.TexSide); Add(l, 0.125f, 0.75f, 0.4375f, 0.875f, 0.9375f, 0.5625f, d, d.TexSide); } }
                        }
                        else
                        {
                            Add(l, 0.4375f, 0.3125f, 0, 0.5625f, hh, 0.125f, d, d.TexSide); Add(l, 0.4375f, 0.3125f, 0.875f, 0.5625f, hh, 1, d, d.TexSide);
                            if (!open) { if (coll) Add(l, 0.4375f, 0, 0.125f, 0.5625f, 1.5f, 0.875f, d, d.TexSide); else { Add(l, 0.4375f, 0.375f, 0.125f, 0.5625f, 0.5625f, 0.875f, d, d.TexSide); Add(l, 0.4375f, 0.75f, 0.125f, 0.5625f, 0.9375f, 0.875f, d, d.TexSide); } }
                        }
                        break;
                    }
                case Shape.Wall:
                    {
                        Add(l, 0.25f, 0, 0.25f, 0.75f, coll ? 1.5f : 1f, 0.75f, d);
                        for (int k = 0; k < 4; k++)
                        {
                            int dx = k == 0 ? 1 : k == 1 ? -1 : 0, dz = k == 2 ? 1 : k == 3 ? -1 : 0;
                            ushort nb = raw(x + dx, y, z + dz);
                            if (!(Is(nb, Shape.Wall) || Is(nb, Shape.Fence) || Is(nb, Shape.Gate) || SolidCube(nb))) continue;
                            float a0 = dx > 0 ? 0.75f : dx < 0 ? 0f : 0.3125f, a1 = dx > 0 ? 1f : dx < 0 ? 0.25f : 0.6875f;
                            float b0 = dz > 0 ? 0.75f : dz < 0 ? 0f : 0.3125f, b1 = dz > 0 ? 1f : dz < 0 ? 0.25f : 0.6875f;
                            Add(l, a0, 0, b0, a1, coll ? 1.5f : 0.875f, b1, d);
                        }
                        break;
                    }
                case Shape.Slab: Add(l, 0, 0, 0, 1, 0.5f, 1, d); break;
                case Shape.Stair:
                    Add(l, 0, 0, 0, 1, 0.5f, 1, d);
                    switch (d.Facing)
                    {
                        case 0: Add(l, 0, 0.5f, 0.5f, 1, 1, 1, d); break;
                        case 1: Add(l, 0.5f, 0.5f, 0, 1, 1, 1, d); break;
                        case 2: Add(l, 0, 0.5f, 0, 1, 1, 0.5f, d); break;
                        default: Add(l, 0, 0.5f, 0, 0.5f, 1, 1, d); break;
                    }
                    break;
                case Shape.Fence:
                    {
                        float hh = coll ? 1.5f : 1f;
                        Add(l, 0.375f, 0, 0.375f, 0.625f, hh, 0.625f, d);
                        for (int k = 0; k < 4; k++)
                        {
                            int dx = k == 0 ? 1 : k == 1 ? -1 : 0, dz = k == 2 ? 1 : k == 3 ? -1 : 0;
                            ushort nb = raw(x + dx, y, z + dz);
                            if (!(Is(nb, Shape.Fence) || Is(nb, Shape.Wall) || Is(nb, Shape.Gate) || SolidCube(nb))) continue;
                            float a0 = dx > 0 ? 0.625f : dx < 0 ? 0f : 0.4375f, a1 = dx > 0 ? 1f : dx < 0 ? 0.375f : 0.5625f;
                            float b0 = dz > 0 ? 0.625f : dz < 0 ? 0f : 0.4375f, b1 = dz > 0 ? 1f : dz < 0 ? 0.375f : 0.5625f;
                            if (coll) Add(l, a0, 0, b0, a1, 1.5f, b1, d);
                            else { Add(l, a0, 0.375f, b0, a1, 0.5625f, b1, d); Add(l, a0, 0.75f, b0, a1, 0.9375f, b1, d); }
                        }
                        break;
                    }
                case Shape.Pane:
                    {
                        Add(l, 0.4375f, 0, 0.4375f, 0.5625f, 1, 0.5625f, d);
                        for (int k = 0; k < 4; k++)
                        {
                            int dx = k == 0 ? 1 : k == 1 ? -1 : 0, dz = k == 2 ? 1 : k == 3 ? -1 : 0;
                            ushort nb = raw(x + dx, y, z + dz);
                            if (!(Is(nb, Shape.Pane) || SolidCube(nb))) continue;
                            float a0 = dx > 0 ? 0.5625f : dx < 0 ? 0f : 0.4375f, a1 = dx > 0 ? 1f : dx < 0 ? 0.4375f : 0.5625f;
                            float b0 = dz > 0 ? 0.5625f : dz < 0 ? 0f : 0.4375f, b1 = dz > 0 ? 1f : dz < 0 ? 0.4375f : 0.5625f;
                            Add(l, a0, 0, b0, a1, 1, b1, d);
                        }
                        break;
                    }
            }
        }

        // углы граней: -X, +X, -Y, +Y, -Z, +Z
        static readonly int[,,] Corner =
        {
            { {0,1,0}, {0,0,0}, {0,1,1}, {0,0,1} }, { {1,1,1}, {1,0,1}, {1,1,0}, {1,0,0} },
            { {1,0,1}, {0,0,1}, {1,0,0}, {0,0,0} }, { {0,1,1}, {1,1,1}, {0,1,0}, {1,1,0} },
            { {1,0,0}, {0,0,0}, {1,1,0}, {0,1,0} }, { {0,0,1}, {1,0,1}, {0,1,1}, {1,1,1} }
        };

        static void AddBox(List<Vector3> V, List<Vector2> U0, List<Vector2> U1, List<int> T, Func<int, int, int, ushort> raw, int x, int y, int z, Box b, float lt)
        {
            for (int f = 0; f < 6; f++)
            {
                switch (f)
                {
                    case 0: if (b.mn.x <= 0f && Opaque(raw(x - 1, y, z))) continue; break;
                    case 1: if (b.mx.x >= 1f && Opaque(raw(x + 1, y, z))) continue; break;
                    case 2: if (b.mn.y <= 0f && Opaque(raw(x, y - 1, z))) continue; break;
                    case 3: if (b.mx.y >= 1f && Opaque(raw(x, y + 1, z))) continue; break;
                    case 4: if (b.mn.z <= 0f && Opaque(raw(x, y, z - 1))) continue; break;
                    default: if (b.mx.z >= 1f && Opaque(raw(x, y, z + 1))) continue; break;
                }
                int tile = f == 3 ? b.tt : f == 2 ? b.tb : b.ts, n = V.Count;
                for (int k = 0; k < 4; k++)
                {
                    float px = Corner[f, k, 0] == 0 ? b.mn.x : b.mx.x, py = Corner[f, k, 1] == 0 ? b.mn.y : b.mx.y, pz = Corner[f, k, 2] == 0 ? b.mn.z : b.mx.z;
                    V.Add(new Vector3(x + px, y + py, z + pz));
                    float u, v;
                    switch (f)
                    {
                        case 0: u = pz; v = py; break;
                        case 1: u = 1 - pz; v = py; break;
                        case 2: u = px; v = 1 - pz; break;
                        case 3: u = 1 - px; v = pz; break;
                        case 4: u = 1 - px; v = py; break;
                        default: u = px; v = py; break;
                    }
                    U0.Add(new Vector2(u, v)); U1.Add(new Vector2(tile, lt));
                }
                T.Add(n); T.Add(n + 1); T.Add(n + 2); T.Add(n + 2); T.Add(n + 1); T.Add(n + 3);
            }
        }
    }
}
