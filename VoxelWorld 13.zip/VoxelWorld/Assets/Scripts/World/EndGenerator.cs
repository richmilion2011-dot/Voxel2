using UnityEngine;
using VoxelWorld.Blocks;

namespace VoxelWorld.World
{
    /// Энд: центральный остров из камня Энда, 10 обсидиановых башен, выход (портал в центре в бедроковом кольце) и далёкие парящие острова.
    public static class EndGenerator
    {
        static float H01(int x, int z, int seed, int salt)
        {
            unchecked
            {
                uint h = (uint)(x * 374761393 + z * 668265263 + seed * 1013904223 + salt * 1274126177);
                h = (h ^ (h >> 13)) * 1274126177u; h ^= h >> 16;
                return (h & 0xFFFFFF) / (float)0x1000000;
            }
        }

        public static ChunkData Generate(Vector2Int key, int seed)
        {
            var cd = new ChunkData();
            int bx = key.x * ChunkData.SizeX, bz = key.y * ChunkData.SizeZ;
            for (int x = 0; x < ChunkData.SizeX; x++)
                for (int z = 0; z < ChunkData.SizeZ; z++)
                {
                    int wx = bx + x, wz = bz + z; float d = Mathf.Sqrt(wx * wx + wz * wz);
                    if (d < 42f)
                    {
                        int bottom = 62 - (int)((1f - d / 42f) * 22f);
                        for (int y = bottom; y <= 64; y++) cd.Set(x, y, z, (ushort)BlockId.EndStone);
                    }
                    else if (d > 100f)
                    {
                        int cx = Mathf.FloorToInt(wx / 56f), cz = Mathf.FloorToInt(wz / 56f);
                        if (H01(cx, cz, seed, 500) < 0.45f)
                        {
                            float ix = cx * 56 + 14 + H01(cx, cz, seed, 501) * 28f, iz = cz * 56 + 14 + H01(cx, cz, seed, 502) * 28f;
                            float ir = 6f + H01(cx, cz, seed, 503) * 8f; int iy = 50 + (int)(H01(cx, cz, seed, 504) * 25f);
                            float dd = Mathf.Sqrt((wx - ix) * (wx - ix) + (wz - iz) * (wz - iz));
                            if (dd < ir) { int th = (int)((1f - dd / ir) * 7f) + 1; for (int y = iy - th; y <= iy; y++) cd.Set(x, y, z, (ushort)BlockId.EndStone); }
                        }
                    }
                    for (int i = 0; i < 10; i++)
                    {
                        float a = i * 36f * Mathf.Deg2Rad; float px = Mathf.Round(Mathf.Cos(a) * 32f), pz = Mathf.Round(Mathf.Sin(a) * 32f);
                        if ((wx - px) * (wx - px) + (wz - pz) * (wz - pz) <= 9f)
                            for (int y = 60; y < 76 + (i % 5) * 5; y++) cd.Set(x, y, z, (ushort)BlockId.Obsidian);
                    }
                    int ax = Mathf.Abs(wx), az = Mathf.Abs(wz);
                    if (ax <= 2 && az <= 2)
                    {
                        if (Mathf.Max(ax, az) == 2) { cd.Set(x, 64, z, (ushort)BlockId.Bedrock); cd.Set(x, 65, z, (ushort)BlockId.Bedrock); }
                        else cd.Set(x, 64, z, (ushort)BlockId.EndPortal);
                    }
                }
            return cd;
        }
    }
}
