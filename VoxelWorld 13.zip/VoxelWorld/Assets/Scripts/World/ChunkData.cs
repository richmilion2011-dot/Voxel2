using System.Collections.Generic;
using VoxelWorld.Blocks;

namespace VoxelWorld.World
{
    public class ChunkData
    {
        public const int SizeX = 16, SizeY = 128, SizeZ = 16;
        public readonly ushort[] Blocks = new ushort[SizeX * SizeY * SizeZ];
        public bool Dirty;
        public readonly List<LightSrc> Emit = new List<LightSrc>();

        public void RebuildEmitters()
        {
            Emit.Clear();
            for (int y = 0; y < SizeY; y++) for (int z = 0; z < SizeZ; z++) for (int x = 0; x < SizeX; x++)
            { int l = BlockDatabase.Get(Blocks[Idx(x, y, z)]).Light; if (l > 0) Emit.Add(new LightSrc { x = x, y = y, z = z, r = l }); }
        }

        static int Idx(int x, int y, int z) => x + SizeX * (z + SizeZ * y);
        public static bool InRange(int x, int y, int z) =>
            x >= 0 && x < SizeX && y >= 0 && y < SizeY && z >= 0 && z < SizeZ;

        public ushort Get(int x, int y, int z) => InRange(x, y, z) ? Blocks[Idx(x, y, z)] : (ushort)0;
        public void Set(int x, int y, int z, ushort id)
        {
            if (!InRange(x, y, z)) return;
            int i = Idx(x, y, z); ushort old = Blocks[i];
            Blocks[i] = id; Dirty = true;
            if (old != id)
            {
                if (BlockDatabase.Get(old).Light > 0) Emit.RemoveAll(e => e.x == x && e.y == y && e.z == z);
                int l = BlockDatabase.Get(id).Light;
                if (l > 0) Emit.Add(new LightSrc { x = x, y = y, z = z, r = l });
            }
        }
    }
}
