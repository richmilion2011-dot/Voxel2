using UnityEngine;
using VoxelWorld.Blocks;

namespace VoxelWorld.World
{
    /// Незер: пещерный мир между бедроковым дном и потолком, лавовое море (y <= 31), душевой песок, светящийся камень на потолке, кварц.
    public static class NetherGenerator
    {
        static float P3(float x, float y, float z) => (Mathf.PerlinNoise(x, y) + Mathf.PerlinNoise(y, z) + Mathf.PerlinNoise(x, z)) / 3f;

        public static ChunkData Generate(Vector2Int key, int seed)
        {
            var cd = new ChunkData(); float o = (seed % 10007) * 0.37f + 500f;
            int bx = key.x * ChunkData.SizeX, bz = key.y * ChunkData.SizeZ;
            for (int x = 0; x < ChunkData.SizeX; x++)
                for (int z = 0; z < ChunkData.SizeZ; z++)
                {
                    int wx = bx + x, wz = bz + z;
                    for (int y = 0; y < ChunkData.SizeY; y++)
                    {
                        ushort id = 0;
                        if (y <= 1 || y >= 126) id = (ushort)BlockId.Bedrock;
                        else
                        {
                            float n = P3(wx * 0.035f + o, y * 0.07f, wz * 0.035f + o);
                            float bias = y < 34 ? (34 - y) * 0.012f : 0f;
                            if (y > 96) bias += (y - 96) * 0.012f;
                            if (n + bias > 0.52f)
                            {
                                id = (ushort)BlockId.Netherrack;
                                if (y > 90 && P3(wx * 0.15f + o + 900f, y * 0.15f, wz * 0.15f + o + 900f) > 0.62f) id = (ushort)BlockId.Glowstone;
                                else if (y >= 28 && y <= 40 && P3(wx * 0.12f + o + 100f, y * 0.12f, wz * 0.12f + o + 100f) > 0.58f) id = (ushort)BlockId.SoulSand;
                                else if (y < 30 && P3(wx * 0.15f + o + 500f, y * 0.15f, wz * 0.15f + o + 500f) > 0.62f) id = (ushort)BlockId.Blackstone;
                                else if (y < 40 && P3(wx * 0.25f + o + 700f, y * 0.25f, wz * 0.25f + o + 700f) > 0.7f) id = (ushort)BlockId.AncientDebris;
                                else if (P3(wx * 0.2f + o + 300f, y * 0.2f, wz * 0.2f + o + 300f) > 0.66f) id = (ushort)BlockId.QuartzOre;
                                else if (y >= 31 && y <= 34 && Mathf.PerlinNoise(wx * 0.3f + o, wz * 0.3f + y) > 0.7f) id = (ushort)BlockId.MagmaBlock;
                            }
                            else if (y <= 31) id = (ushort)BlockId.Lava;
                        }
                        if (id != 0) cd.Set(x, y, z, id);
                    }
                }
            return cd;
        }
    }
}
