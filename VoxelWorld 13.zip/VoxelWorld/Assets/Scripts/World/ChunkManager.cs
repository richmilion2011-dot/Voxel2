using System.Collections.Generic;
using UnityEngine;
using VoxelWorld.Blocks;
using VoxelWorld.Core;

namespace VoxelWorld.World
{
    /// Этап 1: синхронная генерация и загрузка/выгрузка чанков вокруг игрока.
    public class ChunkManager : MonoBehaviour
    {
        public Transform player;
        public Material chunkMaterial;
        public int seed = 12345;
        public int dimension;
        public VoxelWorld.Save.WorldSave save;
        public int renderDistance = 4;
        const int SeaLevel = 44;

        readonly Dictionary<Vector2Int, ChunkData> data = new();
        readonly Dictionary<Vector2Int, GameObject> objs = new();
        Vector2Int last = new(int.MinValue, 0);

        static int FloorDiv(int a, int b) => Mathf.FloorToInt((float)a / b);
        static Vector2Int WorldToChunk(Vector3 p) =>
            new(FloorDiv(Mathf.FloorToInt(p.x), ChunkData.SizeX), FloorDiv(Mathf.FloorToInt(p.z), ChunkData.SizeZ));

        void Update()
        {
            var c = WorldToChunk(player.position);
            if (c == last) return;
            last = c; Refresh(c);
        }

        void Refresh(Vector2Int c)
        {
            int r = renderDistance;
            for (int dx = -r - 1; dx <= r + 1; dx++)
                for (int dz = -r - 1; dz <= r + 1; dz++)
                {
                    var k = new Vector2Int(c.x + dx, c.y + dz);
                    if (!data.ContainsKey(k)) data[k] = Generate(k);
                }
            for (int dx = -r; dx <= r; dx++)
                for (int dz = -r; dz <= r; dz++)
                {
                    var k = new Vector2Int(c.x + dx, c.y + dz);
                    if (!objs.ContainsKey(k)) Spawn(k);
                }
            var rem = new List<Vector2Int>();
            foreach (var k in objs.Keys)
                if (Mathf.Max(Mathf.Abs(k.x - c.x), Mathf.Abs(k.y - c.y)) > r) rem.Add(k);
            foreach (var k in rem) { Destroy(objs[k].GetComponent<MeshFilter>().sharedMesh); Destroy(objs[k].GetComponent<MeshCollider>().sharedMesh); Destroy(objs[k]); objs.Remove(k); }
            rem.Clear();
            foreach (var k in data.Keys)
                if (Mathf.Max(Mathf.Abs(k.x - c.x), Mathf.Abs(k.y - c.y)) > r + 2) rem.Add(k);
            foreach (var k in rem)
            {
                if (data[k].Dirty) save?.SaveChunk(k, data[k]);
                data.Remove(k);
            }
        }

        ChunkData Generate(Vector2Int key)
        {
            var loaded = save?.LoadChunk(key);
            if (loaded != null) return loaded;
            var cd = dimension == 1 ? NetherGenerator.Generate(key, seed) : dimension == 2 ? EndGenerator.Generate(key, seed) : WorldGenerator.Generate(key, seed);
            cd.Dirty = false; // сгенерированное — не изменение
            return cd;
        }

        public void SwitchDimension(int d)
        {
            SaveAllDirty();
            foreach (var go in objs.Values)
            { Destroy(go.GetComponent<MeshFilter>().sharedMesh); Destroy(go.GetComponent<MeshCollider>().sharedMesh); Destroy(go); }
            objs.Clear(); data.Clear();
            dimension = d; GameSession.Dimension = d; if (save != null) save.Dim = d;
            ForceRefresh();
        }

        public bool IsMeshed(int x, int z) => objs.ContainsKey(new Vector2Int(FloorDiv(x, ChunkData.SizeX), FloorDiv(z, ChunkData.SizeZ)));

        public void SetMany(List<Vector3Int> pos, List<ushort> ids)
        {
            var dirty = new HashSet<Vector2Int>();
            for (int i = 0; i < pos.Count; i++)
            {
                var p = pos[i]; if (p.y < 0 || p.y >= ChunkData.SizeY) continue;
                int cx = FloorDiv(p.x, ChunkData.SizeX), cz = FloorDiv(p.z, ChunkData.SizeZ);
                if (!data.TryGetValue(new Vector2Int(cx, cz), out var cd)) continue;
                cd.Set(p.x - cx * ChunkData.SizeX, p.y, p.z - cz * ChunkData.SizeZ, ids[i]); dirty.Add(new Vector2Int(cx, cz));
            }
            foreach (var k in dirty) for (int dx = -1; dx <= 1; dx++) for (int dz = -1; dz <= 1; dz++) Remesh(new Vector2Int(k.x + dx, k.y + dz));
        }

        public void ExplodeAt(Vector3 c, float r)
        {
            var dirty = new HashSet<Vector2Int>(); int R = Mathf.CeilToInt(r);
            for (int dx = -R; dx <= R; dx++)
                for (int dy = -R; dy <= R; dy++)
                    for (int dz = -R; dz <= R; dz++)
                    {
                        if (dx * dx + dy * dy + dz * dz > r * r) continue;
                        int x = Mathf.FloorToInt(c.x) + dx, y = Mathf.FloorToInt(c.y) + dy, z = Mathf.FloorToInt(c.z) + dz;
                        if (y <= 0 || y >= ChunkData.SizeY) continue;
                        int cx = FloorDiv(x, ChunkData.SizeX), cz = FloorDiv(z, ChunkData.SizeZ);
                        if (!data.TryGetValue(new Vector2Int(cx, cz), out var cd)) continue;
                        int lx = x - cx * ChunkData.SizeX, lz = z - cz * ChunkData.SizeZ;
                        ushort b = cd.Get(lx, y, lz);
                        if (b == 0 || b == (ushort)BlockId.Bedrock) continue;
                        cd.Set(lx, y, lz, 0); dirty.Add(new Vector2Int(cx, cz));
                    }
            foreach (var k in dirty)
            { Remesh(k); Remesh(new Vector2Int(k.x - 1, k.y)); Remesh(new Vector2Int(k.x + 1, k.y)); Remesh(new Vector2Int(k.x, k.y - 1)); Remesh(new Vector2Int(k.x, k.y + 1)); }
        }

        public bool IsLoadedAt(int x, int z) => data.ContainsKey(new Vector2Int(FloorDiv(x, ChunkData.SizeX), FloorDiv(z, ChunkData.SizeZ)));

        public void ForceRefresh() { last = new Vector2Int(int.MinValue, 0); }

        public void SaveAllDirty()
        {
            if (save == null) return;
            foreach (var kv in data)
                if (kv.Value.Dirty) { save.SaveChunk(kv.Key, kv.Value); kv.Value.Dirty = false; }
        }

        ushort GetBlock(Vector2Int key, int x, int y, int z)
        {
            if (y < 0) return (ushort)BlockId.Bedrock;
            if (y >= ChunkData.SizeY) return 0;
            int cx = FloorDiv(x, ChunkData.SizeX), cz = FloorDiv(z, ChunkData.SizeZ);
            if (!data.TryGetValue(new Vector2Int(key.x + cx, key.y + cz), out var cd)) return (ushort)BlockId.Bedrock;
            return cd.Get(x - cx * ChunkData.SizeX, y, z - cz * ChunkData.SizeZ);
        }

        public ushort GetBlockWorld(int x, int y, int z) => GetBlock(Vector2Int.zero, x, y, z);

        public void SetBlockWorld(int x, int y, int z, ushort id)
        {
            if (y < 0 || y >= ChunkData.SizeY) return;
            int cx = FloorDiv(x, ChunkData.SizeX), cz = FloorDiv(z, ChunkData.SizeZ);
            if (!data.TryGetValue(new Vector2Int(cx, cz), out var cd)) return;
            int lx = x - cx * ChunkData.SizeX, lz = z - cz * ChunkData.SizeZ;
            ushort oldId = cd.Get(lx, y, lz);
            cd.Set(lx, y, lz, id);
            Remesh(new Vector2Int(cx, cz));
            if (BlockDatabase.Get(id).Light > 0 || BlockDatabase.Get(oldId).Light > 0)
                for (int ex = -1; ex <= 1; ex++) for (int ez = -1; ez <= 1; ez++) if (ex != 0 || ez != 0) Remesh(new Vector2Int(cx + ex, cz + ez));
            if (lx == 0) Remesh(new Vector2Int(cx - 1, cz));
            if (lx == ChunkData.SizeX - 1) Remesh(new Vector2Int(cx + 1, cz));
            if (lz == 0) Remesh(new Vector2Int(cx, cz - 1));
            if (lz == ChunkData.SizeZ - 1) Remesh(new Vector2Int(cx, cz + 1));
        }

        List<LightSrc> GetEmitters(Vector2Int key)
        {
            var l = new List<LightSrc>();
            for (int dx = -1; dx <= 1; dx++)
                for (int dz = -1; dz <= 1; dz++)
                    if (data.TryGetValue(new Vector2Int(key.x + dx, key.y + dz), out var c))
                        foreach (var e in c.Emit) l.Add(new LightSrc { x = e.x + dx * ChunkData.SizeX, y = e.y, z = e.z + dz * ChunkData.SizeZ, r = e.r });
            return l;
        }

        void Remesh(Vector2Int key)
        {
            if (!objs.TryGetValue(key, out var go)) return;
            var mf = go.GetComponent<MeshFilter>();
            var mc = go.GetComponent<MeshCollider>();
            Destroy(mf.sharedMesh); Destroy(mc.sharedMesh);
            mf.sharedMesh = VoxelMeshGenerator.Build((x, y, z) => GetBlock(key, x, y, z), GetEmitters(key));
            mc.sharedMesh = VoxelMeshGenerator.Build((x, y, z) => GetBlock(key, x, y, z), null, true);
        }

        void Spawn(Vector2Int key)
        {
            var go = new GameObject($"Chunk {key.x},{key.y}");
            go.transform.SetParent(transform);
            go.transform.position = new Vector3(key.x * ChunkData.SizeX, 0, key.y * ChunkData.SizeZ);
            var mesh = VoxelMeshGenerator.Build((x, y, z) => GetBlock(key, x, y, z), GetEmitters(key));
            go.AddComponent<MeshFilter>().sharedMesh = mesh;
            go.AddComponent<MeshRenderer>().sharedMaterial = chunkMaterial;
            go.AddComponent<MeshCollider>().sharedMesh = VoxelMeshGenerator.Build((x, y, z) => GetBlock(key, x, y, z), null, true);
            objs[key] = go;
        }
    }
}
