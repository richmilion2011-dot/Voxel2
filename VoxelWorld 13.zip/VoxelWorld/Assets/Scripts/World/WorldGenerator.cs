using UnityEngine;
using VoxelWorld.Blocks;

namespace VoxelWorld.World
{
    public enum Biome { Plains, Forest, Desert, Snowy, Savanna, Jungle }

    /// Чистые функции от (x, z, seed): деревья на границах чанков получаются без швов.
    public static class WorldGenerator
    {
        public const int SeaLevel = 44;
        const float CaveWidth = 0.04f; // больше = шире и чаще пещеры
        const float CoalT = 0.62f, IronT = 0.63f; // меньше = больше руды

        static float Off(int seed) => (seed % 10007) * 0.173f;
        static float Perlin3(float x, float y, float z) =>
            (Mathf.PerlinNoise(x, y) + Mathf.PerlinNoise(y, z) + Mathf.PerlinNoise(x, z)) / 3f;

        static float Hash01(int x, int z, int seed, int salt)
        {
            unchecked
            {
                uint h = (uint)(x * 374761393 + z * 668265263 + seed * 1013904223 + salt * 1274126177);
                h = (h ^ (h >> 13)) * 1274126177u; h ^= h >> 16;
                return (h & 0xFFFFFF) / (float)0x1000000;
            }
        }

        public static int Height(int wx, int wz, int seed)
        {
            float o = Off(seed);
            float n = Mathf.PerlinNoise(wx * 0.01f + o, wz * 0.01f + o) * 0.7f
                    + Mathf.PerlinNoise(wx * 0.05f + o, wz * 0.05f + o) * 0.3f;
            return Mathf.Clamp(30 + Mathf.RoundToInt(n * 40f), 2, ChunkData.SizeY - 12);
        }

        public static Biome GetBiome(int wx, int wz, int seed)
        {
            float o = Off(seed);
            float t = Mathf.PerlinNoise(wx * 0.004f + o + 1000f, wz * 0.004f + o + 1000f);
            float m = Mathf.PerlinNoise(wx * 0.004f + o + 2000f, wz * 0.004f + o + 2000f);
            if (t < 0.4f) return Biome.Snowy;
            if (t > 0.6f) return m < 0.45f ? Biome.Desert : m < 0.55f ? Biome.Savanna : Biome.Jungle;
            return m > 0.52f ? Biome.Forest : Biome.Plains;
        }

        const int VCell = 96, DCell = 64;
        static int FDiv(int a, int b) => Mathf.FloorToInt((float)a / b);

        static void PutRaw(ChunkData cd, int bx, int bz, int wx, int y, int wz, ushort id)
        {
            int lx = wx - bx, lz = wz - bz;
            if (lx >= 0 && lx < ChunkData.SizeX && lz >= 0 && lz < ChunkData.SizeZ) cd.Set(lx, y, lz, id);
        }

        static void Put(ChunkData cd, int bx, int bz, int wx, int y, int wz, BlockId id)
        {
            int lx = wx - bx, lz = wz - bz;
            if (lx >= 0 && lx < ChunkData.SizeX && lz >= 0 && lz < ChunkData.SizeZ) cd.Set(lx, y, lz, (ushort)id);
        }

        /// Якорь деревни в ячейке (cx, cz): false, если деревни там нет.
        public static bool GetVillage(int cx, int cz, int seed, out int ax, out int az, out int ah)
        {
            ax = az = ah = 0;
            if (Hash01(cx, cz, seed, 100) > 0.3f) return false;
            ax = cx * VCell + 8 + (int)(Hash01(cx, cz, seed, 101) * (VCell - 16));
            az = cz * VCell + 8 + (int)(Hash01(cx, cz, seed, 102) * (VCell - 16));
            var b = GetBiome(ax, az, seed);
            if (b != Biome.Plains && b != Biome.Forest && b != Biome.Savanna) return false;
            ah = Height(ax, az, seed);
            return ah > SeaLevel + 1 && ah < 56;
        }

        static void PlaceVillages(ChunkData cd, int bx, int bz, int seed)
        {
            int x0 = FDiv(bx - 34, VCell), x1 = FDiv(bx + ChunkData.SizeX + 34, VCell);
            int z0 = FDiv(bz - 34, VCell), z1 = FDiv(bz + ChunkData.SizeZ + 34, VCell);
            for (int cx = x0; cx <= x1; cx++)
                for (int cz = z0; cz <= z1; cz++)
                {
                    if (Hash01(cx, cz, seed, 100) > 0.3f) continue;
                    int ax = cx * VCell + 8 + (int)(Hash01(cx, cz, seed, 101) * (VCell - 16));
                    int az = cz * VCell + 8 + (int)(Hash01(cx, cz, seed, 102) * (VCell - 16));
                    var b = GetBiome(ax, az, seed);
                    if (b != Biome.Plains && b != Biome.Forest && b != Biome.Savanna) continue;
                    int ah = Height(ax, az, seed);
                    if (ah <= SeaLevel + 1 || ah >= 56) continue;
                    Well(cd, bx, bz, ax, az, ah);
                    int n = 3 + (int)(Hash01(cx, cz, seed, 103) * 3);
                    for (int i = 0; i < n; i++)
                    {
                        float ang = Hash01(cx, cz, seed, 110 + i) * 6.2831853f, rad = 11f + Hash01(cx, cz, seed, 130 + i) * 11f;
                        House(cd, bx, bz, ax + (int)(Mathf.Cos(ang) * rad) - 3, az + (int)(Mathf.Sin(ang) * rad) - 3, seed);
                    }
                }
        }

        static void Well(ChunkData cd, int bx, int bz, int ax, int az, int F)
        {
            for (int dx = -1; dx <= 1; dx++)
                for (int dz = -1; dz <= 1; dz++)
                {
                    for (int y = F + 1; y <= F + 3; y++) Put(cd, bx, bz, ax + dx, y, az + dz, BlockId.Air);
                    if (dx == 0 && dz == 0)
                    { Put(cd, bx, bz, ax, F, az, BlockId.Water); Put(cd, bx, bz, ax, F - 1, az, BlockId.Water); Put(cd, bx, bz, ax, F - 2, az, BlockId.Cobblestone); }
                    else { Put(cd, bx, bz, ax + dx, F, az + dz, BlockId.Cobblestone); Put(cd, bx, bz, ax + dx, F + 1, az + dz, BlockId.Cobblestone); }
                }
        }

        static void House(ChunkData cd, int bx, int bz, int hx, int hz, int seed)
        {
            if (hx > bx + 16 + 8 || hx + 6 < bx - 8 || hz > bz + 16 + 8 || hz + 6 < bz - 8) return; // не пересекает чанк
            int F = Height(hx + 3, hz + 3, seed);
            if (F <= SeaLevel + 1 || F >= 56) return;
            foreach (var c in new[] { new Vector2Int(0, 0), new Vector2Int(6, 0), new Vector2Int(0, 6), new Vector2Int(6, 6) })
            { int h = Height(hx + c.x, hz + c.y, seed); if (h <= SeaLevel + 1 || Mathf.Abs(h - F) > 3) return; }

            for (int x = 0; x <= 6; x++)
                for (int z = 0; z <= 6; z++)
                {
                    int wx = hx + x, wz = hz + z, g = Height(wx, wz, seed);
                    for (int y = g + 1; y < F; y++) Put(cd, bx, bz, wx, y, wz, BlockId.Cobblestone);
                    for (int y = F + 1; y <= F + 9; y++) Put(cd, bx, bz, wx, y, wz, BlockId.Air);
                    Put(cd, bx, bz, wx, F, wz, BlockId.Planks);
                    bool edge = x == 0 || x == 6 || z == 0 || z == 6, corner = (x == 0 || x == 6) && (z == 0 || z == 6);
                    if (edge)
                        for (int y = F + 1; y <= F + 3; y++)
                        {
                            BlockId id = corner ? BlockId.OakLog : BlockId.Planks;
                            bool window = y == F + 2 && (((x == 0 || x == 6) && z == 3) || (z == 6 && x == 3));
                            bool door = x == 3 && z == 0 && y <= F + 2;
                            Put(cd, bx, bz, wx, y, wz, door ? BlockId.Air : window ? BlockId.Glass : id);
                        }
                    for (int k = 0; k < 4; k++)
                        if (x >= k && x <= 6 - k && z >= k && z <= 6 - k) Put(cd, bx, bz, wx, F + 4 + k, wz, BlockId.Planks);
                }
            PutRaw(cd, bx, bz, hx + 3, F + 1, hz, (ushort)BlockId.OakDoor);
            PutRaw(cd, bx, bz, hx + 3, F + 2, hz, (ushort)((int)BlockId.OakDoor | (1 << 9)));
            Put(cd, bx, bz, hx + 1, F + 1, hz + 1, BlockId.CraftingTable);
            Put(cd, bx, bz, hx + 5, F + 1, hz + 1, BlockId.Furnace);
            Put(cd, bx, bz, hx + 5, F + 1, hz + 5, BlockId.Chest);
        }

        static void PlaceDungeons(ChunkData cd, int bx, int bz, int seed)
        {
            int x0 = FDiv(bx - 10, DCell), x1 = FDiv(bx + ChunkData.SizeX + 10, DCell);
            int z0 = FDiv(bz - 10, DCell), z1 = FDiv(bz + ChunkData.SizeZ + 10, DCell);
            for (int cx = x0; cx <= x1; cx++)
                for (int cz = z0; cz <= z1; cz++)
                {
                    if (Hash01(cx, cz, seed, 200) > 0.4f) continue;
                    int ax = cx * DCell + 10 + (int)(Hash01(cx, cz, seed, 201) * (DCell - 20));
                    int az = cz * DCell + 10 + (int)(Hash01(cx, cz, seed, 202) * (DCell - 20));
                    int ay = 12 + (int)(Hash01(cx, cz, seed, 203) * 14);
                    if (Height(ax, az, seed) < ay + 12) continue;
                    for (int dx = -4; dx <= 4; dx++)
                        for (int dz = -4; dz <= 4; dz++)
                            for (int dy = 0; dy <= 5; dy++)
                            {
                                bool shell = Mathf.Abs(dx) == 4 || Mathf.Abs(dz) == 4 || dy == 0 || dy == 5;
                                BlockId id = !shell ? BlockId.Air : Hash01(ax + dx * 7 + dy, az + dz, seed, 210) < 0.2f ? BlockId.Stone : BlockId.Cobblestone;
                                Put(cd, bx, bz, ax + dx, ay + dy, az + dz, id);
                            }
                    Put(cd, bx, bz, ax - 3, ay + 1, az - 3, BlockId.LootChest);
                    Put(cd, bx, bz, ax + 3, ay + 1, az + 3, BlockId.IronOre);
                    Put(cd, bx, bz, ax + 3, ay + 1, az - 3, BlockId.CoalOre);
                }
        }

        public static ChunkData Generate(Vector2Int key, int seed)
        {
            var cd = new ChunkData();
            float o = Off(seed);
            int bx = key.x * ChunkData.SizeX, bz = key.y * ChunkData.SizeZ;

            for (int x = 0; x < ChunkData.SizeX; x++)
                for (int z = 0; z < ChunkData.SizeZ; z++)
                {
                    int wx = bx + x, wz = bz + z;
                    int h = Height(wx, wz, seed);
                    var biome = GetBiome(wx, wz, seed);
                    bool sandy = h <= SeaLevel || biome == Biome.Desert;
                    bool rocky = h >= 58 && !sandy;

                    for (int y = 0; y <= h; y++)
                    {
                        BlockId id;
                        if (y == 0) id = BlockId.Bedrock;
                        else if (y == h) id = rocky ? (h >= 64 ? BlockId.Snow : BlockId.Stone) : sandy ? BlockId.Sand : biome == Biome.Snowy ? BlockId.Snow : BlockId.Grass;
                        else if (y >= h - 3) id = rocky ? BlockId.Stone : sandy ? BlockId.Sand : BlockId.Dirt;
                        else
                        {
                            if (y > 4 && y <= h - 4)
                            {
                                float a = Perlin3(wx * 0.05f + o, y * 0.07f, wz * 0.05f + o);
                                float b = Perlin3(wx * 0.05f + o + 500f, y * 0.07f + 100f, wz * 0.05f + o + 500f);
                                if (Mathf.Abs(a - 0.5f) < CaveWidth && Mathf.Abs(b - 0.5f) < CaveWidth) { if (y <= 10) cd.Set(x, y, z, Hash01(wx, wz + y * 131, seed, 77) < 0.18f ? (ushort)BlockId.Obsidian : (ushort)BlockId.Lava); continue; } // пещера
                            }
                            id = y < 14 ? BlockId.Deepslate : BlockId.Stone;
                            if (y < 70 && Perlin3(wx * 0.2f + o + 900f, y * 0.2f, wz * 0.2f + o + 900f) > CoalT) id = BlockId.CoalOre;
                            else if (y < 45 && Perlin3(wx * 0.2f + o + 1700f, y * 0.2f + 50f, wz * 0.2f + o + 1700f) > IronT) id = BlockId.IronOre;
                            else if (y < 16 && Perlin3(wx * 0.3f + o + 2500f, y * 0.3f, wz * 0.3f + o + 2500f) > 0.665f) id = BlockId.DiamondOre;
                            else if (y < 30 && Perlin3(wx * 0.3f + o + 3100f, y * 0.3f, wz * 0.3f + o + 3100f) > 0.645f) id = BlockId.GoldOre;
                            else if (y < 60 && Perlin3(wx * 0.25f + o + 3700f, y * 0.25f, wz * 0.25f + o + 3700f) > 0.64f) id = BlockId.CopperOre;
                            else if (y < 16 && Perlin3(wx * 0.3f + o + 4300f, y * 0.3f, wz * 0.3f + o + 4300f) > 0.645f) id = BlockId.RedstoneOre;
                            else if (y < 30 && Perlin3(wx * 0.3f + o + 4900f, y * 0.3f, wz * 0.3f + o + 4900f) > 0.655f) id = BlockId.LapisOre;
                            else if (y < 32 && Perlin3(wx * 0.3f + o + 5500f, y * 0.3f, wz * 0.3f + o + 5500f) > 0.67f) id = BlockId.EmeraldOre;
                        }
                        cd.Set(x, y, z, (ushort)id);
                    }
                    for (int y = h + 1; y <= SeaLevel; y++) cd.Set(x, y, z, (ushort)BlockId.Water);
                }

            // Деревья и кактусы: смотрим колонки с запасом 2 блока, чтобы кроны заходили из соседних чанков
            for (int tx = bx - 2; tx < bx + ChunkData.SizeX + 2; tx++)
                for (int tz = bz - 2; tz < bz + ChunkData.SizeZ + 2; tz++)
                {
                    float r = Hash01(tx, tz, seed, 1);
                    if (r > 0.1f) continue;
                    var biome = GetBiome(tx, tz, seed);
                    float dens = biome == Biome.Jungle ? 0.09f : biome == Biome.Forest ? 0.05f : biome == Biome.Snowy ? 0.012f
                               : (biome == Biome.Desert || biome == Biome.Savanna) ? 0.006f : 0.004f;
                    if (r > dens) continue;
                    int th = Height(tx, tz, seed);
                    if (th <= SeaLevel || th >= 58) continue;
                    int lx = tx - bx, lz = tz - bz;

                    if (biome == Biome.Desert)
                    {
                        int ch = 1 + (int)(Hash01(tx, tz, seed, 2) * 3);
                        for (int dy = 1; dy <= ch; dy++) cd.Set(lx, th + dy, lz, (ushort)BlockId.Cactus);
                        continue;
                    }
                    int trunk = 4 + (int)(Hash01(tx, tz, seed, 2) * 3) + (biome == Biome.Jungle ? 3 : 0);
                    BlockId lg = biome == Biome.Snowy ? BlockId.SpruceLog : biome == Biome.Jungle ? BlockId.JungleLog : biome == Biome.Savanna ? BlockId.AcaciaLog : (biome == Biome.Forest && Hash01(tx, tz, seed, 4) < 0.35f) ? BlockId.BirchLog : BlockId.OakLog;
                    BlockId lf = lg == BlockId.SpruceLog ? BlockId.SpruceLeaves : lg == BlockId.JungleLog ? BlockId.JungleLeaves : lg == BlockId.AcaciaLog ? BlockId.AcaciaLeaves : lg == BlockId.BirchLog ? BlockId.BirchLeaves : BlockId.OakLeaves;
                    for (int dy = trunk - 2; dy <= trunk + 1; dy++)
                    {
                        int rad = dy >= trunk ? 1 : 2;
                        for (int dx = -rad; dx <= rad; dx++)
                            for (int dz = -rad; dz <= rad; dz++)
                            {
                                if (Mathf.Abs(dx) == rad && Mathf.Abs(dz) == rad &&
                                    (dy >= trunk || Hash01(tx + dx, tz + dz, seed, 10 + dy) < 0.5f)) continue;
                                if (cd.Get(lx + dx, th + dy, lz + dz) == 0)
                                    cd.Set(lx + dx, th + dy, lz + dz, (ushort)lf);
                            }
                    }
                    for (int dy = 1; dy <= trunk; dy++) cd.Set(lx, th + dy, lz, (ushort)lg);
                }
            PlaceVillages(cd, bx, bz, seed);
            PlaceDungeons(cd, bx, bz, seed);
            return cd;
        }
    }
}
