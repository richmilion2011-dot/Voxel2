using System.Collections.Generic;
using UnityEngine;
using VoxelWorld.Save;

namespace VoxelWorld.Items
{
    /// Все печи мира плавят, даже когда окно закрыто.
    public class FurnaceSystem : MonoBehaviour
    {
        readonly Dictionary<Vector3Int, FurnaceState> map = new Dictionary<Vector3Int, FurnaceState>();

        public FurnaceState GetOrCreate(Vector3Int p)
        {
            if (!map.TryGetValue(p, out var f)) map[p] = f = new FurnaceState();
            return f;
        }

        public void Remove(Vector3Int p, Inventory inv)
        {
            if (!map.TryGetValue(p, out var f)) return;
            foreach (var s in f.slots) if (!s.Empty) inv.Add(s.id, s.count, s.dur);
            map.Remove(p);
        }

        public FurnaceData[] Export()
        {
            var list = new List<FurnaceData>();
            foreach (var kv in map)
                list.Add(new FurnaceData { x = kv.Key.x, y = kv.Key.y, z = kv.Key.z, slots = WorldSaver.ToData(kv.Value.slots),
                    burnLeft = kv.Value.burnLeft, burnMax = kv.Value.burnMax, cook = kv.Value.cook });
            return list.ToArray();
        }

        public void Import(FurnaceData[] arr)
        {
            map.Clear();
            if (arr == null) return;
            foreach (var d in arr)
            {
                var f = new FurnaceState { burnLeft = d.burnLeft, burnMax = d.burnMax, cook = d.cook };
                for (int i = 0; i < 3 && d.slots != null && i < d.slots.Length; i++) f.slots[i] = WorldSaver.FromData(d.slots[i]);
                map[new Vector3Int(d.x, d.y, d.z)] = f;
            }
        }

        void Update() { foreach (var f in map.Values) f.Tick(Time.deltaTime); }
    }
}
