using System.Collections.Generic;

namespace VoxelWorld.Items
{
    public static class SmeltingData
    {
        static readonly Dictionary<ushort, ushort> recipes = new Dictionary<ushort, ushort>
        {
            { (ushort)ItemId.RawIron, (ushort)ItemId.IronIngot },
            { (ushort)ItemId.RawBeef, (ushort)ItemId.CookedBeef },
            { (ushort)ItemId.RawGold, (ushort)ItemId.GoldIngot }, { (ushort)ItemId.RawCopper, (ushort)ItemId.CopperIngot },
            { (ushort)ItemId.RawPork, (ushort)ItemId.CookedPork }, { (ushort)ItemId.RawChicken, (ushort)ItemId.CookedChicken },
            { (ushort)Blocks.BlockId.Clay, (ushort)Blocks.BlockId.Terracotta },
            { (ushort)Blocks.BlockId.Sand, (ushort)Blocks.BlockId.Glass },
            { (ushort)Blocks.BlockId.Cobblestone, (ushort)Blocks.BlockId.Stone },
        };
        static readonly Dictionary<ushort, float> fuels = new Dictionary<ushort, float>
        {
            { (ushort)ItemId.Coal, 80f }, { (ushort)Blocks.BlockId.OakLog, 15f },
            { (ushort)Blocks.BlockId.Planks, 7.5f }, { (ushort)ItemId.Stick, 5f },
        };
        public static bool TryResult(ushort id, out ushort res) => recipes.TryGetValue(id, out res);
        public static float FuelTime(ushort id) => fuels.TryGetValue(id, out var t) ? t : 0f;
    }

    /// slots: 0 — сырьё, 1 — топливо, 2 — результат.
    public class FurnaceState
    {
        public const float CookTime = 10f;
        public readonly ItemStack[] slots = new ItemStack[3];
        public float burnLeft, burnMax, cook;

        public void Tick(float dt)
        {
            ushort res = 0;
            bool can = !slots[0].Empty && SmeltingData.TryResult(slots[0].id, out res) &&
                (slots[2].Empty || (slots[2].id == res && slots[2].count < ItemDatabase.MaxStack(res)));

            if (burnLeft <= 0 && can && !slots[1].Empty)
            {
                float t = SmeltingData.FuelTime(slots[1].id);
                if (t > 0) { burnMax = burnLeft = t; if (--slots[1].count <= 0) slots[1] = default; }
            }
            if (burnLeft > 0)
            {
                burnLeft -= dt; if (burnLeft < 0) burnLeft = 0;
                if (can)
                {
                    cook += dt;
                    if (cook >= CookTime)
                    {
                        cook = 0;
                        if (--slots[0].count <= 0) slots[0] = default;
                        if (slots[2].Empty) slots[2] = new ItemStack { id = res, count = 1 }; else slots[2].count++;
                    }
                }
                else cook = 0;
            }
            else cook = System.Math.Max(0f, cook - dt * 2f);
        }
    }
}
