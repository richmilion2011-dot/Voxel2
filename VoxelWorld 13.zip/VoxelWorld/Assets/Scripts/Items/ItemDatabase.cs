using System.Collections.Generic;
using VoxelWorld.Blocks;

namespace VoxelWorld.Items
{
    public enum ToolType { None, Pickaxe, Axe, Shovel, Sword, Hoe }
    public enum ItemId : ushort { Stick = 1000, Coal, RawIron, WoodPickaxe, StonePickaxe, WoodAxe, StoneAxe, WoodShovel, StoneShovel, WoodSword, StoneSword, Apple, IronIngot, IronPickaxe, IronAxe, IronShovel, IronSword, RawBeef, CookedBeef, RottenFlesh, WheatSeeds, Wheat, Bread, WoodHoe, StoneHoe, IronHoe, Emerald, RawGold, GoldIngot, RawCopper, CopperIngot, Diamond, Redstone, Lapis, Quartz, Gunpowder, RawPork, CookedPork, RawChicken, CookedChicken, DiamondPickaxe, DiamondAxe, DiamondShovel, DiamondSword, DiamondHoe, IronHelmet, IronChestplate, IronLeggings, IronBoots, DiamondHelmet, DiamondChestplate, DiamondLeggings, DiamondBoots, Bucket, WaterBucket, LavaBucket, Minecart, Flint, FlintAndSteel, EyeOfEnder }

    public class ItemDef
    {
        public ushort Id; public string Name; public int Tile; public int MaxStack = 64;
        public int Food; public float Sat; public int ArmorSlot = -1, ArmorPts;
        public ToolType Tool; public int Tier; public float Speed = 1f; public int Durability;
    }

    /// Id < 1000 — блоки (BlockId), Id >= 1000 — предметы (ItemId).
    public static class ItemDatabase
    {
        public const int FirstItem = 1000;
        static readonly Dictionary<ushort, ItemDef> items = new Dictionary<ushort, ItemDef>();

        static ItemDatabase()
        {
            Reg(ItemId.Stick, "Stick", 20); Reg(ItemId.Coal, "Coal", 21); Reg(ItemId.RawIron, "Raw Iron", 22);
            Tool(ItemId.WoodPickaxe, "Wooden Pickaxe", 23, ToolType.Pickaxe, 0);
            Tool(ItemId.StonePickaxe, "Stone Pickaxe", 24, ToolType.Pickaxe, 1);
            Tool(ItemId.WoodAxe, "Wooden Axe", 25, ToolType.Axe, 0);
            Tool(ItemId.StoneAxe, "Stone Axe", 26, ToolType.Axe, 1);
            Tool(ItemId.WoodShovel, "Wooden Shovel", 27, ToolType.Shovel, 0);
            Tool(ItemId.StoneShovel, "Stone Shovel", 28, ToolType.Shovel, 1);
            Tool(ItemId.WoodSword, "Wooden Sword", 29, ToolType.Sword, 0);
            Tool(ItemId.StoneSword, "Stone Sword", 30, ToolType.Sword, 1);
            items[(ushort)ItemId.Apple] = new ItemDef { Id = (ushort)ItemId.Apple, Name = "Apple", Tile = 31, Food = 4, Sat = 2.4f };
            Reg(ItemId.IronIngot, "Iron Ingot", 32);
            Tool(ItemId.IronPickaxe, "Iron Pickaxe", 33, ToolType.Pickaxe, 2);
            Tool(ItemId.IronAxe, "Iron Axe", 34, ToolType.Axe, 2);
            Tool(ItemId.IronShovel, "Iron Shovel", 35, ToolType.Shovel, 2);
            Tool(ItemId.IronSword, "Iron Sword", 36, ToolType.Sword, 2);
            Food(ItemId.RawBeef, "Raw Beef", 39, 3, 1.8f); Food(ItemId.CookedBeef, "Cooked Beef", 40, 8, 12.8f); Food(ItemId.RottenFlesh, "Rotten Flesh", 41, 4, 0.8f);
            Reg(ItemId.WheatSeeds, "Wheat Seeds", 51); Reg(ItemId.Wheat, "Wheat", 52); Food(ItemId.Bread, "Bread", 53, 5, 6f);
            Tool(ItemId.WoodHoe, "Wooden Hoe", 54, ToolType.Hoe, 0); Tool(ItemId.StoneHoe, "Stone Hoe", 55, ToolType.Hoe, 1); Tool(ItemId.IronHoe, "Iron Hoe", 56, ToolType.Hoe, 2);
            Reg(ItemId.Emerald, "Emerald", 57);
            Reg(ItemId.RawGold, "Raw Gold", 125);
            Reg(ItemId.GoldIngot, "Gold Ingot", 126);
            Reg(ItemId.RawCopper, "Raw Copper", 127);
            Reg(ItemId.CopperIngot, "Copper Ingot", 128);
            Reg(ItemId.Diamond, "Diamond", 129);
            Reg(ItemId.Redstone, "Redstone", 130);
            Reg(ItemId.Lapis, "Lapis Lazuli", 131);
            Reg(ItemId.Quartz, "Nether Quartz", 132);
            Reg(ItemId.Gunpowder, "Gunpowder", 133);
            Food(ItemId.RawPork, "Raw Porkchop", 134, 3, 1.8f);
            Food(ItemId.CookedPork, "Cooked Porkchop", 135, 8, 12.8f);
            Food(ItemId.RawChicken, "Raw Chicken", 136, 2, 1.2f);
            Food(ItemId.CookedChicken, "Cooked Chicken", 137, 6, 7.2f);
            Tool(ItemId.DiamondPickaxe, "Diamond Pickaxe", 138, ToolType.Pickaxe, 3);
            Tool(ItemId.DiamondAxe, "Diamond Axe", 139, ToolType.Axe, 3);
            Tool(ItemId.DiamondShovel, "Diamond Shovel", 140, ToolType.Shovel, 3);
            Tool(ItemId.DiamondSword, "Diamond Sword", 141, ToolType.Sword, 3);
            Tool(ItemId.DiamondHoe, "Diamond Hoe", 142, ToolType.Hoe, 3);
            Armor(ItemId.IronHelmet, "Iron Helmet", 143, 0, 2, 165, 2);
            Armor(ItemId.IronChestplate, "Iron Chestplate", 144, 1, 6, 240, 2);
            Armor(ItemId.IronLeggings, "Iron Leggings", 145, 2, 5, 225, 2);
            Armor(ItemId.IronBoots, "Iron Boots", 146, 3, 2, 195, 2);
            Armor(ItemId.DiamondHelmet, "Diamond Helmet", 147, 0, 3, 363, 3);
            Armor(ItemId.DiamondChestplate, "Diamond Chestplate", 148, 1, 8, 528, 3);
            Armor(ItemId.DiamondLeggings, "Diamond Leggings", 149, 2, 6, 495, 3);
            Armor(ItemId.DiamondBoots, "Diamond Boots", 150, 3, 3, 429, 3);
            One(ItemId.Bucket, "Bucket", 211);
            One(ItemId.WaterBucket, "Water Bucket", 212);
            One(ItemId.LavaBucket, "Lava Bucket", 213);
            One(ItemId.Minecart, "Minecart", 214);
            Reg(ItemId.Flint, "Flint", 329);
            One(ItemId.FlintAndSteel, "Flint and Steel", 330); items[(ushort)ItemId.FlintAndSteel].Durability = 64;
            Reg(ItemId.EyeOfEnder, "Eye of Ender", 331);
        }

        static void Food(ItemId id, string name, int tile, int food, float sat) =>
            items[(ushort)id] = new ItemDef { Id = (ushort)id, Name = name, Tile = tile, Food = food, Sat = sat };

        static void Armor(ItemId id, string name, int tile, int slot, int pts, int dur, int tier) =>
            items[(ushort)id] = new ItemDef { Id = (ushort)id, Name = name, Tile = tile, MaxStack = 1, ArmorSlot = slot, ArmorPts = pts, Durability = dur, Tier = tier };

        public static System.Collections.Generic.List<ushort> AllIds() { var l = new System.Collections.Generic.List<ushort>(items.Keys); l.Sort(); return l; }

        public static string Category(ushort id)
        {
            var d = Get(id); if (d == null) return "Materials";
            if (d.ArmorSlot >= 0) return "Armor";
            if (d.Tool == ToolType.Sword) return "Weapons";
            if (d.Tool != ToolType.None) return "Tools";
            return d.Food > 0 ? "Food" : "Materials";
        }

        static void One(ItemId id, string name, int tile) =>
            items[(ushort)id] = new ItemDef { Id = (ushort)id, Name = name, Tile = tile, MaxStack = 1 };

        static void Reg(ItemId id, string name, int tile) =>
            items[(ushort)id] = new ItemDef { Id = (ushort)id, Name = name, Tile = tile };

        static void Tool(ItemId id, string name, int tile, ToolType type, int tier) =>
            items[(ushort)id] = new ItemDef { Id = (ushort)id, Name = name, Tile = tile, MaxStack = 1, Tool = type, Tier = tier,
                Speed = type == ToolType.Sword ? 1f : (tier == 0 ? 2f : tier == 1 ? 4f : tier == 2 ? 6f : 8f), Durability = tier == 0 ? 59 : tier == 1 ? 131 : tier == 2 ? 250 : 1561 };

        public static ItemDef Get(ushort id) => items.TryGetValue(id, out var d) ? d : null;
        public static string Name(ushort id) => id >= FirstItem ? (Get(id)?.Name ?? "?") : BlockDatabase.Get(id).Name;
        public static int IconTile(ushort id) => id >= FirstItem ? (Get(id)?.Tile ?? 0) : (BlockDatabase.Get(id).Icon >= 0 ? BlockDatabase.Get(id).Icon : BlockDatabase.Get(id).TexSide);
        public static int MaxStack(ushort id) => Get(id)?.MaxStack ?? 64;
    }
}
