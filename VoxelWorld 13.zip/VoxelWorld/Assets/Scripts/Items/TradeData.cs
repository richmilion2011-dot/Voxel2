namespace VoxelWorld.Items
{
    public struct Trade
    {
        public ushort cost; public int costN; public ushort res; public int resN;
        public Trade(ushort c, int cn, ushort r, int rn) { cost = c; costN = cn; res = r; resN = rn; }
    }

    /// Торговля жителей. Валюта — изумруды (из сундуков подземелий и продажи товаров жителям).
    public static class TradeData
    {
        static readonly string[] names = { "Farmer", "Toolsmith", "Butcher" };
        static readonly Trade[][] list =
        {
            new[] { new Trade((ushort)ItemId.Wheat, 20, (ushort)ItemId.Emerald, 1), new Trade((ushort)ItemId.Emerald, 1, (ushort)ItemId.Bread, 4),
                    new Trade((ushort)ItemId.Emerald, 1, (ushort)ItemId.WheatSeeds, 8), new Trade((ushort)ItemId.Emerald, 4, (ushort)ItemId.IronHoe, 1) },
            new[] { new Trade((ushort)ItemId.Coal, 15, (ushort)ItemId.Emerald, 1), new Trade((ushort)ItemId.IronIngot, 4, (ushort)ItemId.Emerald, 1),
                    new Trade((ushort)ItemId.Emerald, 3, (ushort)ItemId.IronPickaxe, 1), new Trade((ushort)ItemId.Emerald, 4, (ushort)ItemId.IronSword, 1) },
            new[] { new Trade((ushort)ItemId.RawBeef, 10, (ushort)ItemId.Emerald, 1), new Trade((ushort)ItemId.Emerald, 1, (ushort)ItemId.CookedBeef, 4),
                    new Trade((ushort)ItemId.Emerald, 1, (ushort)ItemId.Apple, 3) }
        };
        public static Trade[] For(int p) => list[p % 3];
        public static string Name(int p) => names[p % 3];
    }
}
