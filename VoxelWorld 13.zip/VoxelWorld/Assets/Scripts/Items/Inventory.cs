namespace VoxelWorld.Items
{
    public struct ItemStack
    {
        public ushort id; public int count; public int dur;
        public bool Empty => id == 0 || count <= 0;
    }

    /// 36 слотов: 0-8 хотбар, 9-35 основной инвентарь.
    public class Inventory
    {
        public const int Hotbar = 9, Size = 36, MaxStack = 64;
        public readonly ItemStack[] slots = new ItemStack[Size];

        /// Возвращает, сколько предметов не поместилось.
        public int Add(ushort id, int n, int dur = 0)
        {
            for (int i = 0; i < Size && n > 0; i++)
                if (!slots[i].Empty && slots[i].id == id && slots[i].count < ItemDatabase.MaxStack(id))
                {
                    int m = System.Math.Min(n, ItemDatabase.MaxStack(id) - slots[i].count);
                    slots[i].count += m; n -= m;
                }
            for (int i = 0; i < Size && n > 0; i++)
                if (slots[i].Empty)
                {
                    int m = System.Math.Min(n, ItemDatabase.MaxStack(id));
                    slots[i] = new ItemStack { id = id, count = m, dur = dur }; n -= m;
                }
            return n;
        }

        public readonly ItemStack[] armor = new ItemStack[4];
        public readonly ItemStack[] off = new ItemStack[1];

        public int ArmorPoints()
        {
            int p = 0;
            foreach (var a in armor) if (!a.Empty) p += ItemDatabase.Get(a.id)?.ArmorPts ?? 0;
            return p;
        }

        public void DamageArmor()
        {
            for (int i = 0; i < 4; i++) { if (armor[i].Empty) continue; if (--armor[i].dur <= 0) armor[i] = default; }
        }

        /// Сортировка основного инвентаря (слоты 9-35): объединяет стопки и упорядочивает по id.
        public void Sort()
        {
            var list = new System.Collections.Generic.List<ItemStack>();
            for (int i = Hotbar; i < Size; i++) if (!slots[i].Empty) { list.Add(slots[i]); slots[i] = default; }
            var merged = new System.Collections.Generic.List<ItemStack>();
            foreach (var s0 in list)
            {
                var s = s0; int mx = ItemDatabase.MaxStack(s.id);
                if (mx > 1)
                    for (int k = 0; k < merged.Count && s.count > 0; k++)
                        if (merged[k].id == s.id && merged[k].count < mx)
                        { var m = merged[k]; int mv = System.Math.Min(s.count, mx - m.count); m.count += mv; merged[k] = m; s.count -= mv; }
                if (s.count > 0) merged.Add(s);
            }
            merged.Sort((a, b) => a.id != b.id ? a.id.CompareTo(b.id) : b.count.CompareTo(a.count));
            for (int i = 0; i < merged.Count; i++) slots[Hotbar + i] = merged[i];
        }

        public int Count(ushort id)
        {
            int c = 0;
            foreach (var s in slots) if (!s.Empty && s.id == id) c += s.count;
            return c;
        }

        public bool Remove(ushort id, int n)
        {
            if (Count(id) < n) return false;
            for (int i = 0; i < Size && n > 0; i++)
                if (!slots[i].Empty && slots[i].id == id)
                {
                    int m = System.Math.Min(n, slots[i].count);
                    slots[i].count -= m; n -= m;
                    if (slots[i].count <= 0) slots[i] = default;
                }
            return true;
        }

        public bool TakeOne(int i)
        {
            if (slots[i].Empty) return false;
            if (--slots[i].count <= 0) slots[i] = default;
            return true;
        }

        /// Клик по слоту с предметом "в руке": взять, положить, объединить или обменять.
        public void Click(int i, ref ItemStack held) => ClickSlot(slots, i, ref held);

        public static void ClickSlot(ItemStack[] slots, int i, ref ItemStack held)
        {
            if (held.Empty) { held = slots[i]; slots[i] = default; }
            else if (slots[i].Empty) { slots[i] = held; held = default; }
            else if (slots[i].id == held.id && ItemDatabase.MaxStack(held.id) > 1)
            {
                int m = System.Math.Min(held.count, ItemDatabase.MaxStack(held.id) - slots[i].count);
                slots[i].count += m; held.count -= m;
                if (held.count <= 0) held = default;
            }
            else { var tmp = slots[i]; slots[i] = held; held = tmp; }
        }
    }
}
