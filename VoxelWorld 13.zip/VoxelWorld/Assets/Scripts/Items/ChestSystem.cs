using System.Collections.Generic;
using UnityEngine;
using VoxelWorld.Blocks;
using VoxelWorld.Save;

namespace VoxelWorld.Items
{
    /// Сундуки мира (27 слотов). Сундук подземелья (LootChest) при первом открытии наполняется добычей.
    public class ChestSystem : MonoBehaviour
    {
        public int seed;
        readonly Dictionary<Vector3Int, ItemStack[]> map = new Dictionary<Vector3Int, ItemStack[]>();
        static readonly (ushort id, int min, int max)[] Loot =
        {
            ((ushort)ItemId.Coal, 2, 6), ((ushort)ItemId.RawIron, 1, 4), ((ushort)ItemId.IronIngot, 1, 3), ((ushort)ItemId.Apple, 1, 3),
            ((ushort)ItemId.CookedBeef, 1, 3), ((ushort)ItemId.Stick, 2, 6), ((ushort)BlockId.Planks, 4, 12),
            ((ushort)BlockId.Cobblestone, 8, 20), ((ushort)ItemId.Emerald, 1, 3), ((ushort)ItemId.Flint, 1, 3), ((ushort)ItemId.Diamond, 1, 2), ((ushort)ItemId.StonePickaxe, 1, 1), ((ushort)ItemId.IronSword, 1, 1)
        };

        public ItemStack[] GetOrCreate(Vector3Int p, bool loot)
        {
            if (!map.TryGetValue(p, out var a))
            {
                a = new ItemStack[27];
                if (loot) Fill(a, p);
                map[p] = a;
            }
            return a;
        }

        void Fill(ItemStack[] a, Vector3Int p)
        {
            var r = new System.Random(p.x * 73856093 ^ p.y * 19349663 ^ p.z * 83492791 ^ seed);
            int n = 4 + r.Next(5);
            for (int i = 0; i < n; i++)
            {
                var l = Loot[r.Next(Loot.Length)]; int slot = r.Next(27);
                if (!a[slot].Empty) continue;
                a[slot] = new ItemStack { id = l.id, count = r.Next(l.min, l.max + 1), dur = ItemDatabase.Get(l.id)?.Durability ?? 0 };
            }
        }

        public void Remove(Vector3Int p, Inventory inv)
        {
            if (!map.TryGetValue(p, out var a)) return;
            foreach (var s in a) if (!s.Empty) inv.Add(s.id, s.count, s.dur);
            map.Remove(p);
        }

        public ChestData[] Export()
        {
            var list = new List<ChestData>();
            foreach (var kv in map) list.Add(new ChestData { x = kv.Key.x, y = kv.Key.y, z = kv.Key.z, slots = WorldSaver.ToData(kv.Value) });
            return list.ToArray();
        }

        public void Import(ChestData[] arr)
        {
            map.Clear();
            if (arr == null) return;
            foreach (var d in arr)
            {
                var a = new ItemStack[27];
                for (int i = 0; i < 27 && d.slots != null && i < d.slots.Length; i++) a[i] = WorldSaver.FromData(d.slots[i]);
                map[new Vector3Int(d.x, d.y, d.z)] = a;
            }
        }
    }
}
