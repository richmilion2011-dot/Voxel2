using System.Collections.Generic;
using VoxelWorld.Blocks;

namespace VoxelWorld.Items
{
    public class Recipe { public int W, H; public ushort[] cells; public ushort result; public int count; }

    /// Рецепты по форме (как в классических песочницах), с зеркальным отражением. Сетка 2x2 или 3x3.
    public static class CraftingSystem
    {
        static readonly List<Recipe> recipes = new List<Recipe>();

        static CraftingSystem()
        {
            ushort L = (ushort)BlockId.OakLog, P = (ushort)BlockId.Planks, C = (ushort)BlockId.Cobblestone, S = (ushort)ItemId.Stick;
            Add((ushort)BlockId.Planks, 4, new[] { "L" }, ('L', L));
            Add((ushort)ItemId.Stick, 4, new[] { "P", "P" }, ('P', P));
            Add((ushort)BlockId.CraftingTable, 1, new[] { "PP", "PP" }, ('P', P));
            Tools(P, S, ItemId.WoodPickaxe, ItemId.WoodAxe, ItemId.WoodShovel, ItemId.WoodSword);
            Tools(C, S, ItemId.StonePickaxe, ItemId.StoneAxe, ItemId.StoneShovel, ItemId.StoneSword);
            Tools((ushort)ItemId.IronIngot, S, ItemId.IronPickaxe, ItemId.IronAxe, ItemId.IronShovel, ItemId.IronSword);
            ushort D = (ushort)ItemId.Diamond, IG = (ushort)ItemId.IronIngot;
            Tools(D, S, ItemId.DiamondPickaxe, ItemId.DiamondAxe, ItemId.DiamondShovel, ItemId.DiamondSword);
            Add((ushort)ItemId.DiamondHoe, 1, new[] { "MM", " S", " S" }, ('M', D), ('S', S));
            Armors(IG, ItemId.IronHelmet, ItemId.IronChestplate, ItemId.IronLeggings, ItemId.IronBoots);
            Armors(D, ItemId.DiamondHelmet, ItemId.DiamondChestplate, ItemId.DiamondLeggings, ItemId.DiamondBoots);
            Add((ushort)BlockId.BirchPlanks, 4, new[] { "L" }, ('L', (ushort)BlockId.BirchLog)); Add((ushort)BlockId.SprucePlanks, 4, new[] { "L" }, ('L', (ushort)BlockId.SpruceLog));
            Add((ushort)BlockId.JunglePlanks, 4, new[] { "L" }, ('L', (ushort)BlockId.JungleLog)); Add((ushort)BlockId.AcaciaPlanks, 4, new[] { "L" }, ('L', (ushort)BlockId.AcaciaLog));
            Add((ushort)BlockId.DarkOakPlanks, 4, new[] { "L" }, ('L', (ushort)BlockId.DarkOakLog));
            Storage(BlockId.IronBlock, IG); Storage(BlockId.GoldBlock, (ushort)ItemId.GoldIngot); Storage(BlockId.DiamondBlock, D); Storage(BlockId.CoalBlock, (ushort)ItemId.Coal);
            Add((ushort)BlockId.StoneBricks, 4, new[] { "SS", "SS" }, ('S', (ushort)BlockId.Stone));
            Add((ushort)BlockId.Sandstone, 1, new[] { "SS", "SS" }, ('S', (ushort)BlockId.Sand));
            Add((ushort)BlockId.Bricks, 4, new[] { "TT", "TT" }, ('T', (ushort)BlockId.Terracotta));
            ushort CoalI = (ushort)ItemId.Coal, GlassB = (ushort)BlockId.Glass;
            Add((ushort)BlockId.Torch, 4, new[] { "C", "S" }, ('C', CoalI), ('S', S));
            Add((ushort)BlockId.Ladder, 3, new[] { "S S", "SSS", "S S" }, ('S', S));
            Add((ushort)BlockId.Rail, 16, new[] { "I I", "ISI", "I I" }, ('I', IG), ('S', S));
            Add((ushort)ItemId.Bucket, 1, new[] { "I I", " I " }, ('I', IG));
            Add((ushort)ItemId.Minecart, 1, new[] { "I I", "III" }, ('I', IG));
            Add((ushort)BlockId.GlassPane, 16, new[] { "GGG", "GGG" }, ('G', GlassB));
            Add((ushort)BlockId.OakSlab, 6, new[] { "PPP" }, ('P', (ushort)BlockId.Planks));
            Add((ushort)BlockId.OakStairs0, 4, new[] { "P  ", "PP ", "PPP" }, ('P', (ushort)BlockId.Planks));
            Add((ushort)BlockId.SpruceSlab, 6, new[] { "PPP" }, ('P', (ushort)BlockId.SprucePlanks));
            Add((ushort)BlockId.SpruceStairs0, 4, new[] { "P  ", "PP ", "PPP" }, ('P', (ushort)BlockId.SprucePlanks));
            Add((ushort)BlockId.BirchSlab, 6, new[] { "PPP" }, ('P', (ushort)BlockId.BirchPlanks));
            Add((ushort)BlockId.BirchStairs0, 4, new[] { "P  ", "PP ", "PPP" }, ('P', (ushort)BlockId.BirchPlanks));
            Add((ushort)BlockId.JungleSlab, 6, new[] { "PPP" }, ('P', (ushort)BlockId.JunglePlanks));
            Add((ushort)BlockId.JungleStairs0, 4, new[] { "P  ", "PP ", "PPP" }, ('P', (ushort)BlockId.JunglePlanks));
            Add((ushort)BlockId.AcaciaSlab, 6, new[] { "PPP" }, ('P', (ushort)BlockId.AcaciaPlanks));
            Add((ushort)BlockId.AcaciaStairs0, 4, new[] { "P  ", "PP ", "PPP" }, ('P', (ushort)BlockId.AcaciaPlanks));
            Add((ushort)BlockId.DarkOakSlab, 6, new[] { "PPP" }, ('P', (ushort)BlockId.DarkOakPlanks));
            Add((ushort)BlockId.DarkOakStairs0, 4, new[] { "P  ", "PP ", "PPP" }, ('P', (ushort)BlockId.DarkOakPlanks));
            Add((ushort)BlockId.CobbleSlab, 6, new[] { "PPP" }, ('P', (ushort)BlockId.Cobblestone));
            Add((ushort)BlockId.CobbleStairs0, 4, new[] { "P  ", "PP ", "PPP" }, ('P', (ushort)BlockId.Cobblestone));
            Add((ushort)BlockId.StoneSlab, 6, new[] { "PPP" }, ('P', (ushort)BlockId.Stone));
            Add((ushort)BlockId.StoneStairs0, 4, new[] { "P  ", "PP ", "PPP" }, ('P', (ushort)BlockId.Stone));
            Add((ushort)BlockId.StoneBrickSlab, 6, new[] { "PPP" }, ('P', (ushort)BlockId.StoneBricks));
            Add((ushort)BlockId.StoneBrickStairs0, 4, new[] { "P  ", "PP ", "PPP" }, ('P', (ushort)BlockId.StoneBricks));
            Add((ushort)BlockId.BrickSlab, 6, new[] { "PPP" }, ('P', (ushort)BlockId.Bricks));
            Add((ushort)BlockId.BrickStairs0, 4, new[] { "P  ", "PP ", "PPP" }, ('P', (ushort)BlockId.Bricks));
            Add((ushort)BlockId.SandstoneSlab, 6, new[] { "PPP" }, ('P', (ushort)BlockId.Sandstone));
            Add((ushort)BlockId.SandstoneStairs0, 4, new[] { "P  ", "PP ", "PPP" }, ('P', (ushort)BlockId.Sandstone));
            Add((ushort)BlockId.NetherBrickSlab, 6, new[] { "PPP" }, ('P', (ushort)BlockId.NetherBricks));
            Add((ushort)BlockId.NetherBrickStairs0, 4, new[] { "P  ", "PP ", "PPP" }, ('P', (ushort)BlockId.NetherBricks));
            Add((ushort)BlockId.OakFence, 3, new[] { "PSP", "PSP" }, ('P', (ushort)BlockId.Planks), ('S', S));
            Add((ushort)BlockId.SpruceFence, 3, new[] { "PSP", "PSP" }, ('P', (ushort)BlockId.SprucePlanks), ('S', S));
            Add((ushort)BlockId.BirchFence, 3, new[] { "PSP", "PSP" }, ('P', (ushort)BlockId.BirchPlanks), ('S', S));
            Add((ushort)BlockId.JungleFence, 3, new[] { "PSP", "PSP" }, ('P', (ushort)BlockId.JunglePlanks), ('S', S));
            Add((ushort)BlockId.AcaciaFence, 3, new[] { "PSP", "PSP" }, ('P', (ushort)BlockId.AcaciaPlanks), ('S', S));
            Add((ushort)BlockId.DarkOakFence, 3, new[] { "PSP", "PSP" }, ('P', (ushort)BlockId.DarkOakPlanks), ('S', S));
            Add((ushort)BlockId.OakDoor, 3, new[] { "PP", "PP", "PP" }, ('P', (ushort)BlockId.Planks));
            Add((ushort)BlockId.OakTrapdoor, 2, new[] { "PPP", "PPP" }, ('P', (ushort)BlockId.Planks));
            Add((ushort)BlockId.OakFenceGate, 1, new[] { "SPS", "SPS" }, ('P', (ushort)BlockId.Planks), ('S', S));
            Add((ushort)BlockId.SpruceDoor, 3, new[] { "PP", "PP", "PP" }, ('P', (ushort)BlockId.SprucePlanks));
            Add((ushort)BlockId.SpruceTrapdoor, 2, new[] { "PPP", "PPP" }, ('P', (ushort)BlockId.SprucePlanks));
            Add((ushort)BlockId.SpruceFenceGate, 1, new[] { "SPS", "SPS" }, ('P', (ushort)BlockId.SprucePlanks), ('S', S));
            Add((ushort)BlockId.BirchDoor, 3, new[] { "PP", "PP", "PP" }, ('P', (ushort)BlockId.BirchPlanks));
            Add((ushort)BlockId.BirchTrapdoor, 2, new[] { "PPP", "PPP" }, ('P', (ushort)BlockId.BirchPlanks));
            Add((ushort)BlockId.BirchFenceGate, 1, new[] { "SPS", "SPS" }, ('P', (ushort)BlockId.BirchPlanks), ('S', S));
            Add((ushort)BlockId.JungleDoor, 3, new[] { "PP", "PP", "PP" }, ('P', (ushort)BlockId.JunglePlanks));
            Add((ushort)BlockId.JungleTrapdoor, 2, new[] { "PPP", "PPP" }, ('P', (ushort)BlockId.JunglePlanks));
            Add((ushort)BlockId.JungleFenceGate, 1, new[] { "SPS", "SPS" }, ('P', (ushort)BlockId.JunglePlanks), ('S', S));
            Add((ushort)BlockId.AcaciaDoor, 3, new[] { "PP", "PP", "PP" }, ('P', (ushort)BlockId.AcaciaPlanks));
            Add((ushort)BlockId.AcaciaTrapdoor, 2, new[] { "PPP", "PPP" }, ('P', (ushort)BlockId.AcaciaPlanks));
            Add((ushort)BlockId.AcaciaFenceGate, 1, new[] { "SPS", "SPS" }, ('P', (ushort)BlockId.AcaciaPlanks), ('S', S));
            Add((ushort)BlockId.DarkOakDoor, 3, new[] { "PP", "PP", "PP" }, ('P', (ushort)BlockId.DarkOakPlanks));
            Add((ushort)BlockId.DarkOakTrapdoor, 2, new[] { "PPP", "PPP" }, ('P', (ushort)BlockId.DarkOakPlanks));
            Add((ushort)BlockId.DarkOakFenceGate, 1, new[] { "SPS", "SPS" }, ('P', (ushort)BlockId.DarkOakPlanks), ('S', S));
            Add((ushort)BlockId.IronDoor, 3, new[] { "II", "II", "II" }, ('I', IG));
            Add((ushort)BlockId.IronTrapdoor, 1, new[] { "II", "II" }, ('I', IG));
            Add((ushort)BlockId.CobbleWall, 6, new[] { "PPP", "PPP" }, ('P', (ushort)BlockId.Cobblestone));
            Add((ushort)BlockId.MossyCobbleWall, 6, new[] { "PPP", "PPP" }, ('P', (ushort)BlockId.MossyCobblestone));
            Add((ushort)BlockId.StoneBrickWall, 6, new[] { "PPP", "PPP" }, ('P', (ushort)BlockId.StoneBricks));
            Add((ushort)BlockId.BrickWall, 6, new[] { "PPP", "PPP" }, ('P', (ushort)BlockId.Bricks));
            Add((ushort)BlockId.SandstoneWall, 6, new[] { "PPP", "PPP" }, ('P', (ushort)BlockId.Sandstone));
            Add((ushort)BlockId.NetherBrickWall, 6, new[] { "PPP", "PPP" }, ('P', (ushort)BlockId.NetherBricks));
            Storage(BlockId.LapisBlock, (ushort)ItemId.Lapis); Storage(BlockId.RedstoneBlock, (ushort)ItemId.Redstone); Storage(BlockId.EmeraldBlock, (ushort)ItemId.Emerald);
            Add((ushort)BlockId.BambooPlanks, 4, new[] { "L" }, ('L', (ushort)BlockId.BambooBlock)); Add((ushort)BlockId.MangrovePlanks, 4, new[] { "L" }, ('L', (ushort)BlockId.MangroveLog));
            Add((ushort)BlockId.CherryPlanks, 4, new[] { "L" }, ('L', (ushort)BlockId.CherryLog)); Add((ushort)BlockId.CrimsonPlanks, 4, new[] { "L" }, ('L', (ushort)BlockId.CrimsonStem)); Add((ushort)BlockId.WarpedPlanks, 4, new[] { "L" }, ('L', (ushort)BlockId.WarpedStem));
            Add((ushort)BlockId.PolishedGranite, 4, new[] { "SS", "SS" }, ('S', (ushort)BlockId.Granite)); Add((ushort)BlockId.PolishedDiorite, 4, new[] { "SS", "SS" }, ('S', (ushort)BlockId.Diorite)); Add((ushort)BlockId.PolishedAndesite, 4, new[] { "SS", "SS" }, ('S', (ushort)BlockId.Andesite));
            Add((ushort)BlockId.QuartzBlock, 1, new[] { "QQ", "QQ" }, ('Q', (ushort)ItemId.Quartz)); Add((ushort)BlockId.HayBale, 1, new[] { "WWW", "WWW", "WWW" }, ('W', (ushort)ItemId.Wheat));
            Add((ushort)ItemId.FlintAndSteel, 1, new[] { "I", "F" }, ('I', IG), ('F', (ushort)ItemId.Flint));
            Add((ushort)ItemId.EyeOfEnder, 1, new[] { "D", "G" }, ('D', D), ('G', (ushort)ItemId.Gunpowder));
            ushort Wh = (ushort)ItemId.Wheat;
            Add((ushort)ItemId.WoodHoe, 1, new[] { "MM", " S", " S" }, ('M', P), ('S', S));
            Add((ushort)ItemId.StoneHoe, 1, new[] { "MM", " S", " S" }, ('M', C), ('S', S));
            Add((ushort)ItemId.IronHoe, 1, new[] { "MM", " S", " S" }, ('M', (ushort)ItemId.IronIngot), ('S', S));
            Add((ushort)ItemId.Bread, 1, new[] { "WWW" }, ('W', Wh));
            Add((ushort)BlockId.Bed, 1, new[] { "WWW", "PPP" }, ('W', Wh), ('P', P));
            Add((ushort)BlockId.Chest, 1, new[] { "PPP", "P P", "PPP" }, ('P', P));
            Add((ushort)BlockId.Furnace, 1, new[] { "CCC", "C C", "CCC" }, ('C', C));
        }

        static void Armors(ushort m, ItemId h, ItemId c, ItemId l, ItemId b)
        {
            Add((ushort)h, 1, new[] { "MMM", "M M" }, ('M', m));
            Add((ushort)c, 1, new[] { "M M", "MMM", "MMM" }, ('M', m));
            Add((ushort)l, 1, new[] { "MMM", "M M", "M M" }, ('M', m));
            Add((ushort)b, 1, new[] { "M M", "M M" }, ('M', m));
        }

        static void Storage(BlockId block, ushort item)
        {
            Add((ushort)block, 1, new[] { "MMM", "MMM", "MMM" }, ('M', item));
            Add(item, 9, new[] { "B" }, ('B', (ushort)block));
        }

        static void Tools(ushort m, ushort s, ItemId pick, ItemId axe, ItemId shovel, ItemId sword)
        {
            Add((ushort)pick, 1, new[] { "MMM", " S ", " S " }, ('M', m), ('S', s));
            Add((ushort)axe, 1, new[] { "MM", "MS", " S" }, ('M', m), ('S', s));
            Add((ushort)shovel, 1, new[] { "M", "S", "S" }, ('M', m), ('S', s));
            Add((ushort)sword, 1, new[] { "M", "M", "S" }, ('M', m), ('S', s));
        }

        static void Add(ushort result, int count, string[] pat, params (char, ushort)[] key)
        {
            int w = 0; foreach (var r in pat) w = System.Math.Max(w, r.Length);
            var cells = new ushort[w * pat.Length];
            for (int y = 0; y < pat.Length; y++)
                for (int x = 0; x < w; x++)
                {
                    char c = x < pat[y].Length ? pat[y][x] : ' ';
                    if (c == ' ') continue;
                    foreach (var k in key) if (k.Item1 == c) cells[y * w + x] = k.Item2;
                }
            recipes.Add(new Recipe { W = w, H = pat.Length, cells = cells, result = result, count = count });
        }

        public static Recipe Find(ItemStack[] grid, int gw)
        {
            int minx = gw, miny = gw, maxx = -1, maxy = -1;
            for (int y = 0; y < gw; y++)
                for (int x = 0; x < gw; x++)
                    if (!grid[y * gw + x].Empty)
                    { minx = System.Math.Min(minx, x); miny = System.Math.Min(miny, y); maxx = System.Math.Max(maxx, x); maxy = System.Math.Max(maxy, y); }
            if (maxx < 0) return null;
            int w = maxx - minx + 1, h = maxy - miny + 1;
            foreach (var r in recipes)
                if (r.W == w && r.H == h && (Check(r, grid, gw, minx, miny, false) || Check(r, grid, gw, minx, miny, true))) return r;
            return null;
        }

        static bool Check(Recipe r, ItemStack[] grid, int gw, int minx, int miny, bool mirror)
        {
            for (int y = 0; y < r.H; y++)
                for (int x = 0; x < r.W; x++)
                {
                    ushort want = r.cells[y * r.W + (mirror ? r.W - 1 - x : x)];
                    var g = grid[(miny + y) * gw + minx + x];
                    if (want != (g.Empty ? (ushort)0 : g.id)) return false;
                }
            return true;
        }
    }
}
