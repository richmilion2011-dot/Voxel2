using UnityEngine;
using VoxelWorld.Core;
using VoxelWorld.Items;

namespace VoxelWorld.Gameplay
{
    /// Босс Края: кружит над островом, периодически пикирует на игрока (6 урона). Награда — 8 алмазов. Если победить, больше не появляется.
    public class EnderDragon : MonoBehaviour
    {
        public static EnderDragon Instance;
        public float hp = 200f; const float Max = 200f;
        Transform player; SurvivalSystem sv; Transform wingL, wingR;
        float ang, chargeT = 12f, chargeLeft, hitCd; Vector3 vel; static Mesh cube;

        public static void Spawn(Transform player, SurvivalSystem sv)
        {
            var g = new GameObject("EnderDragon"); g.transform.position = new Vector3(0, 90, 40);
            var d = g.AddComponent<EnderDragon>(); d.player = player; d.sv = sv; d.Build(); Instance = d;
        }

        Transform Part(Transform p, Vector3 pos, Vector3 size, Color c)
        {
            var o = new GameObject("p"); o.transform.SetParent(p, false); o.transform.localPosition = pos; o.transform.localScale = size;
            o.AddComponent<MeshFilter>().sharedMesh = cube;
            o.AddComponent<MeshRenderer>().sharedMaterial = new Material(Shader.Find("VoxelWorld/ColorUnlit")) { color = c };
            return o.transform;
        }

        void Build()
        {
            if (cube == null) { var g = GameObject.CreatePrimitive(PrimitiveType.Cube); cube = g.GetComponent<MeshFilter>().sharedMesh; Destroy(g); }
            Color dk = new Color(0.1f, 0.08f, 0.14f), md = new Color(0.2f, 0.16f, 0.26f), eye = new Color(0.85f, 0.2f, 0.95f);
            Part(transform, Vector3.zero, new Vector3(3f, 2f, 6f), dk);
            Part(transform, new Vector3(0, 0.3f, 4f), new Vector3(1.2f, 1.2f, 2.5f), md);
            Part(transform, new Vector3(0, 0.4f, 6f), new Vector3(1.6f, 1.3f, 2f), dk);
            Part(transform, new Vector3(-0.5f, 0.7f, 7.02f), new Vector3(0.3f, 0.3f, 0.05f), eye); Part(transform, new Vector3(0.5f, 0.7f, 7.02f), new Vector3(0.3f, 0.3f, 0.05f), eye);
            Part(transform, new Vector3(0, 0, -5.5f), new Vector3(1f, 1f, 5f), md); Part(transform, new Vector3(0, 0.2f, -9f), new Vector3(0.6f, 0.6f, 3f), dk);
            wingL = new GameObject("wl").transform; wingL.SetParent(transform, false); wingL.localPosition = new Vector3(-1.5f, 0.8f, 0.5f);
            wingR = new GameObject("wr").transform; wingR.SetParent(transform, false); wingR.localPosition = new Vector3(1.5f, 0.8f, 0.5f);
            Part(wingL, new Vector3(-4.5f, 0, 0), new Vector3(9f, 0.3f, 3.5f), md); Part(wingR, new Vector3(4.5f, 0, 0), new Vector3(9f, 0.3f, 3.5f), md);
            var bc = gameObject.AddComponent<BoxCollider>(); bc.center = new Vector3(0, 0.3f, 1f); bc.size = new Vector3(3.5f, 2.5f, 9f);
        }

        void Update()
        {
            if (player == null) { Destroy(gameObject); return; }
            float dt = Time.deltaTime; hitCd -= dt; chargeT -= dt;
            Vector3 center = new Vector3(0, 85, 0), tgt;
            float speed = 14f;
            if (chargeLeft > 0f) { chargeLeft -= dt; tgt = player.position + Vector3.up; speed = 24f; }
            else
            {
                ang += 0.35f * dt;
                tgt = center + new Vector3(Mathf.Cos(ang) * 28f, Mathf.Sin(ang * 2f) * 6f, Mathf.Sin(ang) * 28f);
                if (chargeT <= 0f) { chargeT = 14f; chargeLeft = 3f; }
            }
            Vector3 nv = (tgt - transform.position).normalized * speed;
            vel = Vector3.Lerp(vel, nv, 2f * dt);
            transform.position += vel * dt;
            if (vel.sqrMagnitude > 1f) transform.rotation = Quaternion.Slerp(transform.rotation, Quaternion.LookRotation(vel), 3f * dt);
            float fl = Mathf.Sin(Time.time * 3f) * 20f;
            wingL.localRotation = Quaternion.Euler(0, 0, fl); wingR.localRotation = Quaternion.Euler(0, 0, -fl);
            if (hitCd <= 0f && (transform.position - (player.position + Vector3.up)).sqrMagnitude < 3.6f * 3.6f) { hitCd = 1.5f; sv.Damage(6f); }
        }

        public void Hurt(float d)
        {
            hp -= d; vel *= 0.3f;
            if (hp > 0f) return;
            GameSession.DragonDead = true;
            MobManager.Instance?.inv.Add((ushort)ItemId.Diamond, 8);
            Instance = null; Destroy(gameObject);
        }

        void OnGUI()
        {
            if (hp <= 0f) return;
            float w = Screen.width * 0.4f, x = (Screen.width - w) / 2f, y = Screen.height * 0.04f;
            GUI.color = new Color(0, 0, 0, 0.6f); GUI.DrawTexture(new Rect(x - 2, y - 2, w + 4, 16), Texture2D.whiteTexture);
            GUI.color = new Color(0.8f, 0.2f, 0.9f); GUI.DrawTexture(new Rect(x, y, w * Mathf.Clamp01(hp / Max), 12), Texture2D.whiteTexture);
            GUI.color = Color.white; GUI.Label(new Rect(x, y + 14, w, 24), "Ender Dragon");
        }

        void OnDestroy() { if (Instance == this) Instance = null; }
    }
}
