using UnityEngine;
using VoxelWorld.Audio;
using VoxelWorld.Blocks;
using VoxelWorld.Core;

namespace VoxelWorld.Gameplay
{
    public enum MobType { Cow, Zombie, Villager, Pig, Sheep, Chicken, Spider, Creeper, Pigman, Enderman }

    /// Простой ИИ: корова бродит и убегает при ударе, зомби преследует и бьёт; днём зомби горят.
    [RequireComponent(typeof(CharacterController))]
    public class Mob : MonoBehaviour
    {
        public MobType type; public float health = 10f, speed = 2f; public bool hostile; public Vector3 home; public int profession;
        public Transform[] legs;
        CharacterController cc; float vy, wanderT, attackCd, fleeT, burnT, phase, idleT = 3f, fuse;
        Vector3 wanderDir, knock;

        void Awake() { cc = GetComponent<CharacterController>(); }

        void Update()
        {
            var mm = MobManager.Instance; float dt = Time.deltaTime;
            if (hostile && GameSession.Difficulty == 0) { Destroy(gameObject); return; }
            Vector3 toP = mm.player.position - transform.position; toP.y = 0;
            float dist = toP.magnitude; Vector3 dir = Vector3.zero;
            idleT -= dt;
            if (idleT <= 0f)
            {
                idleT = Random.Range(6f, 16f);
                if (dist < 24f && AudioManager.I != null && (type == MobType.Cow || type == MobType.Zombie))
                    AudioManager.I.Play(type == MobType.Cow ? AudioManager.I.moo : AudioManager.I.groan, transform.position, 1f, Random.Range(0.9f, 1.15f));
            }

            if (hostile && dist < 18f && !mm.survival.Dead)
            {
                dir = toP.normalized;
                if (type == MobType.Creeper)
                {
                    if (dist < 3f) { dir = Vector3.zero; fuse += dt; if (fuse >= 1.5f) { Explode(); return; } } else fuse = 0f;
                }
                else if (dist < 1.4f)
                {
                    dir = Vector3.zero; attackCd -= dt;
                    if (attackCd <= 0f) { attackCd = 1f; mm.survival.Damage((GameSession.Difficulty == 1 ? 2f : GameSession.Difficulty == 3 ? 4f : 3f) + (type == MobType.Enderman ? 2f : 0f)); }
                }
            }
            else if (fleeT > 0f) { fleeT -= dt; dir = -toP.normalized; }
            else
            {
                wanderT -= dt;
                if (wanderT <= 0f)
                {
                    wanderT = Random.Range(2f, 6f);
                    wanderDir = Random.value < 0.4f ? Vector3.zero : Quaternion.Euler(0, Random.Range(0, 360f), 0) * Vector3.forward;
                }
                dir = wanderDir;
                if (type == MobType.Villager) { Vector3 hv = home - transform.position; hv.y = 0; if (hv.magnitude > 14f) dir = hv.normalized; }
            }

            if (dir.sqrMagnitude > 0.01f)
                transform.rotation = Quaternion.Slerp(transform.rotation, Quaternion.LookRotation(dir), 8f * dt);
            else if (hostile && dist < 18f)
                transform.rotation = Quaternion.Slerp(transform.rotation, Quaternion.LookRotation(toP.normalized), 8f * dt);

            Vector3 move = dir * speed + knock;
            knock = Vector3.Lerp(knock, Vector3.zero, 6f * dt);
            if (cc.isGrounded && vy < 0) vy = -2f;
            vy -= 22f * dt;
            var flags = cc.Move((move + Vector3.up * vy) * dt);
            if ((flags & CollisionFlags.Sides) != 0 && cc.isGrounded && dir.sqrMagnitude > 0.01f) vy = 7f; // перепрыгнуть блок

            phase += move.magnitude * dt * 4f;
            if (legs != null)
                for (int i = 0; i < legs.Length; i++)
                    legs[i].localRotation = Quaternion.Euler(Mathf.Sin(phase) * 40f * (i % 2 == 0 ? 1 : -1) * Mathf.Clamp01(move.magnitude), 0, 0);

            if (type == MobType.Zombie && mm.day.Light > 0.6f) { burnT += dt; if (burnT >= 1f) { burnT = 0; Hurt(2f, transform.position, false); } }
            if (dist > 64f || transform.position.y < -20f) Destroy(gameObject);
        }

        void Teleport()
        {
            var mm = MobManager.Instance;
            for (int i = 0; i < 8; i++)
            {
                Vector2 r = Random.insideUnitCircle.normalized * Random.Range(4f, 9f);
                int x = Mathf.FloorToInt(mm.player.position.x + r.x), z = Mathf.FloorToInt(mm.player.position.z + r.y);
                for (int y = Mathf.FloorToInt(mm.player.position.y) + 6; y > 1; y--)
                    if (mm.world.GetBlockWorld(x, y, z) == 0 && mm.world.GetBlockWorld(x, y + 1, z) == 0 && mm.world.GetBlockWorld(x, y + 2, z) == 0
                        && BlockDatabase.Get(mm.world.GetBlockWorld(x, y - 1, z)).Solid)
                    { cc.enabled = false; transform.position = new Vector3(x + 0.5f, y, z + 0.5f); cc.enabled = true; return; }
            }
        }

        void Explode()
        {
            var mm = MobManager.Instance; Vector3 c = transform.position + Vector3.up;
            mm.world.ExplodeAt(c, 3.2f);
            float d = Vector3.Distance(mm.player.position + Vector3.up, c);
            if (d < 6f) mm.survival.Damage(Mathf.Lerp(14f, 0f, d / 6f));
            AudioManager.I?.Play(AudioManager.I.breakClip, c, 1f, 0.5f);
            Destroy(gameObject);
        }

        public void Hurt(float dmg, Vector3 from, bool byPlayer)
        {
            health -= dmg;
            if (AudioManager.I != null)
                AudioManager.I.Play(type == MobType.Cow ? AudioManager.I.moo : AudioManager.I.hurt, transform.position, 1f, type == MobType.Cow ? 1.3f : 0.6f);
            if (type == MobType.Enderman && health > 0f && Random.value < 0.6f) Teleport();
            Vector3 k = transform.position - from; k.y = 0;
            knock = k.normalized * 6f; vy = 4f;
            if (!hostile) fleeT = 4f;
            if (health <= 0f)
            {
                if (byPlayer) MobManager.Instance.GiveDrops(type);
                Destroy(gameObject);
            }
        }
    }
}
