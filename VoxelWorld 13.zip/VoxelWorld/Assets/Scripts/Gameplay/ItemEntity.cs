using System.Collections.Generic;
using UnityEngine;
using VoxelWorld.Blocks;
using VoxelWorld.Items;
using VoxelWorld.World;

namespace VoxelWorld.Gameplay
{
    /// Выброшенный предмет: падает, вращается, подбирается при приближении игрока.
    public class ItemEntity : MonoBehaviour
    {
        public static ChunkManager World; public static Transform PlayerT; public static Inventory Inv; public static Material Mat;
        public ItemStack stack; Vector3 vel; float age, spin; Transform vis;

        public static void Spawn(ItemStack st, Vector3 pos, Vector3 velocity)
        {
            var g = new GameObject("Item"); g.transform.position = pos;
            var e = g.AddComponent<ItemEntity>(); e.stack = st; e.vel = velocity; e.Build();
        }

        void Build()
        {
            int tile = ItemDatabase.IconTile(stack.id);
            var vs = new List<Vector3>(); var u0 = new List<Vector2>(); var u1 = new List<Vector2>(); var tr = new List<int>();
            foreach (float ang in new[] { 0f, 90f })
                foreach (bool flip in new[] { false, true })
                {
                    var q = Quaternion.Euler(0, ang, 0); int b = vs.Count;
                    vs.Add(q * new Vector3(-0.2f, 0, 0)); vs.Add(q * new Vector3(0.2f, 0, 0)); vs.Add(q * new Vector3(0.2f, 0.4f, 0)); vs.Add(q * new Vector3(-0.2f, 0.4f, 0));
                    u0.Add(new Vector2(0, 0)); u0.Add(new Vector2(1, 0)); u0.Add(new Vector2(1, 1)); u0.Add(new Vector2(0, 1));
                    for (int i = 0; i < 4; i++) u1.Add(new Vector2(tile, 0));
                    if (!flip) { tr.Add(b); tr.Add(b + 1); tr.Add(b + 2); tr.Add(b); tr.Add(b + 2); tr.Add(b + 3); }
                    else { tr.Add(b); tr.Add(b + 2); tr.Add(b + 1); tr.Add(b); tr.Add(b + 3); tr.Add(b + 2); }
                }
            var m = new Mesh(); m.SetVertices(vs); m.SetUVs(0, u0); m.SetUVs(1, u1); m.SetTriangles(tr, 0); m.RecalculateNormals();
            vis = new GameObject("vis").transform; vis.SetParent(transform, false);
            vis.gameObject.AddComponent<MeshFilter>().sharedMesh = m; vis.gameObject.AddComponent<MeshRenderer>().sharedMaterial = Mat;
        }

        void Update()
        {
            float dt = Time.deltaTime; age += dt;
            if (age > 300f) { Destroy(gameObject); return; }
            vel.y -= 20f * dt; vel.x *= 1f - 2f * dt; vel.z *= 1f - 2f * dt;
            Vector3 p = transform.position + vel * dt;
            if (vel.y < 0)
            {
                int by = Mathf.FloorToInt(p.y);
                ushort b = World.GetBlockWorld(Mathf.FloorToInt(p.x), by, Mathf.FloorToInt(p.z));
                if (b != 0 && BlockDatabase.Get(b).Solid) { p.y = by + 1; vel.y = 0; }
            }
            transform.position = p;
            spin += 90f * dt; vis.localRotation = Quaternion.Euler(0, spin, 0);
            vis.localPosition = new Vector3(0, 0.1f + Mathf.Sin(age * 3f) * 0.05f, 0);
            if (age > 0.8f && (PlayerT.position + Vector3.up * 0.9f - p).sqrMagnitude < 3.2f)
            {
                int left = Inv.Add(stack.id, stack.count, stack.dur);
                if (left <= 0) Destroy(gameObject); else stack.count = left;
            }
        }
    }
}
