using System.Collections.Generic;
using UnityEngine;
using VoxelWorld.Blocks;
using VoxelWorld.Core;
using VoxelWorld.Player;
using VoxelWorld.World;

namespace VoxelWorld.Gameplay
{
    /// Зажигание порталов: рамка из обсидиана (минимум 2x3 внутри), кремень и огниво -> портал Незера, Глаз Края -> портал Края.
    public static class PortalSystem
    {
        public static bool TryLight(ChunkManager w, Vector3Int start, ushort portalBlock)
        {
            if (w.GetBlockWorld(start.x, start.y, start.z) != 0) return false;
            for (int axis = 0; axis < 2; axis++)
            {
                var dirs = axis == 0 ? new[] { Vector3Int.right, Vector3Int.left, Vector3Int.up, Vector3Int.down }
                                     : new[] { new Vector3Int(0, 0, 1), new Vector3Int(0, 0, -1), Vector3Int.up, Vector3Int.down };
                var set = new HashSet<Vector3Int> { start }; var q = new Queue<Vector3Int>(); q.Enqueue(start); bool ok = true;
                while (q.Count > 0 && ok)
                {
                    var c = q.Dequeue();
                    foreach (var dd in dirs)
                    {
                        var nx = c + dd; if (set.Contains(nx)) continue;
                        ushort b = w.GetBlockWorld(nx.x, nx.y, nx.z);
                        if (b == 0) { if (set.Count >= 400) { ok = false; break; } set.Add(nx); q.Enqueue(nx); }
                        else if (b != (ushort)BlockId.Obsidian) { ok = false; break; }
                    }
                }
                if (!ok) continue;
                int minU = int.MaxValue, maxU = int.MinValue, minY = int.MaxValue, maxY = int.MinValue;
                foreach (var c in set) { int u = axis == 0 ? c.x : c.z; minU = Mathf.Min(minU, u); maxU = Mathf.Max(maxU, u); minY = Mathf.Min(minY, c.y); maxY = Mathf.Max(maxY, c.y); }
                int ww = maxU - minU + 1, hh = maxY - minY + 1;
                if (ww < 2 || hh < 3 || ww * hh != set.Count) continue;
                foreach (var c in set) w.SetBlockWorld(c.x, c.y, c.z, portalBlock);
                return true;
            }
            return false;
        }
    }

    /// Переходы между измерениями: стоишь в портале 2.5 с — переносит. Порталы-«пара»: при прибытии строится портал (Незер <-> мир, координаты 1:8).
    public class DimensionManager : MonoBehaviour
    {
        public static DimensionManager Instance;
        public ChunkManager world; public PlayerController pc; public Transform player;
        float inPortal; bool pending, build; Vector3 target; int tdim;

        void Awake() { Instance = this; }

        public void GoTo(int dim, Vector3 pos, bool portal)
        {
            foreach (var m in FindObjectsByType<Mob>(FindObjectsSortMode.None)) Destroy(m.gameObject);
            foreach (var it in FindObjectsByType<ItemEntity>(FindObjectsSortMode.None)) Destroy(it.gameObject);
            if (EnderDragon.Instance != null) Destroy(EnderDragon.Instance.gameObject);
            world.SwitchDimension(dim);
            target = pos; tdim = dim; build = portal; pending = true; pc.frozen = true; inPortal = 0f;
            pc.SetPosition(new Vector3(pos.x, 90f, pos.z), player.eulerAngles.y, 0f);
        }

        void Update()
        {
            if (pending)
            {
                if (world.IsMeshed(Mathf.FloorToInt(target.x), Mathf.FloorToInt(target.z))) Arrive();
                return;
            }
            if (GameSession.Dimension == 2 && player.position.y < -20f) { pc.survival.Damage(100f); return; }
            Vector3 p = player.position; int x = Mathf.FloorToInt(p.x), z = Mathf.FloorToInt(p.z), y = Mathf.FloorToInt(p.y + 0.1f);
            ushort a = world.GetBlockWorld(x, y, z), b = world.GetBlockWorld(x, y + 1, z);
            bool nether = a == (ushort)BlockId.Portal || b == (ushort)BlockId.Portal, end = a == (ushort)BlockId.EndPortal || b == (ushort)BlockId.EndPortal;
            if (!nether && !end) { inPortal = 0f; return; }
            inPortal += Time.deltaTime; if (inPortal < 2.5f) return; inPortal = 0f;
            int cur = GameSession.Dimension;
            if (nether) GoTo(cur == 1 ? 0 : 1, cur == 1 ? new Vector3(p.x * 8f, 0, p.z * 8f) : new Vector3(p.x / 8f, 0, p.z / 8f), true);
            else if (cur == 2) GoTo(0, new Vector3(pc.SpawnPoint.x, 0, pc.SpawnPoint.z), false);
            else GoTo(2, new Vector3(6.5f, 66f, 0.5f), false);
        }

        int FindY(int x, int z, int yMax, int yMin)
        {
            for (int y = yMax; y >= yMin; y--)
                if (world.GetBlockWorld(x, y, z) == 0 && world.GetBlockWorld(x, y + 1, z) == 0 && world.GetBlockWorld(x, y + 2, z) == 0)
                {
                    ushort below = world.GetBlockWorld(x, y - 1, z);
                    if (below != 0 && BlockDatabase.Get(below).Solid) return y;
                }
            return -1;
        }

        void Arrive()
        {
            pending = false; int x = Mathf.FloorToInt(target.x), z = Mathf.FloorToInt(target.z); Vector3 pos;
            if (tdim == 2 || (target.y > 0f && !build)) pos = target;
            else
            {
                int y = -1, ox = x, oz = z;
                for (int r = 0; r <= 10 && y < 0; r += 2)
                    for (int dx = -r; dx <= r && y < 0; dx += 2)
                        for (int dz = -r; dz <= r && y < 0; dz += 2)
                        {
                            if (Mathf.Max(Mathf.Abs(dx), Mathf.Abs(dz)) != r || !world.IsMeshed(x + dx, z + dz)) continue;
                            int yy = FindY(x + dx, z + dz, tdim == 1 ? 100 : ChunkData.SizeY - 2, tdim == 1 ? 34 : 2);
                            if (yy > 0) { y = yy; ox = x + dx; oz = z + dz; }
                        }
                if (y < 0) { ox = x; oz = z; y = tdim == 1 ? 70 : 80; }
                if (build) BuildPortal(ox, y, oz);
                pos = new Vector3(ox + 1.0f, y, oz + 2.5f);
            }
            pc.SetPosition(pos, player.eulerAngles.y, 0f);
            pc.frozen = false;
            if (tdim == 2 && !GameSession.DragonDead) EnderDragon.Spawn(player, pc.survival);
        }

        void BuildPortal(int x, int y, int z)
        {
            for (int dx = -6; dx <= 6; dx++) for (int dz = -6; dz <= 6; dz++) for (int dy = -3; dy <= 6; dy++)
                if (world.GetBlockWorld(x + dx, y + dy, z + dz) == (ushort)BlockId.Portal) return;
            var pos = new List<Vector3Int>(); var ids = new List<ushort>();
            for (int dx = -1; dx <= 2; dx++)
                for (int dz = -1; dz <= 3; dz++)
                {
                    if (!BlockDatabase.Get(world.GetBlockWorld(x + dx, y - 1, z + dz)).Solid) { pos.Add(new Vector3Int(x + dx, y - 1, z + dz)); ids.Add((ushort)BlockId.Obsidian); }
                    for (int dy = 0; dy <= 4; dy++) { pos.Add(new Vector3Int(x + dx, y + dy, z + dz)); ids.Add(0); }
                }
            for (int dx = -1; dx <= 2; dx++)
                for (int dy = -1; dy <= 3; dy++)
                {
                    bool frame = dx == -1 || dx == 2 || dy == -1 || dy == 3;
                    pos.Add(new Vector3Int(x + dx, y + dy, z)); ids.Add(frame ? (ushort)BlockId.Obsidian : (ushort)BlockId.Portal);
                }
            world.SetMany(pos, ids);
        }
    }
}
