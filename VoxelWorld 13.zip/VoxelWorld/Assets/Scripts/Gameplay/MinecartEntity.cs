using UnityEngine;
using VoxelWorld.Blocks;
using VoxelWorld.World;

namespace VoxelWorld.Gameplay
{
    /// Вагонетка: едет по прямым рельсам, пока игрок «давит вперёд»; тормозит без нажатия; упирается в конец рельсов.
    public class MinecartEntity : MonoBehaviour
    {
        public static ChunkManager World;
        static Mesh cube;
        float speed;

        public static MinecartEntity Spawn(Vector3 pos)
        {
            var g = new GameObject("Minecart"); g.transform.position = pos;
            var c = g.AddComponent<MinecartEntity>(); c.Build(); return c;
        }

        void Part(Material m, Vector3 pos, Vector3 size)
        {
            var o = new GameObject("p"); o.transform.SetParent(transform, false); o.transform.localPosition = pos; o.transform.localScale = size;
            o.AddComponent<MeshFilter>().sharedMesh = cube; o.AddComponent<MeshRenderer>().sharedMaterial = m;
        }

        void Build()
        {
            if (cube == null) { var g = GameObject.CreatePrimitive(PrimitiveType.Cube); cube = g.GetComponent<MeshFilter>().sharedMesh; Destroy(g); }
            var m = new Material(Shader.Find("VoxelWorld/ColorUnlit")) { color = new Color(0.55f, 0.55f, 0.6f) };
            Part(m, new Vector3(0, 0.15f, 0), new Vector3(0.9f, 0.1f, 0.9f));
            Part(m, new Vector3(0.45f, 0.4f, 0), new Vector3(0.08f, 0.5f, 0.9f)); Part(m, new Vector3(-0.45f, 0.4f, 0), new Vector3(0.08f, 0.5f, 0.9f));
            Part(m, new Vector3(0, 0.4f, 0.45f), new Vector3(0.9f, 0.5f, 0.08f)); Part(m, new Vector3(0, 0.4f, -0.45f), new Vector3(0.9f, 0.5f, 0.08f));
            var bc = gameObject.AddComponent<BoxCollider>(); bc.center = new Vector3(0, 0.35f, 0); bc.size = new Vector3(0.9f, 0.6f, 0.9f);
        }

        static bool IsRail(int x, int y, int z) => World.GetBlockWorld(x, y, z) == (ushort)BlockId.Rail;

        public void Drive(float input, Vector3 look)
        {
            Vector3 pos = transform.position;
            int cx = Mathf.FloorToInt(pos.x), cy = Mathf.FloorToInt(pos.y), cz = Mathf.FloorToInt(pos.z);
            bool ax = IsRail(cx - 1, cy, cz) || IsRail(cx + 1, cy, cz), az = IsRail(cx, cy, cz - 1) || IsRail(cx, cy, cz + 1);
            Vector3 axis = (ax && !az) ? Vector3.right : Vector3.forward;
            float dt = Time.deltaTime;
            if (Mathf.Abs(input) > 0.2f)
            {
                float s = Mathf.Sign(Vector3.Dot(look * Mathf.Sign(input), axis)); if (s == 0f) s = 1f;
                speed = Mathf.MoveTowards(speed, 7f * s, 18f * dt);
            }
            else speed = Mathf.MoveTowards(speed, 0f, 10f * dt);
            Vector3 d = axis * Mathf.Sign(speed); float step = Mathf.Abs(speed) * dt;
            Vector3 ahead = pos + d * (0.5f + step);
            if (step > 0f && !IsRail(Mathf.FloorToInt(ahead.x), cy, Mathf.FloorToInt(ahead.z))) { speed = 0f; step = 0f; }
            pos += d * step;
            if (axis == Vector3.right) pos.z = cz + 0.5f; else pos.x = cx + 0.5f;
            pos.y = cy + 0.0625f;
            transform.position = pos; transform.rotation = Quaternion.LookRotation(axis);
        }
    }
}
