using UnityEngine;
using VoxelWorld.Audio;
using VoxelWorld.Core;

namespace VoxelWorld.Gameplay
{
    /// Здоровье, голод, насыщение, истощение, регенерация, смерть и возрождение + HUD.
    public class SurvivalSystem : MonoBehaviour
    {
        public float health = 20, hunger = 20, saturation = 5, exhaustion;
        public bool creative, Dead;
        public System.Action OnRespawn; public VoxelWorld.Items.Inventory inv;
        float regenT, starveT, flash;

        public void Damage(float d)
        {
            if (creative || Dead || d <= 0) return;
            if (inv != null) { d *= 1f - Mathf.Min(20, inv.ArmorPoints()) / 25f; inv.DamageArmor(); }
            health -= d; flash = 0.6f;
            AudioManager.I?.Play2D(AudioManager.I.hurt, 0.9f, 1f);
            if (health <= 0) { health = 0; Dead = true; }
        }

        public void AddExhaustion(float e) { if (!creative) exhaustion += e; }

        public bool Eat(int food, float sat)
        {
            if (hunger >= 20) return false;
            hunger = Mathf.Min(20, hunger + food);
            saturation = Mathf.Min(hunger, saturation + sat);
            return true;
        }

        public void Respawn()
        {
            health = 20; hunger = 20; saturation = 5; exhaustion = 0; regenT = starveT = 0; Dead = false;
            OnRespawn?.Invoke();
        }

        void Update()
        {
            flash = Mathf.Max(0, flash - Time.deltaTime);
            if (Dead || creative) return;
            if (GameSession.Difficulty == 0) { health = Mathf.Min(20, health + Time.deltaTime * 0.5f); hunger = 20; saturation = 5; exhaustion = 0; return; }
            if (exhaustion >= 4f)
            {
                exhaustion -= 4f;
                if (saturation > 0) saturation = Mathf.Max(0, saturation - 1);
                else hunger = Mathf.Max(0, hunger - 1);
            }
            if (hunger >= 18 && health < 20)
            {
                regenT += Time.deltaTime;
                if (regenT >= 4f) { regenT = 0; health = Mathf.Min(20, health + 1); exhaustion += 0.6f; }
            }
            else if (hunger <= 0)
            {
                starveT += Time.deltaTime;
                if (starveT >= 4f) { starveT = 0; if (health > (GameSession.Difficulty == 1 ? 10 : GameSession.Difficulty == 2 ? 1 : 0)) Damage(1); }
            }
            else { regenT = 0; starveT = 0; }
        }

        void OnGUI()
        {
            GUI.depth = -100;
            if (flash > 0)
            {
                GUI.color = new Color(1, 0, 0, Mathf.Clamp01(flash) * 0.5f);
                GUI.DrawTexture(new Rect(0, 0, Screen.width, Screen.height), Texture2D.whiteTexture);
                GUI.color = Color.white;
            }
            if (!creative)
            {
                float s = Screen.height * 0.045f, hb = Screen.height * 0.1f;
                float y = Screen.height - hb - 4 - s - 6, x0 = (Screen.width - 9 * hb) / 2f, x1 = x0 + 9 * hb - 10 * (s + 2);
                for (int i = 0; i < 10; i++)
                {
                    float hp = health - i * 2, fv = hunger - i * 2;
                    Icon(new Rect(x0 + i * (s + 2), y, s, s), hp >= 2 ? new Color(.85f, .1f, .1f) : hp >= 1 ? new Color(.85f, .45f, .45f) : new Color(.25f, .25f, .25f));
                    Icon(new Rect(x1 + i * (s + 2), y, s, s), fv >= 2 ? new Color(.85f, .55f, .2f) : fv >= 1 ? new Color(.6f, .45f, .3f) : new Color(.25f, .25f, .25f));
                }
            }
            if (Dead)
            {
                GUI.color = new Color(0, 0, 0, 0.65f);
                GUI.DrawTexture(new Rect(0, 0, Screen.width, Screen.height), Texture2D.whiteTexture);
                GUI.color = Color.white;
                var big = new GUIStyle(GUI.skin.label) { alignment = TextAnchor.MiddleCenter, fontSize = Mathf.RoundToInt(Screen.height * 0.1f), fontStyle = FontStyle.Bold };
                big.normal.textColor = Color.red;
                GUI.Label(new Rect(0, Screen.height * 0.2f, Screen.width, Screen.height * 0.2f), "YOU DIED", big);
                float w = Screen.height * 0.6f, h = Screen.height * 0.16f;
                var btn = new GUIStyle(GUI.skin.button) { fontSize = Mathf.RoundToInt(h * 0.4f) };
                if (GUI.Button(new Rect((Screen.width - w) / 2f, Screen.height * 0.5f, w, h), "RESPAWN", btn)) Respawn();
            }
        }

        static void Icon(Rect r, Color c)
        {
            GUI.color = new Color(0, 0, 0, 0.6f);
            GUI.DrawTexture(new Rect(r.x - 1, r.y - 1, r.width + 2, r.height + 2), Texture2D.whiteTexture);
            GUI.color = c; GUI.DrawTexture(r, Texture2D.whiteTexture); GUI.color = Color.white;
        }
    }
}
