using System.Collections.Generic;
using UnityEngine;
using VoxelWorld.Blocks;
using VoxelWorld.Items;
using VoxelWorld.Save;
using VoxelWorld.World;

namespace VoxelWorld.Gameplay
{
    /// Рост пшеницы: блок грядки меняет стадию Wheat0 -> Wheat3 (каждая стадия StageTime секунд).
    /// Растёт только в загруженных чанках. Урожай: Wheat3 даёт пшеницу и семена, ранняя стадия — только семена.
    public class FarmSystem : MonoBehaviour
    {
        public ChunkManager world;
        public const float StageTime = 60f;
        readonly Dictionary<Vector3Int, float> crops = new Dictionary<Vector3Int, float>();

        public static bool IsCrop(ushort id) => id >= (ushort)BlockId.Wheat0 && id <= (ushort)BlockId.Wheat3;

        public void Plant(Vector3Int p) { crops[p] = 0f; }

        public ushort Harvest(Vector3Int p, ushort id, Inventory inv)
        {
            crops.Remove(p);
            if (id == (ushort)BlockId.Wheat3)
            {
                inv.Add((ushort)ItemId.Wheat, 1);
                int s = Random.Range(0, 3); if (s > 0) inv.Add((ushort)ItemId.WheatSeeds, s);
            }
            else inv.Add((ushort)ItemId.WheatSeeds, 1);
            return (ushort)BlockId.Farmland;
        }

        void Update()
        {
            foreach (var p in new List<Vector3Int>(crops.Keys))
            {
                if (!world.IsLoadedAt(p.x, p.z)) continue;
                ushort id = world.GetBlockWorld(p.x, p.y, p.z);
                if (!IsCrop(id) || id == (ushort)BlockId.Wheat3) { crops.Remove(p); continue; }
                crops[p] += Time.deltaTime;
                if (crops[p] >= StageTime)
                {
                    crops[p] = 0f;
                    world.SetBlockWorld(p.x, p.y, p.z, (ushort)(id + 1));
                    if (id + 1 >= (ushort)BlockId.Wheat3) crops.Remove(p);
                }
            }
        }

        public FarmData[] Export()
        {
            var l = new List<FarmData>();
            foreach (var kv in crops) l.Add(new FarmData { x = kv.Key.x, y = kv.Key.y, z = kv.Key.z, t = kv.Value });
            return l.ToArray();
        }

        public void Import(FarmData[] a)
        {
            crops.Clear();
            if (a != null) foreach (var d in a) crops[new Vector3Int(d.x, d.y, d.z)] = d.t;
        }
    }
}
