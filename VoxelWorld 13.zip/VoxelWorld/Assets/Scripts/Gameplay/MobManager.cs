using System.Collections.Generic;
using UnityEngine;
using VoxelWorld.Blocks;
using VoxelWorld.Core;
using VoxelWorld.Items;
using VoxelWorld.World;

namespace VoxelWorld.Gameplay
{
    /// Спавн/деспавн мобов вокруг игрока, дропы и сборка простых моделей из кубов.
    public class MobManager : MonoBehaviour
    {
        public static MobManager Instance;
        public Transform player; public SurvivalSystem survival; public ChunkManager world; public DayNightCycle day; public Inventory inv;
        readonly List<Mob> mobs = new List<Mob>();
        static readonly Dictionary<Color, Material> mats = new Dictionary<Color, Material>();
        static Mesh cube; float spawnT = 3f, vilT = 6f;

        void Awake() { Instance = this; }

        void Update()
        {
            vilT -= Time.deltaTime; if (vilT <= 0f) { vilT = 5f; SpawnVillagers(); }
            spawnT -= Time.deltaTime; if (spawnT > 0) return;
            spawnT = 2f; mobs.RemoveAll(m => m == null);
            int passive = 0, hostile = 0;
            foreach (var m in mobs) { if (m == null || m.type == MobType.Villager) continue; if (m.hostile) hostile++; else passive++; }
            if (GameSession.Dimension == 0)
            {
                if (passive < 10 && Random.value < 0.5f) TrySpawn(PassiveTypes[Random.Range(0, PassiveTypes.Length)]);
                if (day.IsNight && hostile < 10 && GameSession.Difficulty > 0) TrySpawn(HostileTypes[Random.Range(0, HostileTypes.Length)]);
            }
            else if (hostile < (GameSession.Dimension == 1 ? 8 : 6) && GameSession.Difficulty > 0) TrySpawn(GameSession.Dimension == 1 ? MobType.Pigman : MobType.Enderman);
        }

        /// Рядом с деревней (в пределах 48 блоков от игрока) поддерживаем 3 жителей.
        void SpawnVillagers()
        {
            if (GameSession.Dimension != 0) return;
            int pcx = Mathf.FloorToInt(player.position.x / 96f), pcz = Mathf.FloorToInt(player.position.z / 96f);
            for (int dx = -1; dx <= 1; dx++)
                for (int dz = -1; dz <= 1; dz++)
                {
                    if (!WorldGenerator.GetVillage(pcx + dx, pcz + dz, world.seed, out int ax, out int az, out int ah)) continue;
                    var home = new Vector3(ax + 0.5f, ah + 1, az + 0.5f);
                    if ((home - player.position).sqrMagnitude > 48f * 48f || !world.IsLoadedAt(ax, az)) continue;
                    int n = 0;
                    foreach (var m in mobs) if (m != null && m.type == MobType.Villager && (m.home - home).sqrMagnitude < 1f) n++;
                    for (int tries = 0; n < 3 && tries < 8; tries++)
                    {
                        int x = ax + Random.Range(-8, 9), z = az + Random.Range(-8, 9), y = WorldGenerator.Height(x, z, world.seed) + 1;
                        ushort below = world.GetBlockWorld(x, y - 1, z);
                        if (world.GetBlockWorld(x, y, z) != 0 || world.GetBlockWorld(x, y + 1, z) != 0 || below == 0 || below == (ushort)BlockId.Water) continue;
                        var v = Create(MobType.Villager, new Vector3(x + 0.5f, y, z + 0.5f), Random.Range(0, 3));
                        v.home = home; mobs.Add(v); n++;
                    }
                }
        }

        static readonly MobType[] PassiveTypes = { MobType.Cow, MobType.Pig, MobType.Sheep, MobType.Chicken }, HostileTypes = { MobType.Zombie, MobType.Zombie, MobType.Spider, MobType.Creeper };
        static bool IsPassive(MobType t) => t == MobType.Cow || t == MobType.Pig || t == MobType.Sheep || t == MobType.Chicken;

        void TrySpawn(MobType t)
        {
            Vector2 r = Random.insideUnitCircle.normalized * Random.Range(18f, 36f);
            float x = player.position.x + r.x, z = player.position.z + r.y;
            float top = GameSession.Dimension == 0 ? 127f : player.position.y + 8f;
            if (!Physics.Raycast(new Vector3(x, top, z), Vector3.down, out var h, top)) return;
            ushort b = world.GetBlockWorld(Mathf.FloorToInt(x), Mathf.FloorToInt(h.point.y - 0.1f), Mathf.FloorToInt(z));
            if (IsPassive(t) ? b != (ushort)BlockId.Grass : (b == (ushort)BlockId.Water || b == (ushort)BlockId.Lava || b == (ushort)BlockId.OakLeaves || b == (ushort)BlockId.Cactus || b == 0)) return;
            mobs.Add(Create(t, h.point + Vector3.up * 0.1f));
        }

        public bool HostileNear(Vector3 p, float r)
        {
            foreach (var m in mobs) if (m != null && m.hostile && (m.transform.position - p).sqrMagnitude < r * r) return true;
            return false;
        }

        public void GiveDrops(MobType t)
        {
            if (t == MobType.Cow) inv.Add((ushort)ItemId.RawBeef, Random.Range(1, 4));
            else if (t == MobType.Zombie) { int n = Random.Range(0, 3); if (n > 0) inv.Add((ushort)ItemId.RottenFlesh, n); }
            else if (t == MobType.Pig) inv.Add((ushort)ItemId.RawPork, Random.Range(1, 4));
            else if (t == MobType.Chicken) inv.Add((ushort)ItemId.RawChicken, 1);
            else if (t == MobType.Sheep) inv.Add((ushort)BlockId.WhiteWool, Random.Range(1, 3));
            else if (t == MobType.Creeper) { int g = Random.Range(0, 3); if (g > 0) inv.Add((ushort)ItemId.Gunpowder, g); }
        }

        // ---------- модели ----------
        static Material Mat(Color c)
        {
            if (!mats.TryGetValue(c, out var m)) { m = new Material(Shader.Find("VoxelWorld/ColorUnlit")) { color = c }; mats[c] = m; }
            return m;
        }

        static Transform Box(Transform parent, Vector3 pos, Vector3 size, Color c)
        {
            if (cube == null) { var g = GameObject.CreatePrimitive(PrimitiveType.Cube); cube = g.GetComponent<MeshFilter>().sharedMesh; Destroy(g); }
            var o = new GameObject("part"); o.transform.SetParent(parent, false);
            o.transform.localPosition = pos; o.transform.localScale = size;
            o.AddComponent<MeshFilter>().sharedMesh = cube; o.AddComponent<MeshRenderer>().sharedMaterial = Mat(c);
            return o.transform;
        }

        static Transform Leg(Transform parent, Vector3 hip, Vector3 size, Color c)
        {
            var h = new GameObject("leg").transform; h.SetParent(parent, false); h.localPosition = hip;
            Box(h, new Vector3(0, -size.y / 2f, 0), size, c); return h;
        }

        public static Mob Create(MobType t, Vector3 pos, int prof = 0)
        {
            var root = new GameObject(t.ToString()); root.transform.position = pos;
            root.transform.rotation = Quaternion.Euler(0, Random.Range(0, 360f), 0);
            var cc = root.AddComponent<CharacterController>(); cc.stepOffset = 0.3f;
            var mob = root.AddComponent<Mob>(); mob.type = t; mob.profession = prof; mob.home = pos;
            var tr = root.transform;
            if (t == MobType.Cow)
            {
                cc.radius = 0.45f; cc.height = 1.3f; cc.center = new Vector3(0, 0.65f, 0);
                Color br = new Color(0.35f, 0.22f, 0.12f), dk = new Color(0.22f, 0.14f, 0.08f);
                Box(tr, new Vector3(0, 0.9f, 0), new Vector3(0.8f, 0.7f, 1.3f), br);
                Box(tr, new Vector3(0.05f, 0.95f, 0.2f), new Vector3(0.82f, 0.4f, 0.5f), new Color(0.9f, 0.9f, 0.9f));
                Box(tr, new Vector3(0, 1.15f, 0.85f), new Vector3(0.5f, 0.5f, 0.5f), dk);
                Box(tr, new Vector3(0, 1.05f, 1.12f), new Vector3(0.3f, 0.2f, 0.1f), new Color(0.9f, 0.6f, 0.6f));
                mob.legs = new[] { Leg(tr, new Vector3(-0.28f, 0.55f, 0.5f), new Vector3(0.22f, 0.55f, 0.22f), dk), Leg(tr, new Vector3(0.28f, 0.55f, 0.5f), new Vector3(0.22f, 0.55f, 0.22f), dk),
                                   Leg(tr, new Vector3(-0.28f, 0.55f, -0.5f), new Vector3(0.22f, 0.55f, 0.22f), dk), Leg(tr, new Vector3(0.28f, 0.55f, -0.5f), new Vector3(0.22f, 0.55f, 0.22f), dk) };
                mob.health = 10; mob.speed = 2f; mob.hostile = false;
            }
            else if (t == MobType.Zombie)
            {
                cc.radius = 0.3f; cc.height = 1.8f; cc.center = new Vector3(0, 0.9f, 0);
                Color skin = new Color(0.45f, 0.65f, 0.35f);
                Box(tr, new Vector3(0, 1.125f, 0), new Vector3(0.5f, 0.75f, 0.25f), new Color(0.15f, 0.6f, 0.7f));
                Box(tr, new Vector3(0, 1.75f, 0), new Vector3(0.5f, 0.5f, 0.5f), skin);
                Box(tr, new Vector3(-0.37f, 1.35f, 0.3f), new Vector3(0.2f, 0.2f, 0.7f), skin);
                Box(tr, new Vector3(0.37f, 1.35f, 0.3f), new Vector3(0.2f, 0.2f, 0.7f), skin);
                Color jeans = new Color(0.2f, 0.25f, 0.6f);
                mob.legs = new[] { Leg(tr, new Vector3(-0.13f, 0.75f, 0), new Vector3(0.24f, 0.75f, 0.24f), jeans), Leg(tr, new Vector3(0.13f, 0.75f, 0), new Vector3(0.24f, 0.75f, 0.24f), jeans) };
                mob.health = 20; mob.speed = 2.6f; mob.hostile = true;
            }
            else if (t == MobType.Pig)
            {
                cc.radius = 0.4f; cc.height = 0.9f; cc.center = new Vector3(0, 0.45f, 0);
                Color pk = new Color(0.95f, 0.65f, 0.65f), pd = new Color(0.8f, 0.5f, 0.5f); var lp = new Vector3(0.2f, 0.4f, 0.2f);
                Box(tr, new Vector3(0, 0.65f, 0), new Vector3(0.7f, 0.6f, 1.0f), pk);
                Box(tr, new Vector3(0, 0.8f, 0.7f), new Vector3(0.5f, 0.5f, 0.45f), pk);
                Box(tr, new Vector3(0, 0.72f, 0.95f), new Vector3(0.25f, 0.18f, 0.1f), pd);
                mob.legs = new[] { Leg(tr, new Vector3(-0.2f, 0.4f, 0.35f), lp, pd), Leg(tr, new Vector3(0.2f, 0.4f, 0.35f), lp, pd), Leg(tr, new Vector3(-0.2f, 0.4f, -0.35f), lp, pd), Leg(tr, new Vector3(0.2f, 0.4f, -0.35f), lp, pd) };
                mob.health = 10; mob.speed = 1.8f; mob.hostile = false;
            }
            else if (t == MobType.Sheep)
            {
                cc.radius = 0.45f; cc.height = 1.3f; cc.center = new Vector3(0, 0.65f, 0);
                Color wl = new Color(0.92f, 0.92f, 0.9f), fc = new Color(0.35f, 0.3f, 0.28f); var lp = new Vector3(0.2f, 0.5f, 0.2f);
                Box(tr, new Vector3(0, 0.9f, 0), new Vector3(0.8f, 0.7f, 1.1f), wl);
                Box(tr, new Vector3(0, 1.0f, 0.75f), new Vector3(0.4f, 0.4f, 0.45f), fc);
                mob.legs = new[] { Leg(tr, new Vector3(-0.25f, 0.55f, 0.4f), lp, fc), Leg(tr, new Vector3(0.25f, 0.55f, 0.4f), lp, fc), Leg(tr, new Vector3(-0.25f, 0.55f, -0.4f), lp, fc), Leg(tr, new Vector3(0.25f, 0.55f, -0.4f), lp, fc) };
                mob.health = 8; mob.speed = 1.8f; mob.hostile = false;
            }
            else if (t == MobType.Chicken)
            {
                cc.radius = 0.25f; cc.height = 0.7f; cc.center = new Vector3(0, 0.35f, 0);
                Color wh = new Color(0.95f, 0.95f, 0.95f), yl = new Color(0.9f, 0.7f, 0.2f); var lp = new Vector3(0.08f, 0.3f, 0.08f);
                Box(tr, new Vector3(0, 0.5f, 0), new Vector3(0.4f, 0.4f, 0.55f), wh);
                Box(tr, new Vector3(0, 0.82f, 0.28f), new Vector3(0.2f, 0.25f, 0.2f), wh);
                Box(tr, new Vector3(0, 0.78f, 0.42f), new Vector3(0.1f, 0.08f, 0.12f), yl);
                mob.legs = new[] { Leg(tr, new Vector3(-0.1f, 0.3f, 0), lp, yl), Leg(tr, new Vector3(0.1f, 0.3f, 0), lp, yl) };
                mob.health = 4; mob.speed = 1.6f; mob.hostile = false;
            }
            else if (t == MobType.Spider)
            {
                cc.radius = 0.5f; cc.height = 0.7f; cc.center = new Vector3(0, 0.35f, 0);
                Color sk = new Color(0.2f, 0.15f, 0.15f);
                Box(tr, new Vector3(0, 0.5f, 0), new Vector3(0.9f, 0.5f, 0.9f), sk);
                Box(tr, new Vector3(0, 0.5f, 0.7f), new Vector3(0.5f, 0.45f, 0.5f), sk);
                Box(tr, new Vector3(-0.12f, 0.58f, 0.96f), new Vector3(0.1f, 0.08f, 0.02f), new Color(0.9f, 0.1f, 0.1f));
                Box(tr, new Vector3(0.12f, 0.58f, 0.96f), new Vector3(0.1f, 0.08f, 0.02f), new Color(0.9f, 0.1f, 0.1f));
                foreach (float sg in new[] { -1f, 1f }) foreach (float zz in new[] { -0.3f, -0.1f, 0.1f, 0.3f })
                    Box(tr, new Vector3(sg * 0.65f, 0.35f, zz), new Vector3(0.8f, 0.08f, 0.08f), sk);
                mob.health = 16; mob.speed = 3.2f; mob.hostile = true;
            }
            else if (t == MobType.Creeper)
            {
                cc.radius = 0.3f; cc.height = 1.7f; cc.center = new Vector3(0, 0.85f, 0);
                Color g = new Color(0.35f, 0.7f, 0.3f), dg = new Color(0.25f, 0.55f, 0.22f), bk = Color.black; var lp = new Vector3(0.22f, 0.4f, 0.22f);
                Box(tr, new Vector3(0, 0.8f, 0), new Vector3(0.5f, 0.8f, 0.3f), g);
                Box(tr, new Vector3(0, 1.45f, 0), new Vector3(0.5f, 0.5f, 0.5f), g);
                Box(tr, new Vector3(-0.12f, 1.5f, 0.255f), new Vector3(0.12f, 0.12f, 0.02f), bk);
                Box(tr, new Vector3(0.12f, 1.5f, 0.255f), new Vector3(0.12f, 0.12f, 0.02f), bk);
                Box(tr, new Vector3(0, 1.3f, 0.255f), new Vector3(0.14f, 0.2f, 0.02f), bk);
                mob.legs = new[] { Leg(tr, new Vector3(-0.12f, 0.4f, 0.15f), lp, dg), Leg(tr, new Vector3(0.12f, 0.4f, 0.15f), lp, dg), Leg(tr, new Vector3(-0.12f, 0.4f, -0.15f), lp, dg), Leg(tr, new Vector3(0.12f, 0.4f, -0.15f), lp, dg) };
                mob.health = 20; mob.speed = 2.4f; mob.hostile = true;
            }
            else if (t == MobType.Pigman)
            {
                cc.radius = 0.3f; cc.height = 1.8f; cc.center = new Vector3(0, 0.9f, 0);
                Color skin = new Color(0.85f, 0.55f, 0.55f), tun = new Color(0.65f, 0.4f, 0.2f), gold = new Color(0.95f, 0.8f, 0.2f);
                Box(tr, new Vector3(0, 1.125f, 0), new Vector3(0.5f, 0.75f, 0.25f), tun);
                Box(tr, new Vector3(0, 1.75f, 0), new Vector3(0.5f, 0.5f, 0.5f), skin);
                Box(tr, new Vector3(0, 1.68f, 0.27f), new Vector3(0.25f, 0.18f, 0.08f), new Color(0.75f, 0.4f, 0.4f));
                Box(tr, new Vector3(-0.37f, 1.35f, 0.3f), new Vector3(0.2f, 0.2f, 0.7f), skin); Box(tr, new Vector3(0.37f, 1.35f, 0.3f), new Vector3(0.2f, 0.2f, 0.7f), skin);
                Box(tr, new Vector3(0.37f, 1.45f, 0.75f), new Vector3(0.1f, 0.5f, 0.1f), gold);
                mob.legs = new[] { Leg(tr, new Vector3(-0.13f, 0.75f, 0), new Vector3(0.24f, 0.75f, 0.24f), skin), Leg(tr, new Vector3(0.13f, 0.75f, 0), new Vector3(0.24f, 0.75f, 0.24f), skin) };
                mob.health = 20; mob.speed = 2.8f; mob.hostile = true;
            }
            else if (t == MobType.Enderman)
            {
                cc.radius = 0.3f; cc.height = 2.8f; cc.center = new Vector3(0, 1.4f, 0);
                Color bk = new Color(0.07f, 0.05f, 0.09f), eye = new Color(0.85f, 0.3f, 0.95f);
                Box(tr, new Vector3(0, 1.7f, 0), new Vector3(0.4f, 1.0f, 0.25f), bk);
                Box(tr, new Vector3(0, 2.45f, 0), new Vector3(0.45f, 0.45f, 0.45f), bk);
                Box(tr, new Vector3(-0.12f, 2.47f, 0.23f), new Vector3(0.14f, 0.05f, 0.02f), eye); Box(tr, new Vector3(0.12f, 2.47f, 0.23f), new Vector3(0.14f, 0.05f, 0.02f), eye);
                Box(tr, new Vector3(-0.28f, 1.6f, 0), new Vector3(0.1f, 1.2f, 0.1f), bk); Box(tr, new Vector3(0.28f, 1.6f, 0), new Vector3(0.1f, 1.2f, 0.1f), bk);
                mob.legs = new[] { Leg(tr, new Vector3(-0.1f, 1.2f, 0), new Vector3(0.12f, 1.2f, 0.12f), bk), Leg(tr, new Vector3(0.1f, 1.2f, 0), new Vector3(0.12f, 1.2f, 0.12f), bk) };
                mob.health = 40; mob.speed = 3.2f; mob.hostile = true;
            }
            else
            {
                cc.radius = 0.3f; cc.height = 1.8f; cc.center = new Vector3(0, 0.9f, 0);
                Color skin = new Color(0.78f, 0.6f, 0.48f);
                Color[] robes = { new Color(0.54f, 0.42f, 0.23f), new Color(0.27f, 0.27f, 0.3f), new Color(0.86f, 0.86f, 0.86f) };
                Box(tr, new Vector3(0, 0.75f, 0), new Vector3(0.6f, 1.5f, 0.38f), robes[prof % 3]);
                Box(tr, new Vector3(0, 1.75f, 0), new Vector3(0.45f, 0.5f, 0.45f), skin);
                Box(tr, new Vector3(0, 1.68f, 0.27f), new Vector3(0.1f, 0.2f, 0.12f), new Color(0.65f, 0.48f, 0.38f));
                Box(tr, new Vector3(0, 1.2f, 0.22f), new Vector3(0.62f, 0.2f, 0.2f), skin);
                mob.health = 20; mob.speed = 1.4f; mob.hostile = false;
            }
            return mob;
        }
    }
}
