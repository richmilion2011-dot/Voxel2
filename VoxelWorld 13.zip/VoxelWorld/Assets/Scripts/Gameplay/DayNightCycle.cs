using UnityEngine;
using VoxelWorld.Core;

namespace VoxelWorld.Gameplay
{
    /// Время суток: управляет глобальной яркостью шейдеров (_DayLight) и цветом неба.
    public class DayNightCycle : MonoBehaviour
    {
        public float dayLength = 600f;   // секунд на сутки
        public float t = 0.2f;           // 0.25 — полдень, 0.75 — полночь
        public Camera cam;
        public float Light { get; private set; } = 1f;
        public bool IsNight => Light < 0.35f;

        void Update()
        {
            if (Input.GetKeyDown(KeyCode.N)) t = 0.75f; // тест в редакторе: ночь
            t = (t + Time.deltaTime / dayLength) % 1f;
            float s = Mathf.Sin(t * Mathf.PI * 2f);
            Light = GameSession.Dimension == 0 ? Mathf.Clamp01(0.5f + s * 1.5f) : GameSession.Dimension == 1 ? 0.62f : 0.5f;
            Shader.SetGlobalFloat("_DayLight", Light);
            if (cam == null) return;
            var sky = Color.Lerp(new Color(0.02f, 0.03f, 0.09f), new Color(0.55f, 0.75f, 0.95f), Light);
            float dusk = Mathf.Clamp01(1f - Mathf.Abs(Light - 0.45f) / 0.25f);
            cam.backgroundColor = Color.Lerp(sky, new Color(0.95f, 0.5f, 0.3f), dusk * 0.35f);
            if (GameSession.Dimension == 1) cam.backgroundColor = new Color(0.22f, 0.04f, 0.04f);
            else if (GameSession.Dimension == 2) cam.backgroundColor = new Color(0.05f, 0.03f, 0.1f);
        }
    }
}
