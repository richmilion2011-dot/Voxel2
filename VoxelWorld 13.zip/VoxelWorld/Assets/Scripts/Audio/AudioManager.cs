using UnityEngine;
using VoxelWorld.Blocks;
using VoxelWorld.Core;

namespace VoxelWorld.Audio
{
    /// Все звуки синтезируются кодом при старте (оригинальные, без файлов): шаги, добыча, удары, голоса мобов.
    /// Музыка — генеративная: тихие пэды и нотки пентатоники, новый фрагмент каждые 30–70 секунд.
    public class AudioManager : MonoBehaviour
    {
        public static AudioManager I;
        const int SR = 22050;
        public AudioClip stepStone, stepSoft, stepWood, digHard, digSoft, digWood, breakClip, place, hurt, eat, moo, groan, hit, splash;
        AudioSource[] pool; int next; AudioSource music; float nextMusic = 6f;

        public static void Ensure()
        {
            if (I != null) return;
            I = new GameObject("Audio").AddComponent<AudioManager>();
        }

        void Awake()
        {
            I = this;
            pool = new AudioSource[12];
            for (int i = 0; i < pool.Length; i++)
            {
                var o = new GameObject("sfx" + i); o.transform.SetParent(transform);
                pool[i] = o.AddComponent<AudioSource>(); pool[i].playOnAwake = false;
                pool[i].minDistance = 3f; pool[i].maxDistance = 30f; pool[i].rolloffMode = AudioRolloffMode.Linear;
            }
            music = gameObject.AddComponent<AudioSource>(); music.playOnAwake = false; music.spatialBlend = 0f;
            BuildClips(); ApplyVolumes();
        }

        public void ApplyVolumes() { if (music != null) music.volume = 0.35f * GameSettings.MusicVol; }

        void Update()
        {
            nextMusic -= Time.unscaledDeltaTime;
            if (nextMusic > 0f || music.isPlaying) return;
            nextMusic = Random.Range(30f, 70f);
            if (music.clip != null) Destroy(music.clip);
            music.clip = MakeMusic(Random.Range(0, 100000)); music.Play();
        }

        public void Play(AudioClip c, Vector3 pos, float vol = 1f, float pitch = 1f) => Emit(c, pos, 1f, vol, pitch);
        public void Play2D(AudioClip c, float vol = 1f, float pitch = 1f) => Emit(c, Vector3.zero, 0f, vol, pitch);

        void Emit(AudioClip c, Vector3 pos, float blend, float vol, float pitch)
        {
            if (c == null) return;
            var s = pool[next]; next = (next + 1) % pool.Length;
            s.transform.position = pos; s.spatialBlend = blend; s.pitch = pitch;
            s.volume = vol * GameSettings.SfxVol; s.clip = c; s.Play();
        }

        public AudioClip StepFor(ushort id)
        {
            switch ((BlockId)id)
            {
                case BlockId.Water: return splash;
                case BlockId.Grass: case BlockId.Dirt: case BlockId.Sand: case BlockId.Snow: case BlockId.OakLeaves: return stepSoft;
                case BlockId.OakLog: case BlockId.Planks: case BlockId.CraftingTable: case BlockId.Cactus: return stepWood;
                default: return stepStone;
            }
        }

        public AudioClip DigFor(BlockId id)
        {
            switch (id)
            {
                case BlockId.Grass: case BlockId.Dirt: case BlockId.Sand: case BlockId.Snow: case BlockId.OakLeaves: return digSoft;
                case BlockId.OakLog: case BlockId.Planks: case BlockId.CraftingTable: case BlockId.Cactus: return digWood;
                default: return digHard;
            }
        }

        // ---------- синтез ----------
        static AudioClip Make(string name, float dur, System.Func<float, float, float> gen)
        {
            int n = (int)(dur * SR); var d = new float[n];
            for (int i = 0; i < n; i++) d[i] = gen(i / (float)SR, i / (float)n);
            var c = AudioClip.Create(name, n, 1, SR, false); c.SetData(d, 0); return c;
        }

        static AudioClip Burst(string name, float dur, float lp, float decay, float tone = 0f, float toneAmt = 0f)
        {
            var rnd = new System.Random(name.Length * 7919 + (int)(dur * 1000)); float y = 0f;
            return Make(name, dur, (t, p) =>
            {
                y += lp * ((float)(rnd.NextDouble() * 2.0 - 1.0) - y);
                float env = Mathf.Exp(-t * decay), s = y * env * 2.2f;
                if (tone > 0f) s += Mathf.Sin(6.2831853f * tone * t) * env * toneAmt;
                return Mathf.Clamp(s, -1f, 1f) * 0.8f;
            });
        }

        void BuildClips()
        {
            stepStone = Burst("stepStone", 0.12f, 0.35f, 30f); stepSoft = Burst("stepSoft", 0.14f, 0.15f, 22f);
            stepWood = Burst("stepWood", 0.12f, 0.2f, 28f, 140f, 0.5f);
            digHard = Burst("digHard", 0.09f, 0.5f, 45f); digSoft = Burst("digSoft", 0.09f, 0.2f, 40f);
            digWood = Burst("digWood", 0.1f, 0.22f, 38f, 160f, 0.5f);
            breakClip = Burst("breakClip", 0.25f, 0.4f, 14f); place = Burst("place", 0.1f, 0.25f, 35f, 180f, 0.4f);
            hit = Burst("hit", 0.12f, 0.4f, 35f, 90f, 0.6f); splash = Burst("splash", 0.35f, 0.12f, 8f);

            float ph = 0f;
            hurt = Make("hurt", 0.3f, (t, p) => { ph += 6.2831853f * (320f - 200f * p) / SR; return Mathf.Sin(ph) * Mathf.Exp(-t * 7f) * 0.6f; });
            ph = 0f;
            moo = Make("moo", 0.8f, (t, p) =>
            {
                float f = 130f - 35f * p + 6f * Mathf.Sin(6.2831853f * 5f * t); ph += 6.2831853f * f / SR;
                float env = Mathf.Pow(Mathf.Sin(Mathf.PI * p), 0.6f);
                return (Mathf.Sin(ph) + 0.5f * Mathf.Sin(2f * ph) + 0.25f * Mathf.Sin(3f * ph)) * 0.35f * env;
            });
            ph = 0f; var rnd = new System.Random(5);
            groan = Make("groan", 0.9f, (t, p) =>
            {
                float f = 85f - 25f * p + 10f * Mathf.Sin(6.2831853f * 7f * t); ph += 6.2831853f * f / SR;
                float env = Mathf.Sin(Mathf.PI * p);
                return (Mathf.Clamp(Mathf.Sin(ph) * 3f, -1f, 1f) * 0.3f + (float)(rnd.NextDouble() - 0.5) * 0.06f) * env;
            });
            float yy = 0f;
            eat = Make("eat", 0.45f, (t, p) =>
            {
                float env = 0f;
                for (int k = 0; k < 3; k++) { float tt = t - k * 0.15f; if (tt > 0) env += Mathf.Exp(-tt * 40f); }
                yy += 0.3f * ((float)(rnd.NextDouble() * 2 - 1) - yy);
                return Mathf.Clamp(yy * env * 2f, -1f, 1f) * 0.7f;
            });
        }

        static AudioClip MakeMusic(int seed)
        {
            var rnd = new System.Random(seed);
            float[] scale = { 220f, 261.63f, 293.66f, 329.63f, 392f };
            float[] pad = new float[3];
            for (int i = 0; i < 3; i++) pad[i] = scale[rnd.Next(5)] * (rnd.Next(2) == 0 ? 0.5f : 1f);
            const int pl = 6; var pt = new float[pl]; var pf = new float[pl];
            for (int i = 0; i < pl; i++) { pt[i] = 1f + i * 2f + (float)rnd.NextDouble(); pf[i] = scale[rnd.Next(5)] * 2f; }
            return Make("music", 14f, (t, p) =>
            {
                float env = Mathf.Pow(Mathf.Sin(Mathf.PI * p), 2f), s = 0f;
                for (int i = 0; i < 3; i++) s += Mathf.Sin(6.2831853f * pad[i] * t) * 0.08f;
                for (int i = 0; i < pl; i++) { float tt = t - pt[i]; if (tt > 0f && tt < 3f) s += Mathf.Sin(6.2831853f * pf[i] * tt) * Mathf.Exp(-tt * 2.5f) * 0.12f; }
                return s * env;
            });
        }
    }
}
