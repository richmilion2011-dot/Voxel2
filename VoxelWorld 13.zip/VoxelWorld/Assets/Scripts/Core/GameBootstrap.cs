using System.Collections.Generic;
using UnityEngine;
using VoxelWorld.Audio;
using VoxelWorld.Gameplay;
using VoxelWorld.Items;
using VoxelWorld.Player;
using VoxelWorld.Save;
using VoxelWorld.UI;
using VoxelWorld.World;

namespace VoxelWorld.Core
{
    /// Повесьте на пустой объект в пустой сцене. Показывает главное меню; выбранный мир собирается в BuildGame().
    public class GameBootstrap : MonoBehaviour
    {
        Camera cam; Material mat; MainMenu menu; WorldSaver saver;
        readonly List<GameObject> roots = new List<GameObject>();

        void Start()
        {
            var tex = Resources.Load<Texture2D>("VoxelAtlas");
            tex.filterMode = FilterMode.Point; tex.wrapMode = TextureWrapMode.Clamp;
            mat = new Material(Shader.Find("VoxelWorld/VoxelUnlit")) { mainTexture = tex };

            cam = Camera.main != null ? Camera.main : new GameObject("Camera", typeof(Camera)).GetComponent<Camera>();
            cam.tag = "MainCamera"; cam.clearFlags = CameraClearFlags.SolidColor;
            cam.backgroundColor = new Color(0.55f, 0.75f, 0.95f);

            new GameObject("Fps").AddComponent<FpsCounter>();
            if (cam.GetComponent<AudioListener>() == null) cam.gameObject.AddComponent<AudioListener>();
            AudioManager.Ensure();
            GameSettings.Load(); GameSettings.Cam = cam; GameSettings.Apply();
            Shader.SetGlobalFloat("_DayLight", 1f);
            ShowMenu();
        }

        void ShowMenu() { menu = gameObject.AddComponent<MainMenu>(); menu.Init(this, cam, mat); }

        public void BeginGame()
        {
            if (menu != null) { menu.Shutdown(); Destroy(menu); menu = null; }
            BuildGame();
        }

        public void QuitToMenu()
        {
            if (saver != null) saver.Save();
            GameSettings.Pc = null; GameSettings.Cm = null;
            cam.transform.SetParent(null, true);
            foreach (var m in FindObjectsByType<Mob>(FindObjectsSortMode.None)) Destroy(m.gameObject);
            foreach (var it in FindObjectsByType<ItemEntity>(FindObjectsSortMode.None)) Destroy(it.gameObject);
            foreach (var r in roots) if (r != null) Destroy(r);
            roots.Clear(); saver = null;
            GameSession.Paused = false; Time.timeScale = 1f;
            Shader.SetGlobalFloat("_DayLight", 1f);
            ShowMenu();
        }

        void BuildGame()
        {
            string worldName = GameSession.WorldName;
            var save = new WorldSave(worldName);
            var data = save.LoadMeta();
            int seed = data != null ? data.seed : 12345;
            if (data != null) GameSession.Difficulty = data.difficulty;
            GameSession.Dimension = data != null ? data.dimension : 0; GameSession.DragonDead = data != null && data.dragonDead; save.Dim = GameSession.Dimension;

            var player = new GameObject("Player"); roots.Add(player);
            player.transform.position = new Vector3(8, 110, 8);
            var cc = player.AddComponent<CharacterController>();
            cc.height = 1.8f; cc.radius = 0.3f; cc.center = new Vector3(0, 0.9f, 0); cc.stepOffset = 0.55f;

            cam.transform.SetParent(player.transform, false);
            cam.transform.localPosition = new Vector3(0, 1.6f, 0); cam.transform.localRotation = Quaternion.identity;

            var cm = new GameObject("World").AddComponent<ChunkManager>(); roots.Add(cm.gameObject);
            cm.player = player.transform; cm.chunkMaterial = mat; cm.seed = seed; cm.save = save; cm.dimension = GameSession.Dimension;
            cm.renderDistance = GameSettings.RenderDistance;

            var pc = player.AddComponent<PlayerController>();
            var inv = new Inventory();
            var ui = player.AddComponent<InventoryUI>(); ui.inv = inv;
            pc.cam = cam.transform; pc.world = cm; pc.inv = inv; pc.ui = ui;
            pc.survival = player.AddComponent<SurvivalSystem>(); pc.survival.inv = inv;
            var model = player.AddComponent<PlayerModel>(); model.Init(inv, cc); pc.model = model;
            ui.onDrop = pc.DropStack;
            var furn = new GameObject("Furnaces").AddComponent<FurnaceSystem>(); roots.Add(furn.gameObject);
            pc.furnaces = furn;
            var chests = new GameObject("Chests").AddComponent<ChestSystem>(); roots.Add(chests.gameObject);
            chests.seed = seed; pc.chests = chests;
            var farms = new GameObject("Farms").AddComponent<FarmSystem>(); roots.Add(farms.gameObject);
            farms.world = cm; pc.farms = farms;
            MinecartEntity.World = cm; ItemEntity.World = cm; ItemEntity.PlayerT = player.transform; ItemEntity.Inv = inv; ItemEntity.Mat = mat;

            var day = new GameObject("DayNight").AddComponent<DayNightCycle>(); roots.Add(day.gameObject);
            day.cam = cam; pc.day = day;
            var mm = new GameObject("Mobs").AddComponent<MobManager>(); roots.Add(mm.gameObject);
            mm.player = player.transform; mm.survival = pc.survival; mm.world = cm; mm.day = day; mm.inv = inv;

            saver = new GameObject("Saver").AddComponent<WorldSaver>(); roots.Add(saver.gameObject);
            saver.Init(worldName, save, cm, pc, pc.survival, inv, ui, furn, day, chests, farms);
            if (data != null) saver.Apply(data);

            var pause = new GameObject("Pause").AddComponent<PauseMenu>(); roots.Add(pause.gameObject);
            var dm = new GameObject("Dimensions").AddComponent<DimensionManager>(); roots.Add(dm.gameObject);
            dm.world = cm; dm.pc = pc; dm.player = player.transform;
            pause.Init(this, saver, ui);

            GameSettings.Pc = pc; GameSettings.Cm = cm; GameSettings.Apply();
        }
    }
}
