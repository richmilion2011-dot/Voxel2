using UnityEngine;
using VoxelWorld.Audio;
using VoxelWorld.Player;
using VoxelWorld.World;

namespace VoxelWorld.Core
{
    /// Данные текущей игровой сессии (мир, сложность, пауза).
    public static class GameSession
    {
        public static string WorldName = "World1";
        public static int Difficulty = 2;   // 0 Peaceful, 1 Easy, 2 Normal, 3 Hard
        public static bool Paused;
        public static int Dimension;      // 0 мир, 1 Незер, 2 Энд
        public static bool DragonDead;
    }

    /// Настройки игрока (хранятся в PlayerPrefs) и их применение на лету.
    public static class GameSettings
    {
        public static int RenderDistance = 3, FpsLimit = 60;
        public static float Fov = 70f, LookSens = 0.15f;
        public static bool ShowFps;
        public static float MasterVol = 1f, MusicVol = 0.6f, SfxVol = 1f;
        public static Camera Cam; public static PlayerController Pc; public static ChunkManager Cm;

        public static void Load()
        {
            RenderDistance = PlayerPrefs.GetInt("rd", 3); FpsLimit = PlayerPrefs.GetInt("fps", 60);
            Fov = PlayerPrefs.GetFloat("fov", 70f); LookSens = PlayerPrefs.GetFloat("look", 0.15f);
            ShowFps = PlayerPrefs.GetInt("showfps", 0) == 1;
            MasterVol = PlayerPrefs.GetFloat("vm", 1f); MusicVol = PlayerPrefs.GetFloat("vmu", 0.6f); SfxVol = PlayerPrefs.GetFloat("vsfx", 1f);
        }

        public static void Save()
        {
            PlayerPrefs.SetInt("rd", RenderDistance); PlayerPrefs.SetInt("fps", FpsLimit);
            PlayerPrefs.SetFloat("fov", Fov); PlayerPrefs.SetFloat("look", LookSens);
            PlayerPrefs.SetInt("showfps", ShowFps ? 1 : 0);
            PlayerPrefs.SetFloat("vm", MasterVol); PlayerPrefs.SetFloat("vmu", MusicVol); PlayerPrefs.SetFloat("vsfx", SfxVol);
            PlayerPrefs.Save();
        }

        public static void Apply()
        {
            QualitySettings.vSyncCount = 0; Application.targetFrameRate = FpsLimit;
            AudioListener.volume = MasterVol; if (AudioManager.I != null) AudioManager.I.ApplyVolumes();
            if (Cam != null) Cam.fieldOfView = Fov;
            if (Pc != null) Pc.touchLook = LookSens;
            if (Cm != null && Cm.renderDistance != RenderDistance) { Cm.renderDistance = RenderDistance; Cm.ForceRefresh(); }
        }
    }

    public class FpsCounter : MonoBehaviour
    {
        float acc, fps; int frames;
        void Update()
        {
            acc += Time.unscaledDeltaTime; frames++;
            if (acc >= 0.5f) { fps = frames / acc; frames = 0; acc = 0; }
        }
        void OnGUI() { if (GameSettings.ShowFps) GUI.Label(new Rect(Screen.width - 120, 6, 110, 30), Mathf.RoundToInt(fps) + " FPS"); }
    }
}
