using System;
using System.IO;
using System.IO.Compression;
using UnityEngine;
using VoxelWorld.World;

namespace VoxelWorld.Save
{
    [Serializable] public class SlotData { public int id, count, dur; }
    [Serializable] public class FurnaceData { public int x, y, z; public SlotData[] slots; public float burnLeft, burnMax, cook; }

    [Serializable] public class FarmData { public int x, y, z; public float t; }
    [Serializable] public class ChestData { public int x, y, z; public SlotData[] slots; }

    [Serializable]
    public class SaveData
    {
        public int version = 1; public string name; public int seed; public float dayT;
        public Vector3 pos; public float yaw, pitch;
        public float health, hunger, saturation; public int selected;
        public SlotData[] items; public FurnaceData[] furnaces; public string lastPlayed;
        public bool creative; public int difficulty = 2; public ChestData[] chests; public FarmData[] farms; public Vector3 spawn; public SlotData[] armor, offhand; public int dimension; public bool dragonDead;
    }

    /// Файлы мира в Application.persistentDataPath/worlds/<имя>/: world.json + chunks/x_z.chk (только изменённые чанки, gzip).
    /// Запись через временный файл — защита от порчи при внезапном закрытии.
    public class WorldSave
    {
        readonly string dir, chunkDir;

        public WorldSave(string worldName)
        {
            worldName = Sanitize(worldName);
            dir = Path.Combine(Root, worldName);
            chunkDir = Path.Combine(dir, "chunks");
            Directory.CreateDirectory(chunkDir);
        }

        public static string Root => Path.Combine(Application.persistentDataPath, "worlds");
        public static string Sanitize(string n) { foreach (var c in Path.GetInvalidFileNameChars()) n = n.Replace(c, '_'); return n.Trim(); }
        public static bool Exists(string n) => Directory.Exists(Path.Combine(Root, Sanitize(n)));
        public static void Delete(string n) { var p = Path.Combine(Root, Sanitize(n)); if (Directory.Exists(p)) Directory.Delete(p, true); }
        public static string[] ListNames()
        {
            if (!Directory.Exists(Root)) return new string[0];
            var d = Directory.GetDirectories(Root);
            for (int i = 0; i < d.Length; i++) d[i] = Path.GetFileName(d[i]);
            return d;
        }

        string MetaPath => Path.Combine(dir, "world.json");
        public int Dim;
        string ChunkPath(Vector2Int k) => Path.Combine(chunkDir, (Dim == 0 ? "" : "d" + Dim + "_") + k.x + "_" + k.y + ".chk");

        static void WriteAtomic(string path, byte[] data)
        {
            string tmp = path + ".tmp";
            File.WriteAllBytes(tmp, data);
            if (File.Exists(path)) File.Copy(tmp, path, true); else File.Move(tmp, path);
            if (File.Exists(tmp)) File.Delete(tmp);
        }

        public SaveData LoadMeta()
        {
            foreach (var p in new[] { MetaPath, MetaPath + ".tmp" })
            {
                try { if (File.Exists(p)) { var d = JsonUtility.FromJson<SaveData>(File.ReadAllText(p)); if (d != null) return d; } }
                catch (Exception e) { Debug.LogWarning("Save read failed: " + e.Message); }
            }
            return null;
        }

        public void SaveMeta(SaveData d)
        {
            d.lastPlayed = DateTime.Now.ToString("s");
            WriteAtomic(MetaPath, System.Text.Encoding.UTF8.GetBytes(JsonUtility.ToJson(d, true)));
        }

        public ChunkData LoadChunk(Vector2Int k)
        {
            string p = ChunkPath(k);
            if (!File.Exists(p)) return null;
            try
            {
                using (var fs = File.OpenRead(p))
                using (var gz = new GZipStream(fs, CompressionMode.Decompress))
                {
                    var raw = new byte[ChunkData.SizeX * ChunkData.SizeY * ChunkData.SizeZ * 2];
                    int off = 0;
                    while (off < raw.Length) { int n = gz.Read(raw, off, raw.Length - off); if (n <= 0) break; off += n; }
                    if (off != raw.Length) return null;
                    var cd = new ChunkData();
                    Buffer.BlockCopy(raw, 0, cd.Blocks, 0, raw.Length);
                    cd.RebuildEmitters();
                    return cd;
                }
            }
            catch (Exception e) { Debug.LogWarning("Chunk read failed: " + e.Message); return null; }
        }

        public void SaveChunk(Vector2Int k, ChunkData cd)
        {
            var raw = new byte[cd.Blocks.Length * 2];
            Buffer.BlockCopy(cd.Blocks, 0, raw, 0, raw.Length);
            using (var ms = new MemoryStream())
            {
                using (var gz = new GZipStream(ms, CompressionLevel.Fastest, true)) gz.Write(raw, 0, raw.Length);
                WriteAtomic(ChunkPath(k), ms.ToArray());
            }
        }
    }
}
