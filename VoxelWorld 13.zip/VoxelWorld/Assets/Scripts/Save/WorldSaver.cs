using UnityEngine;
using VoxelWorld.Core;
using VoxelWorld.Gameplay;
using VoxelWorld.Items;
using VoxelWorld.Player;
using VoxelWorld.UI;
using VoxelWorld.World;

namespace VoxelWorld.Save
{
    /// Автосохранение каждые 60 с, при сворачивании приложения и при выходе. Моб-ы не сохраняются (появятся заново).
    public class WorldSaver : MonoBehaviour
    {
        string worldName; WorldSave save; ChunkManager cm; PlayerController pc; SurvivalSystem sv;
        Inventory inv; InventoryUI ui; FurnaceSystem furn; DayNightCycle day; ChestSystem chests; FarmSystem farms;
        float timer, shown;

        public void Init(string name, WorldSave s, ChunkManager c, PlayerController p, SurvivalSystem v, Inventory i, InventoryUI u, FurnaceSystem f, DayNightCycle d, ChestSystem ch = null, FarmSystem fa = null)
        { worldName = name; save = s; cm = c; pc = p; sv = v; inv = i; ui = u; furn = f; day = d; chests = ch; farms = fa; }

        void Update()
        {
            timer += Time.deltaTime; shown = Mathf.Max(0, shown - Time.deltaTime);
            if (timer >= 60f) { timer = 0; Save(); }
        }
        void OnApplicationPause(bool paused) { if (paused) Save(); }
        void OnApplicationQuit() { Save(); }
        void OnGUI() { if (shown > 0) GUI.Label(new Rect(Screen.height * 0.1f + 20, 12, 300, 40), "World saved"); }

        public static SlotData[] ToData(ItemStack[] src)
        {
            var d = new SlotData[src.Length];
            for (int i = 0; i < src.Length; i++) d[i] = new SlotData { id = src[i].Empty ? 0 : src[i].id, count = src[i].count, dur = src[i].dur };
            return d;
        }
        public static ItemStack FromData(SlotData s) => s == null || s.id == 0 || s.count <= 0 ? default : new ItemStack { id = (ushort)s.id, count = s.count, dur = s.dur };

        public void Save()
        {
            if (cm == null || save == null) return;
            var d = new SaveData
            {
                name = worldName, seed = cm.seed, dayT = day.t,
                pos = pc.transform.position, yaw = pc.transform.eulerAngles.y, pitch = pc.Pitch,
                health = sv.health, hunger = sv.hunger, saturation = sv.saturation, selected = ui.selected,
                items = ToData(pc.SurvivalInventory()), furnaces = furn.Export(), creative = pc.creative, difficulty = GameSession.Difficulty, chests = chests?.Export(), farms = farms?.Export(), spawn = pc.SpawnPoint, armor = ToData(inv.armor), offhand = ToData(inv.off), dimension = GameSession.Dimension, dragonDead = GameSession.DragonDead
            };
            if (sv.Dead) { d.health = 20; d.hunger = 20; d.pos = new Vector3(8, 110, 8); }
            cm.SaveAllDirty();
            save.SaveMeta(d);
            shown = 2f;
        }

        public void Apply(SaveData d)
        {
            pc.SetPosition(d.pos, d.yaw, d.pitch);
            sv.health = d.health > 0 ? d.health : 20; sv.hunger = d.hunger; sv.saturation = d.saturation;
            ui.selected = Mathf.Clamp(d.selected, 0, 8);
            if (d.items != null) for (int i = 0; i < d.items.Length && i < Inventory.Size; i++) inv.slots[i] = FromData(d.items[i]);
            day.t = d.dayT;
            furn.Import(d.furnaces); chests?.Import(d.chests); farms?.Import(d.farms);
            if (d.armor != null) for (int i = 0; i < 4 && i < d.armor.Length; i++) inv.armor[i] = FromData(d.armor[i]);
            if (d.offhand != null && d.offhand.Length > 0) inv.off[0] = FromData(d.offhand[0]);
            if (d.spawn != Vector3.zero) pc.SpawnPoint = d.spawn;
            GameSession.Difficulty = d.difficulty; pc.SetCreative(d.creative);
        }
    }
}
