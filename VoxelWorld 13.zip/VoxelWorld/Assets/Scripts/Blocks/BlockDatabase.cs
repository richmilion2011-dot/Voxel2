using UnityEngine;
using VoxelWorld.Items;
namespace VoxelWorld.Blocks
{
    public enum Shape { Cube, Torch, Ladder, Rail, Fence, Pane, Slab, Stair, Door, Trapdoor, Gate, Wall }

    public enum BlockId : ushort { Air = 0, Grass, Dirt, Stone, Sand, Water, Bedrock, OakLog, OakLeaves, Glass, Snow, Cactus, CoalOre, IronOre, Planks, CraftingTable, Cobblestone, Furnace, Chest, LootChest, Farmland, Wheat0, Wheat1, Wheat2, Wheat3, Bed, Granite, Diorite, Andesite, Deepslate, Gravel, Clay, Mud, RedSand, Terracotta, PackedIce, Ice, Moss, Mycelium, Obsidian, GoldOre, CopperOre, RedstoneOre, LapisOre, DiamondOre, EmeraldOre, QuartzOre, BirchLog, BirchPlanks, BirchLeaves, SpruceLog, SprucePlanks, SpruceLeaves, JungleLog, JunglePlanks, JungleLeaves, AcaciaLog, AcaciaPlanks, AcaciaLeaves, DarkOakLog, DarkOakPlanks, DarkOakLeaves, Bricks, StoneBricks, Sandstone, WhiteWool, RedWool, OrangeWool, YellowWool, LimeWool, BlueWool, PurpleWool, BlackWool, Bookshelf, IronBlock, GoldBlock, DiamondBlock, CoalBlock, Netherrack, SoulSand, NetherBricks, Glowstone, EndStone, Lava, MagentaWool, LightBlueWool, PinkWool, GrayWool, LightGrayWool, CyanWool, BrownWool, GreenWool, WhiteConcrete, OrangeConcrete, MagentaConcrete, LightBlueConcrete, YellowConcrete, LimeConcrete, PinkConcrete, GrayConcrete, LightGrayConcrete, CyanConcrete, PurpleConcrete, BlueConcrete, BrownConcrete, GreenConcrete, RedConcrete, BlackConcrete, WhiteTerracotta, OrangeTerracotta, MagentaTerracotta, LightBlueTerracotta, YellowTerracotta, LimeTerracotta, PinkTerracotta, GrayTerracotta, LightGrayTerracotta, CyanTerracotta, PurpleTerracotta, BlueTerracotta, BrownTerracotta, GreenTerracotta, RedTerracotta, BlackTerracotta, WhiteStainedGlass, OrangeStainedGlass, MagentaStainedGlass, LightBlueStainedGlass, YellowStainedGlass, LimeStainedGlass, PinkStainedGlass, GrayStainedGlass, LightGrayStainedGlass, CyanStainedGlass, PurpleStainedGlass, BlueStainedGlass, BrownStainedGlass, GreenStainedGlass, RedStainedGlass, BlackStainedGlass, Torch, Ladder, Rail, GlassPane, WhiteStainedGlassPane, OrangeStainedGlassPane, MagentaStainedGlassPane, LightBlueStainedGlassPane, YellowStainedGlassPane, LimeStainedGlassPane, PinkStainedGlassPane, GrayStainedGlassPane, LightGrayStainedGlassPane, CyanStainedGlassPane, PurpleStainedGlassPane, BlueStainedGlassPane, BrownStainedGlassPane, GreenStainedGlassPane, RedStainedGlassPane, BlackStainedGlassPane, OakSlab, OakStairs0, OakStairs1, OakStairs2, OakStairs3, SpruceSlab, SpruceStairs0, SpruceStairs1, SpruceStairs2, SpruceStairs3, BirchSlab, BirchStairs0, BirchStairs1, BirchStairs2, BirchStairs3, JungleSlab, JungleStairs0, JungleStairs1, JungleStairs2, JungleStairs3, AcaciaSlab, AcaciaStairs0, AcaciaStairs1, AcaciaStairs2, AcaciaStairs3, DarkOakSlab, DarkOakStairs0, DarkOakStairs1, DarkOakStairs2, DarkOakStairs3, CobbleSlab, CobbleStairs0, CobbleStairs1, CobbleStairs2, CobbleStairs3, StoneSlab, StoneStairs0, StoneStairs1, StoneStairs2, StoneStairs3, StoneBrickSlab, StoneBrickStairs0, StoneBrickStairs1, StoneBrickStairs2, StoneBrickStairs3, BrickSlab, BrickStairs0, BrickStairs1, BrickStairs2, BrickStairs3, SandstoneSlab, SandstoneStairs0, SandstoneStairs1, SandstoneStairs2, SandstoneStairs3, NetherBrickSlab, NetherBrickStairs0, NetherBrickStairs1, NetherBrickStairs2, NetherBrickStairs3, OakFence, SpruceFence, BirchFence, JungleFence, AcaciaFence, DarkOakFence, NetherBrickFence, MangroveLog, MangrovePlanks, MangroveLeaves, CherryLog, CherryPlanks, CherryLeaves, CrimsonStem, CrimsonPlanks, WarpedStem, WarpedPlanks, BambooBlock, BambooPlanks, PolishedGranite, PolishedDiorite, PolishedAndesite, SmoothStone, MossyCobblestone, MossyStoneBricks, CrackedStoneBricks, ChiseledStoneBricks, Calcite, Tuff, Basalt, Blackstone, PolishedBlackstone, CryingObsidian, DripstoneBlock, CopperBlock, ExposedCopper, WeatheredCopper, OxidizedCopper, CutCopper, QuartzBlock, QuartzPillar, ChiseledQuartz, Purpur, PurpurPillar, Prismarine, PrismarineBricks, DarkPrismarine, SeaLantern, RedSandstone, BlueIce, CoarseDirt, Podzol, PackedMud, MudBricks, SoulSoil, NetherWartBlock, WarpedWartBlock, RedNetherBricks, AncientDebris, EndStoneBricks, Amethyst, LapisBlock, RedstoneBlock, EmeraldBlock, HayBale, Melon, Pumpkin, JackOLantern, Sponge, BoneBlock, MagmaBlock, Shroomlight, OakDoor, SpruceDoor, BirchDoor, JungleDoor, AcaciaDoor, DarkOakDoor, IronDoor, OakTrapdoor, SpruceTrapdoor, BirchTrapdoor, JungleTrapdoor, AcaciaTrapdoor, DarkOakTrapdoor, IronTrapdoor, OakFenceGate, SpruceFenceGate, BirchFenceGate, JungleFenceGate, AcaciaFenceGate, DarkOakFenceGate, CobbleWall, MossyCobbleWall, StoneBrickWall, BrickWall, SandstoneWall, NetherBrickWall, Portal, EndPortal }

    public class BlockDefinition
    {
        public BlockId Id; public string Name;
        public bool Solid = true;        // коллизия
        public bool Transparent = false; // соседние грани видны сквозь блок
        public float Hardness = 1f;      // время добычи
        public ushort Drop; public ToolType Tool; public int MinTier = -1; public string Cat = "Building"; public bool Hidden; public Shape Shape; public int Light, Facing, Full, Icon = -1;             // что выпадает при добыче
        public int TexTop, TexSide, TexBottom; // индексы тайлов в атласе 16x16 тайлов
    }

    public static class BlockDatabase
    {
        public const int AtlasTiles = 16;
        static readonly BlockDefinition[] defs = new BlockDefinition[ushort.MaxValue + 1];

        static BlockDatabase()
        {
            Reg(BlockId.Air, "Air", 0, 0, 0, solid: false, transparent: true, hardness: 0);
            Reg(BlockId.Grass, "Grass", 0, 1, 2, hardness: 0.6f);
            Reg(BlockId.Dirt, "Dirt", 2, 2, 2, hardness: 0.5f);
            Reg(BlockId.Stone, "Stone", 3, 3, 3, hardness: 1.5f);
            Reg(BlockId.Sand, "Sand", 4, 4, 4, hardness: 0.5f);
            Reg(BlockId.Water, "Water", 5, 5, 5, solid: false, transparent: true, hardness: 100);
            Reg(BlockId.Bedrock, "Bedrock", 6, 6, 6, hardness: -1);
            Reg(BlockId.OakLog, "Oak Log", 7, 8, 7, hardness: 2f);
            Reg(BlockId.OakLeaves, "Oak Leaves", 9, 9, 9, transparent: true, hardness: 0.2f);
            Reg(BlockId.Glass, "Glass", 10, 10, 10, transparent: true, hardness: 0.3f);
            Reg(BlockId.Snow, "Snow", 11, 11, 11, hardness: 0.3f);
            Reg(BlockId.Cactus, "Cactus", 13, 12, 13, hardness: 0.4f);
            Reg(BlockId.CoalOre, "Coal Ore", 14, 14, 14, hardness: 3f);
            Reg(BlockId.IronOre, "Iron Ore", 15, 15, 15, hardness: 3f);
            Reg(BlockId.Planks, "Oak Planks", 16, 16, 16, hardness: 2f);
            Reg(BlockId.CraftingTable, "Crafting Table", 17, 18, 16, hardness: 2.5f);
            Reg(BlockId.Cobblestone, "Cobblestone", 19, 19, 19, hardness: 2f);
            Reg(BlockId.Furnace, "Furnace", 38, 37, 38, hardness: 3.5f);
            Reg(BlockId.Chest, "Chest", 42, 43, 42, hardness: 2.5f);
            Reg(BlockId.LootChest, "Chest", 42, 43, 42, hardness: 2.5f);
            Reg(BlockId.Farmland, "Farmland", 44, 2, 2, hardness: 0.6f);
            Reg(BlockId.Wheat0, "Wheat", 45, 2, 2, hardness: 0.1f); Reg(BlockId.Wheat1, "Wheat", 46, 2, 2, hardness: 0.1f);
            Reg(BlockId.Wheat2, "Wheat", 47, 2, 2, hardness: 0.1f); Reg(BlockId.Wheat3, "Wheat", 48, 2, 2, hardness: 0.1f);
            Reg(BlockId.Bed, "Bed", 49, 50, 16, hardness: 0.3f);
            R2(BlockId.Granite, "Granite", 58, 58, 58, 1.5f, ToolType.Pickaxe, 0, "Natural");
            R2(BlockId.Diorite, "Diorite", 59, 59, 59, 1.5f, ToolType.Pickaxe, 0, "Natural");
            R2(BlockId.Andesite, "Andesite", 60, 60, 60, 1.5f, ToolType.Pickaxe, 0, "Natural");
            R2(BlockId.Deepslate, "Deepslate", 61, 61, 61, 3.0f, ToolType.Pickaxe, 0, "Natural");
            R2(BlockId.Gravel, "Gravel", 62, 62, 62, 0.6f, ToolType.Shovel, -1, "Natural");
            R2(BlockId.Clay, "Clay", 63, 63, 63, 0.6f, ToolType.Shovel, -1, "Natural");
            R2(BlockId.Mud, "Mud", 64, 64, 64, 0.5f, ToolType.Shovel, -1, "Natural");
            R2(BlockId.RedSand, "Red Sand", 65, 65, 65, 0.5f, ToolType.Shovel, -1, "Natural");
            R2(BlockId.Terracotta, "Terracotta", 66, 66, 66, 1.2f, ToolType.Pickaxe, 0, "Building");
            R2(BlockId.PackedIce, "Packed Ice", 67, 67, 67, 0.5f, ToolType.Pickaxe, -1, "Natural");
            R2(BlockId.Ice, "Ice", 68, 68, 68, 0.5f, ToolType.Pickaxe, -1, "Natural", true, true, false);
            R2(BlockId.Moss, "Moss Block", 69, 69, 69, 0.1f, ToolType.None, -1, "Natural");
            R2(BlockId.Mycelium, "Mycelium", 70, 71, 72, 0.6f, ToolType.Shovel, -1, "Natural");
            R2(BlockId.Obsidian, "Obsidian", 73, 73, 73, 50f, ToolType.Pickaxe, 3, "Natural");
            R2(BlockId.GoldOre, "Gold Ore", 74, 74, 74, 3.0f, ToolType.Pickaxe, 2, "Natural");
            defs[(int)BlockId.GoldOre].Drop = (ushort)ItemId.RawGold;
            R2(BlockId.CopperOre, "Copper Ore", 75, 75, 75, 3.0f, ToolType.Pickaxe, 1, "Natural");
            defs[(int)BlockId.CopperOre].Drop = (ushort)ItemId.RawCopper;
            R2(BlockId.RedstoneOre, "Redstone Ore", 76, 76, 76, 3.0f, ToolType.Pickaxe, 2, "Natural");
            defs[(int)BlockId.RedstoneOre].Drop = (ushort)ItemId.Redstone;
            R2(BlockId.LapisOre, "Lapis Lazuli Ore", 77, 77, 77, 3.0f, ToolType.Pickaxe, 1, "Natural");
            defs[(int)BlockId.LapisOre].Drop = (ushort)ItemId.Lapis;
            R2(BlockId.DiamondOre, "Diamond Ore", 78, 78, 78, 3.0f, ToolType.Pickaxe, 2, "Natural");
            defs[(int)BlockId.DiamondOre].Drop = (ushort)ItemId.Diamond;
            R2(BlockId.EmeraldOre, "Emerald Ore", 79, 79, 79, 3.0f, ToolType.Pickaxe, 2, "Natural");
            defs[(int)BlockId.EmeraldOre].Drop = (ushort)ItemId.Emerald;
            R2(BlockId.QuartzOre, "Nether Quartz Ore", 80, 80, 80, 3.0f, ToolType.Pickaxe, 0, "Natural");
            defs[(int)BlockId.QuartzOre].Drop = (ushort)ItemId.Quartz;
            R2(BlockId.BirchLog, "Birch Log", 81, 82, 81, 2.0f, ToolType.Axe, -1, "Natural");
            R2(BlockId.BirchPlanks, "Birch Planks", 83, 83, 83, 2.0f, ToolType.Axe, -1, "Building");
            R2(BlockId.BirchLeaves, "Birch Leaves", 84, 84, 84, 0.2f, ToolType.None, -1, "Natural", true, true, false);
            defs[(int)BlockId.BirchLeaves].Drop = 0;
            R2(BlockId.SpruceLog, "Spruce Log", 85, 86, 85, 2.0f, ToolType.Axe, -1, "Natural");
            R2(BlockId.SprucePlanks, "Spruce Planks", 87, 87, 87, 2.0f, ToolType.Axe, -1, "Building");
            R2(BlockId.SpruceLeaves, "Spruce Leaves", 88, 88, 88, 0.2f, ToolType.None, -1, "Natural", true, true, false);
            defs[(int)BlockId.SpruceLeaves].Drop = 0;
            R2(BlockId.JungleLog, "Jungle Log", 89, 90, 89, 2.0f, ToolType.Axe, -1, "Natural");
            R2(BlockId.JunglePlanks, "Jungle Planks", 91, 91, 91, 2.0f, ToolType.Axe, -1, "Building");
            R2(BlockId.JungleLeaves, "Jungle Leaves", 92, 92, 92, 0.2f, ToolType.None, -1, "Natural", true, true, false);
            defs[(int)BlockId.JungleLeaves].Drop = 0;
            R2(BlockId.AcaciaLog, "Acacia Log", 93, 94, 93, 2.0f, ToolType.Axe, -1, "Natural");
            R2(BlockId.AcaciaPlanks, "Acacia Planks", 95, 95, 95, 2.0f, ToolType.Axe, -1, "Building");
            R2(BlockId.AcaciaLeaves, "Acacia Leaves", 96, 96, 96, 0.2f, ToolType.None, -1, "Natural", true, true, false);
            defs[(int)BlockId.AcaciaLeaves].Drop = 0;
            R2(BlockId.DarkOakLog, "Dark Oak Log", 97, 98, 97, 2.0f, ToolType.Axe, -1, "Natural");
            R2(BlockId.DarkOakPlanks, "Dark Oak Planks", 99, 99, 99, 2.0f, ToolType.Axe, -1, "Building");
            R2(BlockId.DarkOakLeaves, "Dark Oak Leaves", 100, 100, 100, 0.2f, ToolType.None, -1, "Natural", true, true, false);
            defs[(int)BlockId.DarkOakLeaves].Drop = 0;
            R2(BlockId.Bricks, "Bricks", 101, 101, 101, 2.0f, ToolType.Pickaxe, 0, "Building");
            R2(BlockId.StoneBricks, "Stone Bricks", 102, 102, 102, 1.5f, ToolType.Pickaxe, 0, "Building");
            R2(BlockId.Sandstone, "Sandstone", 103, 104, 103, 0.8f, ToolType.Pickaxe, 0, "Building");
            R2(BlockId.WhiteWool, "White Wool", 105, 105, 105, 0.8f, ToolType.None, -1, "Building");
            R2(BlockId.RedWool, "Red Wool", 106, 106, 106, 0.8f, ToolType.None, -1, "Building");
            R2(BlockId.OrangeWool, "Orange Wool", 107, 107, 107, 0.8f, ToolType.None, -1, "Building");
            R2(BlockId.YellowWool, "Yellow Wool", 108, 108, 108, 0.8f, ToolType.None, -1, "Building");
            R2(BlockId.LimeWool, "Lime Wool", 109, 109, 109, 0.8f, ToolType.None, -1, "Building");
            R2(BlockId.BlueWool, "Blue Wool", 110, 110, 110, 0.8f, ToolType.None, -1, "Building");
            R2(BlockId.PurpleWool, "Purple Wool", 111, 111, 111, 0.8f, ToolType.None, -1, "Building");
            R2(BlockId.BlackWool, "Black Wool", 112, 112, 112, 0.8f, ToolType.None, -1, "Building");
            R2(BlockId.Bookshelf, "Bookshelf", 113, 114, 113, 1.5f, ToolType.Axe, -1, "Functional");
            R2(BlockId.IronBlock, "Block of Iron", 115, 115, 115, 5.0f, ToolType.Pickaxe, 1, "Building");
            R2(BlockId.GoldBlock, "Block of Gold", 116, 116, 116, 5.0f, ToolType.Pickaxe, 2, "Building");
            R2(BlockId.DiamondBlock, "Block of Diamond", 117, 117, 117, 5.0f, ToolType.Pickaxe, 2, "Building");
            R2(BlockId.CoalBlock, "Block of Coal", 118, 118, 118, 5.0f, ToolType.Pickaxe, 0, "Building");
            R2(BlockId.Netherrack, "Netherrack", 119, 119, 119, 0.4f, ToolType.Pickaxe, 0, "Natural");
            R2(BlockId.SoulSand, "Soul Sand", 120, 120, 120, 0.5f, ToolType.Shovel, -1, "Natural");
            R2(BlockId.NetherBricks, "Nether Bricks", 121, 121, 121, 2.0f, ToolType.Pickaxe, 0, "Building");
            R2(BlockId.Glowstone, "Glowstone", 122, 122, 122, 0.3f, ToolType.None, -1, "Building");
            R2(BlockId.EndStone, "End Stone", 123, 123, 123, 3.0f, ToolType.Pickaxe, 0, "Natural");
            R2(BlockId.Lava, "Lava", 124, 124, 124, 100f, ToolType.None, -1, "Natural", true, false, true);
            defs[(int)BlockId.Lava].Drop = 0;
            foreach (var nb in new[] { BlockId.Grass, BlockId.Dirt, BlockId.Stone, BlockId.Sand, BlockId.Bedrock, BlockId.OakLog, BlockId.OakLeaves, BlockId.Snow, BlockId.Cactus, BlockId.CoalOre, BlockId.IronOre }) defs[(int)nb].Cat = "Natural";
            foreach (var nb in new[] { BlockId.CraftingTable, BlockId.Furnace, BlockId.Chest, BlockId.Bed, BlockId.Farmland }) defs[(int)nb].Cat = "Functional";
            foreach (var nb in new[] { BlockId.Water, BlockId.LootChest, BlockId.Wheat0, BlockId.Wheat1, BlockId.Wheat2, BlockId.Wheat3 }) defs[(int)nb].Hidden = true;
            R2(BlockId.MagentaWool, "Magenta Wool", 151, 151, 151, 0.8f, ToolType.None, -1, "Building");
            R2(BlockId.LightBlueWool, "Light Blue Wool", 152, 152, 152, 0.8f, ToolType.None, -1, "Building");
            R2(BlockId.PinkWool, "Pink Wool", 153, 153, 153, 0.8f, ToolType.None, -1, "Building");
            R2(BlockId.GrayWool, "Gray Wool", 154, 154, 154, 0.8f, ToolType.None, -1, "Building");
            R2(BlockId.LightGrayWool, "Light Gray Wool", 155, 155, 155, 0.8f, ToolType.None, -1, "Building");
            R2(BlockId.CyanWool, "Cyan Wool", 156, 156, 156, 0.8f, ToolType.None, -1, "Building");
            R2(BlockId.BrownWool, "Brown Wool", 157, 157, 157, 0.8f, ToolType.None, -1, "Building");
            R2(BlockId.GreenWool, "Green Wool", 158, 158, 158, 0.8f, ToolType.None, -1, "Building");
            R2(BlockId.WhiteConcrete, "White Concrete", 159, 159, 159, 1.8f, ToolType.Pickaxe, 0, "Building");
            R2(BlockId.OrangeConcrete, "Orange Concrete", 160, 160, 160, 1.8f, ToolType.Pickaxe, 0, "Building");
            R2(BlockId.MagentaConcrete, "Magenta Concrete", 161, 161, 161, 1.8f, ToolType.Pickaxe, 0, "Building");
            R2(BlockId.LightBlueConcrete, "Light Blue Concrete", 162, 162, 162, 1.8f, ToolType.Pickaxe, 0, "Building");
            R2(BlockId.YellowConcrete, "Yellow Concrete", 163, 163, 163, 1.8f, ToolType.Pickaxe, 0, "Building");
            R2(BlockId.LimeConcrete, "Lime Concrete", 164, 164, 164, 1.8f, ToolType.Pickaxe, 0, "Building");
            R2(BlockId.PinkConcrete, "Pink Concrete", 165, 165, 165, 1.8f, ToolType.Pickaxe, 0, "Building");
            R2(BlockId.GrayConcrete, "Gray Concrete", 166, 166, 166, 1.8f, ToolType.Pickaxe, 0, "Building");
            R2(BlockId.LightGrayConcrete, "Light Gray Concrete", 167, 167, 167, 1.8f, ToolType.Pickaxe, 0, "Building");
            R2(BlockId.CyanConcrete, "Cyan Concrete", 168, 168, 168, 1.8f, ToolType.Pickaxe, 0, "Building");
            R2(BlockId.PurpleConcrete, "Purple Concrete", 169, 169, 169, 1.8f, ToolType.Pickaxe, 0, "Building");
            R2(BlockId.BlueConcrete, "Blue Concrete", 170, 170, 170, 1.8f, ToolType.Pickaxe, 0, "Building");
            R2(BlockId.BrownConcrete, "Brown Concrete", 171, 171, 171, 1.8f, ToolType.Pickaxe, 0, "Building");
            R2(BlockId.GreenConcrete, "Green Concrete", 172, 172, 172, 1.8f, ToolType.Pickaxe, 0, "Building");
            R2(BlockId.RedConcrete, "Red Concrete", 173, 173, 173, 1.8f, ToolType.Pickaxe, 0, "Building");
            R2(BlockId.BlackConcrete, "Black Concrete", 174, 174, 174, 1.8f, ToolType.Pickaxe, 0, "Building");
            R2(BlockId.WhiteTerracotta, "White Terracotta", 175, 175, 175, 1.2f, ToolType.Pickaxe, 0, "Building");
            R2(BlockId.OrangeTerracotta, "Orange Terracotta", 176, 176, 176, 1.2f, ToolType.Pickaxe, 0, "Building");
            R2(BlockId.MagentaTerracotta, "Magenta Terracotta", 177, 177, 177, 1.2f, ToolType.Pickaxe, 0, "Building");
            R2(BlockId.LightBlueTerracotta, "Light Blue Terracotta", 178, 178, 178, 1.2f, ToolType.Pickaxe, 0, "Building");
            R2(BlockId.YellowTerracotta, "Yellow Terracotta", 179, 179, 179, 1.2f, ToolType.Pickaxe, 0, "Building");
            R2(BlockId.LimeTerracotta, "Lime Terracotta", 180, 180, 180, 1.2f, ToolType.Pickaxe, 0, "Building");
            R2(BlockId.PinkTerracotta, "Pink Terracotta", 181, 181, 181, 1.2f, ToolType.Pickaxe, 0, "Building");
            R2(BlockId.GrayTerracotta, "Gray Terracotta", 182, 182, 182, 1.2f, ToolType.Pickaxe, 0, "Building");
            R2(BlockId.LightGrayTerracotta, "Light Gray Terracotta", 183, 183, 183, 1.2f, ToolType.Pickaxe, 0, "Building");
            R2(BlockId.CyanTerracotta, "Cyan Terracotta", 184, 184, 184, 1.2f, ToolType.Pickaxe, 0, "Building");
            R2(BlockId.PurpleTerracotta, "Purple Terracotta", 185, 185, 185, 1.2f, ToolType.Pickaxe, 0, "Building");
            R2(BlockId.BlueTerracotta, "Blue Terracotta", 186, 186, 186, 1.2f, ToolType.Pickaxe, 0, "Building");
            R2(BlockId.BrownTerracotta, "Brown Terracotta", 187, 187, 187, 1.2f, ToolType.Pickaxe, 0, "Building");
            R2(BlockId.GreenTerracotta, "Green Terracotta", 188, 188, 188, 1.2f, ToolType.Pickaxe, 0, "Building");
            R2(BlockId.RedTerracotta, "Red Terracotta", 189, 189, 189, 1.2f, ToolType.Pickaxe, 0, "Building");
            R2(BlockId.BlackTerracotta, "Black Terracotta", 190, 190, 190, 1.2f, ToolType.Pickaxe, 0, "Building");
            R2(BlockId.WhiteStainedGlass, "White Stained Glass", 191, 191, 191, 0.3f, ToolType.None, -1, "Building", true, true, false);
            defs[(int)BlockId.WhiteStainedGlass].Drop = 0;
            R2(BlockId.OrangeStainedGlass, "Orange Stained Glass", 192, 192, 192, 0.3f, ToolType.None, -1, "Building", true, true, false);
            defs[(int)BlockId.OrangeStainedGlass].Drop = 0;
            R2(BlockId.MagentaStainedGlass, "Magenta Stained Glass", 193, 193, 193, 0.3f, ToolType.None, -1, "Building", true, true, false);
            defs[(int)BlockId.MagentaStainedGlass].Drop = 0;
            R2(BlockId.LightBlueStainedGlass, "Light Blue Stained Glass", 194, 194, 194, 0.3f, ToolType.None, -1, "Building", true, true, false);
            defs[(int)BlockId.LightBlueStainedGlass].Drop = 0;
            R2(BlockId.YellowStainedGlass, "Yellow Stained Glass", 195, 195, 195, 0.3f, ToolType.None, -1, "Building", true, true, false);
            defs[(int)BlockId.YellowStainedGlass].Drop = 0;
            R2(BlockId.LimeStainedGlass, "Lime Stained Glass", 196, 196, 196, 0.3f, ToolType.None, -1, "Building", true, true, false);
            defs[(int)BlockId.LimeStainedGlass].Drop = 0;
            R2(BlockId.PinkStainedGlass, "Pink Stained Glass", 197, 197, 197, 0.3f, ToolType.None, -1, "Building", true, true, false);
            defs[(int)BlockId.PinkStainedGlass].Drop = 0;
            R2(BlockId.GrayStainedGlass, "Gray Stained Glass", 198, 198, 198, 0.3f, ToolType.None, -1, "Building", true, true, false);
            defs[(int)BlockId.GrayStainedGlass].Drop = 0;
            R2(BlockId.LightGrayStainedGlass, "Light Gray Stained Glass", 199, 199, 199, 0.3f, ToolType.None, -1, "Building", true, true, false);
            defs[(int)BlockId.LightGrayStainedGlass].Drop = 0;
            R2(BlockId.CyanStainedGlass, "Cyan Stained Glass", 200, 200, 200, 0.3f, ToolType.None, -1, "Building", true, true, false);
            defs[(int)BlockId.CyanStainedGlass].Drop = 0;
            R2(BlockId.PurpleStainedGlass, "Purple Stained Glass", 201, 201, 201, 0.3f, ToolType.None, -1, "Building", true, true, false);
            defs[(int)BlockId.PurpleStainedGlass].Drop = 0;
            R2(BlockId.BlueStainedGlass, "Blue Stained Glass", 202, 202, 202, 0.3f, ToolType.None, -1, "Building", true, true, false);
            defs[(int)BlockId.BlueStainedGlass].Drop = 0;
            R2(BlockId.BrownStainedGlass, "Brown Stained Glass", 203, 203, 203, 0.3f, ToolType.None, -1, "Building", true, true, false);
            defs[(int)BlockId.BrownStainedGlass].Drop = 0;
            R2(BlockId.GreenStainedGlass, "Green Stained Glass", 204, 204, 204, 0.3f, ToolType.None, -1, "Building", true, true, false);
            defs[(int)BlockId.GreenStainedGlass].Drop = 0;
            R2(BlockId.RedStainedGlass, "Red Stained Glass", 205, 205, 205, 0.3f, ToolType.None, -1, "Building", true, true, false);
            defs[(int)BlockId.RedStainedGlass].Drop = 0;
            R2(BlockId.BlackStainedGlass, "Black Stained Glass", 206, 206, 206, 0.3f, ToolType.None, -1, "Building", true, true, false);
            defs[(int)BlockId.BlackStainedGlass].Drop = 0;
            RS(BlockId.Torch, "Torch", 207, 207, 207, 0.0f, ToolType.None, -1, "Functional", Shape.Torch, false, 9, 0, 0, false);
            RS(BlockId.Ladder, "Ladder", 208, 208, 208, 0.4f, ToolType.Axe, -1, "Functional", Shape.Ladder, false, 0, 0, 0, false);
            RS(BlockId.Rail, "Rail", 209, 210, 209, 0.7f, ToolType.Pickaxe, -1, "Functional", Shape.Rail, false, 0, 0, 0, false);
            RS(BlockId.GlassPane, "Glass Pane", 11, 11, 11, 0.3f, ToolType.None, -1, "Building", Shape.Pane, true, 0, 0, 0, false);
            RS(BlockId.WhiteStainedGlassPane, "White Stained Glass Pane", 191, 191, 191, 0.3f, ToolType.None, -1, "Building", Shape.Pane, true, 0, 0, 0, false);
            RS(BlockId.OrangeStainedGlassPane, "Orange Stained Glass Pane", 192, 192, 192, 0.3f, ToolType.None, -1, "Building", Shape.Pane, true, 0, 0, 0, false);
            RS(BlockId.MagentaStainedGlassPane, "Magenta Stained Glass Pane", 193, 193, 193, 0.3f, ToolType.None, -1, "Building", Shape.Pane, true, 0, 0, 0, false);
            RS(BlockId.LightBlueStainedGlassPane, "Light Blue Stained Glass Pane", 194, 194, 194, 0.3f, ToolType.None, -1, "Building", Shape.Pane, true, 0, 0, 0, false);
            RS(BlockId.YellowStainedGlassPane, "Yellow Stained Glass Pane", 195, 195, 195, 0.3f, ToolType.None, -1, "Building", Shape.Pane, true, 0, 0, 0, false);
            RS(BlockId.LimeStainedGlassPane, "Lime Stained Glass Pane", 196, 196, 196, 0.3f, ToolType.None, -1, "Building", Shape.Pane, true, 0, 0, 0, false);
            RS(BlockId.PinkStainedGlassPane, "Pink Stained Glass Pane", 197, 197, 197, 0.3f, ToolType.None, -1, "Building", Shape.Pane, true, 0, 0, 0, false);
            RS(BlockId.GrayStainedGlassPane, "Gray Stained Glass Pane", 198, 198, 198, 0.3f, ToolType.None, -1, "Building", Shape.Pane, true, 0, 0, 0, false);
            RS(BlockId.LightGrayStainedGlassPane, "Light Gray Stained Glass Pane", 199, 199, 199, 0.3f, ToolType.None, -1, "Building", Shape.Pane, true, 0, 0, 0, false);
            RS(BlockId.CyanStainedGlassPane, "Cyan Stained Glass Pane", 200, 200, 200, 0.3f, ToolType.None, -1, "Building", Shape.Pane, true, 0, 0, 0, false);
            RS(BlockId.PurpleStainedGlassPane, "Purple Stained Glass Pane", 201, 201, 201, 0.3f, ToolType.None, -1, "Building", Shape.Pane, true, 0, 0, 0, false);
            RS(BlockId.BlueStainedGlassPane, "Blue Stained Glass Pane", 202, 202, 202, 0.3f, ToolType.None, -1, "Building", Shape.Pane, true, 0, 0, 0, false);
            RS(BlockId.BrownStainedGlassPane, "Brown Stained Glass Pane", 203, 203, 203, 0.3f, ToolType.None, -1, "Building", Shape.Pane, true, 0, 0, 0, false);
            RS(BlockId.GreenStainedGlassPane, "Green Stained Glass Pane", 204, 204, 204, 0.3f, ToolType.None, -1, "Building", Shape.Pane, true, 0, 0, 0, false);
            RS(BlockId.RedStainedGlassPane, "Red Stained Glass Pane", 205, 205, 205, 0.3f, ToolType.None, -1, "Building", Shape.Pane, true, 0, 0, 0, false);
            RS(BlockId.BlackStainedGlassPane, "Black Stained Glass Pane", 206, 206, 206, 0.3f, ToolType.None, -1, "Building", Shape.Pane, true, 0, 0, 0, false);
            RS(BlockId.OakSlab, "Oak Slab", 16, 16, 16, 2.0f, ToolType.Axe, -1, "Building", Shape.Slab, true, 0, 0, (int)BlockId.Planks, false);
            RS(BlockId.OakStairs0, "Oak Stairs", 16, 16, 16, 2.0f, ToolType.Axe, -1, "Building", Shape.Stair, true, 0, 0, 0, false);
            RS(BlockId.OakStairs1, "Oak Stairs", 16, 16, 16, 2.0f, ToolType.Axe, -1, "Building", Shape.Stair, true, 0, 1, 0, true);
            defs[(int)BlockId.OakStairs1].Drop = (ushort)BlockId.OakStairs0;
            RS(BlockId.OakStairs2, "Oak Stairs", 16, 16, 16, 2.0f, ToolType.Axe, -1, "Building", Shape.Stair, true, 0, 2, 0, true);
            defs[(int)BlockId.OakStairs2].Drop = (ushort)BlockId.OakStairs0;
            RS(BlockId.OakStairs3, "Oak Stairs", 16, 16, 16, 2.0f, ToolType.Axe, -1, "Building", Shape.Stair, true, 0, 3, 0, true);
            defs[(int)BlockId.OakStairs3].Drop = (ushort)BlockId.OakStairs0;
            RS(BlockId.SpruceSlab, "Spruce Slab", 87, 87, 87, 2.0f, ToolType.Axe, -1, "Building", Shape.Slab, true, 0, 0, (int)BlockId.SprucePlanks, false);
            RS(BlockId.SpruceStairs0, "Spruce Stairs", 87, 87, 87, 2.0f, ToolType.Axe, -1, "Building", Shape.Stair, true, 0, 0, 0, false);
            RS(BlockId.SpruceStairs1, "Spruce Stairs", 87, 87, 87, 2.0f, ToolType.Axe, -1, "Building", Shape.Stair, true, 0, 1, 0, true);
            defs[(int)BlockId.SpruceStairs1].Drop = (ushort)BlockId.SpruceStairs0;
            RS(BlockId.SpruceStairs2, "Spruce Stairs", 87, 87, 87, 2.0f, ToolType.Axe, -1, "Building", Shape.Stair, true, 0, 2, 0, true);
            defs[(int)BlockId.SpruceStairs2].Drop = (ushort)BlockId.SpruceStairs0;
            RS(BlockId.SpruceStairs3, "Spruce Stairs", 87, 87, 87, 2.0f, ToolType.Axe, -1, "Building", Shape.Stair, true, 0, 3, 0, true);
            defs[(int)BlockId.SpruceStairs3].Drop = (ushort)BlockId.SpruceStairs0;
            RS(BlockId.BirchSlab, "Birch Slab", 83, 83, 83, 2.0f, ToolType.Axe, -1, "Building", Shape.Slab, true, 0, 0, (int)BlockId.BirchPlanks, false);
            RS(BlockId.BirchStairs0, "Birch Stairs", 83, 83, 83, 2.0f, ToolType.Axe, -1, "Building", Shape.Stair, true, 0, 0, 0, false);
            RS(BlockId.BirchStairs1, "Birch Stairs", 83, 83, 83, 2.0f, ToolType.Axe, -1, "Building", Shape.Stair, true, 0, 1, 0, true);
            defs[(int)BlockId.BirchStairs1].Drop = (ushort)BlockId.BirchStairs0;
            RS(BlockId.BirchStairs2, "Birch Stairs", 83, 83, 83, 2.0f, ToolType.Axe, -1, "Building", Shape.Stair, true, 0, 2, 0, true);
            defs[(int)BlockId.BirchStairs2].Drop = (ushort)BlockId.BirchStairs0;
            RS(BlockId.BirchStairs3, "Birch Stairs", 83, 83, 83, 2.0f, ToolType.Axe, -1, "Building", Shape.Stair, true, 0, 3, 0, true);
            defs[(int)BlockId.BirchStairs3].Drop = (ushort)BlockId.BirchStairs0;
            RS(BlockId.JungleSlab, "Jungle Slab", 91, 91, 91, 2.0f, ToolType.Axe, -1, "Building", Shape.Slab, true, 0, 0, (int)BlockId.JunglePlanks, false);
            RS(BlockId.JungleStairs0, "Jungle Stairs", 91, 91, 91, 2.0f, ToolType.Axe, -1, "Building", Shape.Stair, true, 0, 0, 0, false);
            RS(BlockId.JungleStairs1, "Jungle Stairs", 91, 91, 91, 2.0f, ToolType.Axe, -1, "Building", Shape.Stair, true, 0, 1, 0, true);
            defs[(int)BlockId.JungleStairs1].Drop = (ushort)BlockId.JungleStairs0;
            RS(BlockId.JungleStairs2, "Jungle Stairs", 91, 91, 91, 2.0f, ToolType.Axe, -1, "Building", Shape.Stair, true, 0, 2, 0, true);
            defs[(int)BlockId.JungleStairs2].Drop = (ushort)BlockId.JungleStairs0;
            RS(BlockId.JungleStairs3, "Jungle Stairs", 91, 91, 91, 2.0f, ToolType.Axe, -1, "Building", Shape.Stair, true, 0, 3, 0, true);
            defs[(int)BlockId.JungleStairs3].Drop = (ushort)BlockId.JungleStairs0;
            RS(BlockId.AcaciaSlab, "Acacia Slab", 95, 95, 95, 2.0f, ToolType.Axe, -1, "Building", Shape.Slab, true, 0, 0, (int)BlockId.AcaciaPlanks, false);
            RS(BlockId.AcaciaStairs0, "Acacia Stairs", 95, 95, 95, 2.0f, ToolType.Axe, -1, "Building", Shape.Stair, true, 0, 0, 0, false);
            RS(BlockId.AcaciaStairs1, "Acacia Stairs", 95, 95, 95, 2.0f, ToolType.Axe, -1, "Building", Shape.Stair, true, 0, 1, 0, true);
            defs[(int)BlockId.AcaciaStairs1].Drop = (ushort)BlockId.AcaciaStairs0;
            RS(BlockId.AcaciaStairs2, "Acacia Stairs", 95, 95, 95, 2.0f, ToolType.Axe, -1, "Building", Shape.Stair, true, 0, 2, 0, true);
            defs[(int)BlockId.AcaciaStairs2].Drop = (ushort)BlockId.AcaciaStairs0;
            RS(BlockId.AcaciaStairs3, "Acacia Stairs", 95, 95, 95, 2.0f, ToolType.Axe, -1, "Building", Shape.Stair, true, 0, 3, 0, true);
            defs[(int)BlockId.AcaciaStairs3].Drop = (ushort)BlockId.AcaciaStairs0;
            RS(BlockId.DarkOakSlab, "Dark Oak Slab", 99, 99, 99, 2.0f, ToolType.Axe, -1, "Building", Shape.Slab, true, 0, 0, (int)BlockId.DarkOakPlanks, false);
            RS(BlockId.DarkOakStairs0, "Dark Oak Stairs", 99, 99, 99, 2.0f, ToolType.Axe, -1, "Building", Shape.Stair, true, 0, 0, 0, false);
            RS(BlockId.DarkOakStairs1, "Dark Oak Stairs", 99, 99, 99, 2.0f, ToolType.Axe, -1, "Building", Shape.Stair, true, 0, 1, 0, true);
            defs[(int)BlockId.DarkOakStairs1].Drop = (ushort)BlockId.DarkOakStairs0;
            RS(BlockId.DarkOakStairs2, "Dark Oak Stairs", 99, 99, 99, 2.0f, ToolType.Axe, -1, "Building", Shape.Stair, true, 0, 2, 0, true);
            defs[(int)BlockId.DarkOakStairs2].Drop = (ushort)BlockId.DarkOakStairs0;
            RS(BlockId.DarkOakStairs3, "Dark Oak Stairs", 99, 99, 99, 2.0f, ToolType.Axe, -1, "Building", Shape.Stair, true, 0, 3, 0, true);
            defs[(int)BlockId.DarkOakStairs3].Drop = (ushort)BlockId.DarkOakStairs0;
            RS(BlockId.CobbleSlab, "Cobblestone Slab", 19, 19, 19, 2.0f, ToolType.Pickaxe, 0, "Building", Shape.Slab, true, 0, 0, (int)BlockId.Cobblestone, false);
            RS(BlockId.CobbleStairs0, "Cobblestone Stairs", 19, 19, 19, 2.0f, ToolType.Pickaxe, 0, "Building", Shape.Stair, true, 0, 0, 0, false);
            RS(BlockId.CobbleStairs1, "Cobblestone Stairs", 19, 19, 19, 2.0f, ToolType.Pickaxe, 0, "Building", Shape.Stair, true, 0, 1, 0, true);
            defs[(int)BlockId.CobbleStairs1].Drop = (ushort)BlockId.CobbleStairs0;
            RS(BlockId.CobbleStairs2, "Cobblestone Stairs", 19, 19, 19, 2.0f, ToolType.Pickaxe, 0, "Building", Shape.Stair, true, 0, 2, 0, true);
            defs[(int)BlockId.CobbleStairs2].Drop = (ushort)BlockId.CobbleStairs0;
            RS(BlockId.CobbleStairs3, "Cobblestone Stairs", 19, 19, 19, 2.0f, ToolType.Pickaxe, 0, "Building", Shape.Stair, true, 0, 3, 0, true);
            defs[(int)BlockId.CobbleStairs3].Drop = (ushort)BlockId.CobbleStairs0;
            RS(BlockId.StoneSlab, "Stone Slab", 3, 3, 3, 2.0f, ToolType.Pickaxe, 0, "Building", Shape.Slab, true, 0, 0, (int)BlockId.Stone, false);
            RS(BlockId.StoneStairs0, "Stone Stairs", 3, 3, 3, 2.0f, ToolType.Pickaxe, 0, "Building", Shape.Stair, true, 0, 0, 0, false);
            RS(BlockId.StoneStairs1, "Stone Stairs", 3, 3, 3, 2.0f, ToolType.Pickaxe, 0, "Building", Shape.Stair, true, 0, 1, 0, true);
            defs[(int)BlockId.StoneStairs1].Drop = (ushort)BlockId.StoneStairs0;
            RS(BlockId.StoneStairs2, "Stone Stairs", 3, 3, 3, 2.0f, ToolType.Pickaxe, 0, "Building", Shape.Stair, true, 0, 2, 0, true);
            defs[(int)BlockId.StoneStairs2].Drop = (ushort)BlockId.StoneStairs0;
            RS(BlockId.StoneStairs3, "Stone Stairs", 3, 3, 3, 2.0f, ToolType.Pickaxe, 0, "Building", Shape.Stair, true, 0, 3, 0, true);
            defs[(int)BlockId.StoneStairs3].Drop = (ushort)BlockId.StoneStairs0;
            RS(BlockId.StoneBrickSlab, "Stone Brick Slab", 102, 102, 102, 2.0f, ToolType.Pickaxe, 0, "Building", Shape.Slab, true, 0, 0, (int)BlockId.StoneBricks, false);
            RS(BlockId.StoneBrickStairs0, "Stone Brick Stairs", 102, 102, 102, 2.0f, ToolType.Pickaxe, 0, "Building", Shape.Stair, true, 0, 0, 0, false);
            RS(BlockId.StoneBrickStairs1, "Stone Brick Stairs", 102, 102, 102, 2.0f, ToolType.Pickaxe, 0, "Building", Shape.Stair, true, 0, 1, 0, true);
            defs[(int)BlockId.StoneBrickStairs1].Drop = (ushort)BlockId.StoneBrickStairs0;
            RS(BlockId.StoneBrickStairs2, "Stone Brick Stairs", 102, 102, 102, 2.0f, ToolType.Pickaxe, 0, "Building", Shape.Stair, true, 0, 2, 0, true);
            defs[(int)BlockId.StoneBrickStairs2].Drop = (ushort)BlockId.StoneBrickStairs0;
            RS(BlockId.StoneBrickStairs3, "Stone Brick Stairs", 102, 102, 102, 2.0f, ToolType.Pickaxe, 0, "Building", Shape.Stair, true, 0, 3, 0, true);
            defs[(int)BlockId.StoneBrickStairs3].Drop = (ushort)BlockId.StoneBrickStairs0;
            RS(BlockId.BrickSlab, "Brick Slab", 101, 101, 101, 2.0f, ToolType.Pickaxe, 0, "Building", Shape.Slab, true, 0, 0, (int)BlockId.Bricks, false);
            RS(BlockId.BrickStairs0, "Brick Stairs", 101, 101, 101, 2.0f, ToolType.Pickaxe, 0, "Building", Shape.Stair, true, 0, 0, 0, false);
            RS(BlockId.BrickStairs1, "Brick Stairs", 101, 101, 101, 2.0f, ToolType.Pickaxe, 0, "Building", Shape.Stair, true, 0, 1, 0, true);
            defs[(int)BlockId.BrickStairs1].Drop = (ushort)BlockId.BrickStairs0;
            RS(BlockId.BrickStairs2, "Brick Stairs", 101, 101, 101, 2.0f, ToolType.Pickaxe, 0, "Building", Shape.Stair, true, 0, 2, 0, true);
            defs[(int)BlockId.BrickStairs2].Drop = (ushort)BlockId.BrickStairs0;
            RS(BlockId.BrickStairs3, "Brick Stairs", 101, 101, 101, 2.0f, ToolType.Pickaxe, 0, "Building", Shape.Stair, true, 0, 3, 0, true);
            defs[(int)BlockId.BrickStairs3].Drop = (ushort)BlockId.BrickStairs0;
            RS(BlockId.SandstoneSlab, "Sandstone Slab", 103, 104, 103, 2.0f, ToolType.Pickaxe, 0, "Building", Shape.Slab, true, 0, 0, (int)BlockId.Sandstone, false);
            RS(BlockId.SandstoneStairs0, "Sandstone Stairs", 103, 104, 103, 2.0f, ToolType.Pickaxe, 0, "Building", Shape.Stair, true, 0, 0, 0, false);
            RS(BlockId.SandstoneStairs1, "Sandstone Stairs", 103, 104, 103, 2.0f, ToolType.Pickaxe, 0, "Building", Shape.Stair, true, 0, 1, 0, true);
            defs[(int)BlockId.SandstoneStairs1].Drop = (ushort)BlockId.SandstoneStairs0;
            RS(BlockId.SandstoneStairs2, "Sandstone Stairs", 103, 104, 103, 2.0f, ToolType.Pickaxe, 0, "Building", Shape.Stair, true, 0, 2, 0, true);
            defs[(int)BlockId.SandstoneStairs2].Drop = (ushort)BlockId.SandstoneStairs0;
            RS(BlockId.SandstoneStairs3, "Sandstone Stairs", 103, 104, 103, 2.0f, ToolType.Pickaxe, 0, "Building", Shape.Stair, true, 0, 3, 0, true);
            defs[(int)BlockId.SandstoneStairs3].Drop = (ushort)BlockId.SandstoneStairs0;
            RS(BlockId.NetherBrickSlab, "Nether Brick Slab", 121, 121, 121, 2.0f, ToolType.Pickaxe, 0, "Building", Shape.Slab, true, 0, 0, (int)BlockId.NetherBricks, false);
            RS(BlockId.NetherBrickStairs0, "Nether Brick Stairs", 121, 121, 121, 2.0f, ToolType.Pickaxe, 0, "Building", Shape.Stair, true, 0, 0, 0, false);
            RS(BlockId.NetherBrickStairs1, "Nether Brick Stairs", 121, 121, 121, 2.0f, ToolType.Pickaxe, 0, "Building", Shape.Stair, true, 0, 1, 0, true);
            defs[(int)BlockId.NetherBrickStairs1].Drop = (ushort)BlockId.NetherBrickStairs0;
            RS(BlockId.NetherBrickStairs2, "Nether Brick Stairs", 121, 121, 121, 2.0f, ToolType.Pickaxe, 0, "Building", Shape.Stair, true, 0, 2, 0, true);
            defs[(int)BlockId.NetherBrickStairs2].Drop = (ushort)BlockId.NetherBrickStairs0;
            RS(BlockId.NetherBrickStairs3, "Nether Brick Stairs", 121, 121, 121, 2.0f, ToolType.Pickaxe, 0, "Building", Shape.Stair, true, 0, 3, 0, true);
            defs[(int)BlockId.NetherBrickStairs3].Drop = (ushort)BlockId.NetherBrickStairs0;
            RS(BlockId.OakFence, "Oak Fence", 16, 16, 16, 2.0f, ToolType.Axe, -1, "Building", Shape.Fence, true, 0, 0, 0, false);
            RS(BlockId.SpruceFence, "Spruce Fence", 87, 87, 87, 2.0f, ToolType.Axe, -1, "Building", Shape.Fence, true, 0, 0, 0, false);
            RS(BlockId.BirchFence, "Birch Fence", 83, 83, 83, 2.0f, ToolType.Axe, -1, "Building", Shape.Fence, true, 0, 0, 0, false);
            RS(BlockId.JungleFence, "Jungle Fence", 91, 91, 91, 2.0f, ToolType.Axe, -1, "Building", Shape.Fence, true, 0, 0, 0, false);
            RS(BlockId.AcaciaFence, "Acacia Fence", 95, 95, 95, 2.0f, ToolType.Axe, -1, "Building", Shape.Fence, true, 0, 0, 0, false);
            RS(BlockId.DarkOakFence, "Dark Oak Fence", 99, 99, 99, 2.0f, ToolType.Axe, -1, "Building", Shape.Fence, true, 0, 0, 0, false);
            RS(BlockId.NetherBrickFence, "Nether Brick Fence", 121, 121, 121, 2.0f, ToolType.Pickaxe, 0, "Building", Shape.Fence, true, 0, 0, 0, false);
            defs[(int)BlockId.Glowstone].Light = 12; defs[(int)BlockId.Lava].Light = 10;
            R2(BlockId.MangroveLog, "Mangrove Log", 215, 216, 215, 2.0f, ToolType.Axe, -1, "Natural");
            R2(BlockId.MangrovePlanks, "Mangrove Planks", 217, 217, 217, 2.0f, ToolType.Axe, -1, "Building");
            R2(BlockId.MangroveLeaves, "Mangrove Leaves", 218, 218, 218, 0.2f, ToolType.None, -1, "Natural", true, true, false);
            defs[(int)BlockId.MangroveLeaves].Drop = 0;
            R2(BlockId.CherryLog, "Cherry Log", 219, 220, 219, 2.0f, ToolType.Axe, -1, "Natural");
            R2(BlockId.CherryPlanks, "Cherry Planks", 221, 221, 221, 2.0f, ToolType.Axe, -1, "Building");
            R2(BlockId.CherryLeaves, "Cherry Leaves", 222, 222, 222, 0.2f, ToolType.None, -1, "Natural", true, true, false);
            defs[(int)BlockId.CherryLeaves].Drop = 0;
            R2(BlockId.CrimsonStem, "Crimson Stem", 223, 224, 223, 2.0f, ToolType.Axe, -1, "Natural");
            R2(BlockId.CrimsonPlanks, "Crimson Planks", 225, 225, 225, 2.0f, ToolType.Axe, -1, "Building");
            R2(BlockId.WarpedStem, "Warped Stem", 226, 227, 226, 2.0f, ToolType.Axe, -1, "Natural");
            R2(BlockId.WarpedPlanks, "Warped Planks", 228, 228, 228, 2.0f, ToolType.Axe, -1, "Building");
            R2(BlockId.BambooBlock, "Block of Bamboo", 229, 230, 229, 2.0f, ToolType.Axe, -1, "Natural");
            R2(BlockId.BambooPlanks, "Bamboo Planks", 231, 231, 231, 2.0f, ToolType.Axe, -1, "Building");
            R2(BlockId.PolishedGranite, "Polished Granite", 232, 232, 232, 1.5f, ToolType.Pickaxe, 0, "Building");
            R2(BlockId.PolishedDiorite, "Polished Diorite", 233, 233, 233, 1.5f, ToolType.Pickaxe, 0, "Building");
            R2(BlockId.PolishedAndesite, "Polished Andesite", 234, 234, 234, 1.5f, ToolType.Pickaxe, 0, "Building");
            R2(BlockId.SmoothStone, "Smooth Stone", 235, 235, 235, 1.5f, ToolType.Pickaxe, 0, "Building");
            R2(BlockId.MossyCobblestone, "Mossy Cobblestone", 236, 236, 236, 2.0f, ToolType.Pickaxe, 0, "Building");
            R2(BlockId.MossyStoneBricks, "Mossy Stone Bricks", 237, 237, 237, 1.5f, ToolType.Pickaxe, 0, "Building");
            R2(BlockId.CrackedStoneBricks, "Cracked Stone Bricks", 238, 238, 238, 1.5f, ToolType.Pickaxe, 0, "Building");
            R2(BlockId.ChiseledStoneBricks, "Chiseled Stone Bricks", 239, 239, 239, 1.5f, ToolType.Pickaxe, 0, "Building");
            R2(BlockId.Calcite, "Calcite", 240, 240, 240, 0.75f, ToolType.Pickaxe, 0, "Natural");
            R2(BlockId.Tuff, "Tuff", 241, 241, 241, 1.5f, ToolType.Pickaxe, 0, "Natural");
            R2(BlockId.Basalt, "Basalt", 242, 243, 242, 1.25f, ToolType.Pickaxe, 0, "Natural");
            R2(BlockId.Blackstone, "Blackstone", 244, 244, 244, 1.5f, ToolType.Pickaxe, 0, "Natural");
            R2(BlockId.PolishedBlackstone, "Polished Blackstone", 245, 245, 245, 2.0f, ToolType.Pickaxe, 0, "Building");
            R2(BlockId.CryingObsidian, "Crying Obsidian", 246, 246, 246, 50f, ToolType.Pickaxe, 3, "Natural");
            defs[(int)BlockId.CryingObsidian].Light = 10;
            R2(BlockId.DripstoneBlock, "Dripstone Block", 247, 247, 247, 1.5f, ToolType.Pickaxe, 0, "Natural");
            R2(BlockId.CopperBlock, "Block of Copper", 248, 248, 248, 3.0f, ToolType.Pickaxe, 1, "Building");
            R2(BlockId.ExposedCopper, "Exposed Copper", 249, 249, 249, 3.0f, ToolType.Pickaxe, 1, "Building");
            R2(BlockId.WeatheredCopper, "Weathered Copper", 250, 250, 250, 3.0f, ToolType.Pickaxe, 1, "Building");
            R2(BlockId.OxidizedCopper, "Oxidized Copper", 251, 251, 251, 3.0f, ToolType.Pickaxe, 1, "Building");
            R2(BlockId.CutCopper, "Cut Copper", 252, 252, 252, 3.0f, ToolType.Pickaxe, 1, "Building");
            R2(BlockId.QuartzBlock, "Block of Quartz", 253, 253, 253, 0.8f, ToolType.Pickaxe, 0, "Building");
            R2(BlockId.QuartzPillar, "Quartz Pillar", 253, 254, 253, 0.8f, ToolType.Pickaxe, 0, "Building");
            R2(BlockId.ChiseledQuartz, "Chiseled Quartz Block", 255, 255, 255, 0.8f, ToolType.Pickaxe, 0, "Building");
            R2(BlockId.Purpur, "Purpur Block", 256, 256, 256, 1.5f, ToolType.Pickaxe, 0, "Building");
            R2(BlockId.PurpurPillar, "Purpur Pillar", 256, 257, 256, 1.5f, ToolType.Pickaxe, 0, "Building");
            R2(BlockId.Prismarine, "Prismarine", 258, 258, 258, 1.5f, ToolType.Pickaxe, 0, "Building");
            R2(BlockId.PrismarineBricks, "Prismarine Bricks", 259, 259, 259, 1.5f, ToolType.Pickaxe, 0, "Building");
            R2(BlockId.DarkPrismarine, "Dark Prismarine", 260, 260, 260, 1.5f, ToolType.Pickaxe, 0, "Building");
            R2(BlockId.SeaLantern, "Sea Lantern", 261, 261, 261, 0.3f, ToolType.None, -1, "Building");
            defs[(int)BlockId.SeaLantern].Light = 14;
            R2(BlockId.RedSandstone, "Red Sandstone", 262, 263, 262, 0.8f, ToolType.Pickaxe, 0, "Natural");
            R2(BlockId.BlueIce, "Blue Ice", 264, 264, 264, 2.8f, ToolType.Pickaxe, 0, "Natural");
            R2(BlockId.CoarseDirt, "Coarse Dirt", 265, 265, 265, 0.5f, ToolType.Shovel, -1, "Natural");
            R2(BlockId.Podzol, "Podzol", 266, 267, 72, 0.5f, ToolType.Shovel, -1, "Natural");
            R2(BlockId.PackedMud, "Packed Mud", 268, 268, 268, 1.0f, ToolType.Pickaxe, 0, "Building");
            R2(BlockId.MudBricks, "Mud Bricks", 269, 269, 269, 1.5f, ToolType.Pickaxe, 0, "Building");
            R2(BlockId.SoulSoil, "Soul Soil", 270, 270, 270, 0.5f, ToolType.Shovel, -1, "Natural");
            R2(BlockId.NetherWartBlock, "Nether Wart Block", 271, 271, 271, 1.0f, ToolType.None, -1, "Natural");
            R2(BlockId.WarpedWartBlock, "Warped Wart Block", 272, 272, 272, 1.0f, ToolType.None, -1, "Natural");
            R2(BlockId.RedNetherBricks, "Red Nether Bricks", 273, 273, 273, 2.0f, ToolType.Pickaxe, 0, "Building");
            R2(BlockId.AncientDebris, "Ancient Debris", 274, 275, 274, 30f, ToolType.Pickaxe, 3, "Natural");
            R2(BlockId.EndStoneBricks, "End Stone Bricks", 276, 276, 276, 3.0f, ToolType.Pickaxe, 0, "Building");
            R2(BlockId.Amethyst, "Block of Amethyst", 277, 277, 277, 1.5f, ToolType.Pickaxe, 0, "Building");
            R2(BlockId.LapisBlock, "Block of Lapis Lazuli", 278, 278, 278, 5.0f, ToolType.Pickaxe, 0, "Building");
            R2(BlockId.RedstoneBlock, "Block of Redstone", 279, 279, 279, 5.0f, ToolType.Pickaxe, 0, "Building");
            R2(BlockId.EmeraldBlock, "Block of Emerald", 280, 280, 280, 5.0f, ToolType.Pickaxe, 2, "Building");
            R2(BlockId.HayBale, "Hay Bale", 281, 282, 281, 0.5f, ToolType.None, -1, "Natural");
            R2(BlockId.Melon, "Melon", 283, 284, 283, 1.0f, ToolType.Axe, -1, "Natural");
            R2(BlockId.Pumpkin, "Pumpkin", 285, 286, 285, 1.0f, ToolType.Axe, -1, "Natural");
            R2(BlockId.JackOLantern, "Jack o'Lantern", 287, 287, 287, 1.0f, ToolType.Axe, -1, "Building");
            defs[(int)BlockId.JackOLantern].Light = 12;
            R2(BlockId.Sponge, "Sponge", 288, 288, 288, 0.6f, ToolType.None, -1, "Building");
            R2(BlockId.BoneBlock, "Bone Block", 289, 290, 289, 2.0f, ToolType.Pickaxe, 0, "Building");
            R2(BlockId.MagmaBlock, "Magma Block", 291, 291, 291, 0.5f, ToolType.Pickaxe, 0, "Natural");
            defs[(int)BlockId.MagmaBlock].Light = 3;
            R2(BlockId.Shroomlight, "Shroomlight", 292, 292, 292, 1.0f, ToolType.None, -1, "Natural");
            defs[(int)BlockId.Shroomlight].Light = 15;
            RS(BlockId.OakDoor, "Oak Door", 294, 293, 293, 3.0f, ToolType.Axe, -1, "Functional", Shape.Door, true, 0, 0, 0, false);
            defs[(int)BlockId.OakDoor].Icon = 295;
            RS(BlockId.SpruceDoor, "Spruce Door", 299, 298, 298, 3.0f, ToolType.Axe, -1, "Functional", Shape.Door, true, 0, 0, 0, false);
            defs[(int)BlockId.SpruceDoor].Icon = 300;
            RS(BlockId.BirchDoor, "Birch Door", 304, 303, 303, 3.0f, ToolType.Axe, -1, "Functional", Shape.Door, true, 0, 0, 0, false);
            defs[(int)BlockId.BirchDoor].Icon = 305;
            RS(BlockId.JungleDoor, "Jungle Door", 309, 308, 308, 3.0f, ToolType.Axe, -1, "Functional", Shape.Door, true, 0, 0, 0, false);
            defs[(int)BlockId.JungleDoor].Icon = 310;
            RS(BlockId.AcaciaDoor, "Acacia Door", 314, 313, 313, 3.0f, ToolType.Axe, -1, "Functional", Shape.Door, true, 0, 0, 0, false);
            defs[(int)BlockId.AcaciaDoor].Icon = 315;
            RS(BlockId.DarkOakDoor, "Dark Oak Door", 319, 318, 318, 3.0f, ToolType.Axe, -1, "Functional", Shape.Door, true, 0, 0, 0, false);
            defs[(int)BlockId.DarkOakDoor].Icon = 320;
            RS(BlockId.IronDoor, "Iron Door", 324, 323, 323, 5.0f, ToolType.Pickaxe, 0, "Functional", Shape.Door, true, 0, 0, 0, false);
            defs[(int)BlockId.IronDoor].Icon = 325;
            RS(BlockId.OakTrapdoor, "Oak Trapdoor", 296, 296, 296, 3.0f, ToolType.Axe, -1, "Functional", Shape.Trapdoor, true, 0, 0, 0, false);
            RS(BlockId.SpruceTrapdoor, "Spruce Trapdoor", 301, 301, 301, 3.0f, ToolType.Axe, -1, "Functional", Shape.Trapdoor, true, 0, 0, 0, false);
            RS(BlockId.BirchTrapdoor, "Birch Trapdoor", 306, 306, 306, 3.0f, ToolType.Axe, -1, "Functional", Shape.Trapdoor, true, 0, 0, 0, false);
            RS(BlockId.JungleTrapdoor, "Jungle Trapdoor", 311, 311, 311, 3.0f, ToolType.Axe, -1, "Functional", Shape.Trapdoor, true, 0, 0, 0, false);
            RS(BlockId.AcaciaTrapdoor, "Acacia Trapdoor", 316, 316, 316, 3.0f, ToolType.Axe, -1, "Functional", Shape.Trapdoor, true, 0, 0, 0, false);
            RS(BlockId.DarkOakTrapdoor, "Dark Oak Trapdoor", 321, 321, 321, 3.0f, ToolType.Axe, -1, "Functional", Shape.Trapdoor, true, 0, 0, 0, false);
            RS(BlockId.IronTrapdoor, "Iron Trapdoor", 326, 326, 326, 5.0f, ToolType.Pickaxe, 0, "Functional", Shape.Trapdoor, true, 0, 0, 0, false);
            RS(BlockId.OakFenceGate, "Oak Fence Gate", 16, 16, 16, 2.0f, ToolType.Axe, -1, "Functional", Shape.Gate, true, 0, 0, 0, false);
            defs[(int)BlockId.OakFenceGate].Icon = 297;
            RS(BlockId.SpruceFenceGate, "Spruce Fence Gate", 87, 87, 87, 2.0f, ToolType.Axe, -1, "Functional", Shape.Gate, true, 0, 0, 0, false);
            defs[(int)BlockId.SpruceFenceGate].Icon = 302;
            RS(BlockId.BirchFenceGate, "Birch Fence Gate", 83, 83, 83, 2.0f, ToolType.Axe, -1, "Functional", Shape.Gate, true, 0, 0, 0, false);
            defs[(int)BlockId.BirchFenceGate].Icon = 307;
            RS(BlockId.JungleFenceGate, "Jungle Fence Gate", 91, 91, 91, 2.0f, ToolType.Axe, -1, "Functional", Shape.Gate, true, 0, 0, 0, false);
            defs[(int)BlockId.JungleFenceGate].Icon = 312;
            RS(BlockId.AcaciaFenceGate, "Acacia Fence Gate", 95, 95, 95, 2.0f, ToolType.Axe, -1, "Functional", Shape.Gate, true, 0, 0, 0, false);
            defs[(int)BlockId.AcaciaFenceGate].Icon = 317;
            RS(BlockId.DarkOakFenceGate, "Dark Oak Fence Gate", 99, 99, 99, 2.0f, ToolType.Axe, -1, "Functional", Shape.Gate, true, 0, 0, 0, false);
            defs[(int)BlockId.DarkOakFenceGate].Icon = 322;
            RS(BlockId.CobbleWall, "Cobblestone Wall", 19, 19, 19, 2f, ToolType.Pickaxe, 0, "Building", Shape.Wall, true, 0, 0, 0, false);
            RS(BlockId.MossyCobbleWall, "Mossy Cobblestone Wall", 236, 236, 236, 2f, ToolType.Pickaxe, 0, "Building", Shape.Wall, true, 0, 0, 0, false);
            RS(BlockId.StoneBrickWall, "Stone Brick Wall", 102, 102, 102, 2f, ToolType.Pickaxe, 0, "Building", Shape.Wall, true, 0, 0, 0, false);
            RS(BlockId.BrickWall, "Brick Wall", 101, 101, 101, 2f, ToolType.Pickaxe, 0, "Building", Shape.Wall, true, 0, 0, 0, false);
            RS(BlockId.SandstoneWall, "Sandstone Wall", 103, 103, 103, 2f, ToolType.Pickaxe, 0, "Building", Shape.Wall, true, 0, 0, 0, false);
            RS(BlockId.NetherBrickWall, "Nether Brick Wall", 121, 121, 121, 2f, ToolType.Pickaxe, 0, "Building", Shape.Wall, true, 0, 0, 0, false);
            R2(BlockId.Portal, "Nether Portal", 327, 327, 327, -1f, ToolType.None, -1, "Functional", true, false, true);
            R2(BlockId.EndPortal, "End Portal", 328, 328, 328, -1f, ToolType.None, -1, "Functional", true, false, true);
            defs[(int)BlockId.Portal].Light = 11; defs[(int)BlockId.EndPortal].Light = 8;
            defs[(int)BlockId.OakLeaves].Drop = 0;
            T(BlockId.Stone, ToolType.Pickaxe, 0, (ushort)BlockId.Cobblestone);
            T(BlockId.Cobblestone, ToolType.Pickaxe, 0); T(BlockId.Furnace, ToolType.Pickaxe, 0); T(BlockId.Chest, ToolType.Axe, -1); T(BlockId.LootChest, ToolType.Axe, -1, (ushort)BlockId.Chest);
            T(BlockId.Farmland, ToolType.Shovel, -1, (ushort)BlockId.Dirt); T(BlockId.Bed, ToolType.Axe, -1);
            T(BlockId.Wheat0, ToolType.None, -1, 0); T(BlockId.Wheat1, ToolType.None, -1, 0); T(BlockId.Wheat2, ToolType.None, -1, 0); T(BlockId.Wheat3, ToolType.None, -1, 0);
            T(BlockId.CoalOre, ToolType.Pickaxe, 0, (ushort)ItemId.Coal);
            T(BlockId.IronOre, ToolType.Pickaxe, 1, (ushort)ItemId.RawIron);
            T(BlockId.Grass, ToolType.Shovel, -1, (ushort)BlockId.Dirt);
            T(BlockId.Dirt, ToolType.Shovel, -1); T(BlockId.Sand, ToolType.Shovel, -1); T(BlockId.Snow, ToolType.Shovel, -1);
            T(BlockId.OakLog, ToolType.Axe, -1); T(BlockId.Planks, ToolType.Axe, -1); T(BlockId.CraftingTable, ToolType.Axe, -1);
        }

        static void RS(BlockId id, string name, int top, int side, int bot, float hard, ToolType t, int tier, string cat,
            Shape shape, bool solid, int light, int facing, int full, bool hidden)
        {
            R2(id, name, top, side, bot, hard, t, tier, cat, true, solid, hidden);
            var d = defs[(int)id]; d.Shape = shape; d.Light = light; d.Facing = facing; d.Full = full;
        }

        static void R2(BlockId id, string name, int top, int side, int bot, float hard, ToolType t, int tier, string cat,
            bool transp = false, bool solid = true, bool hidden = false)
        {
            Reg(id, name, top, side, bot, solid, transp, hard);
            var d = defs[(int)id]; d.Tool = t; d.MinTier = tier; d.Cat = cat; d.Hidden = hidden;
        }

        public static System.Collections.Generic.List<ushort> All()
        {
            var l = new System.Collections.Generic.List<ushort>();
            for (int i = 1; i < 1000; i++) if (defs[i] != null && !defs[i].Hidden) l.Add((ushort)i);
            return l;
        }

        static void T(BlockId id, ToolType t, int minTier, ushort drop = ushort.MaxValue)
        {
            var d = defs[(int)id]; d.Tool = t; d.MinTier = minTier;
            if (drop != ushort.MaxValue) d.Drop = drop;
        }

        static void Reg(BlockId id, string name, int top, int side, int bottom,
            bool solid = true, bool transparent = false, float hardness = 1f)
        {
            defs[(int)id] = new BlockDefinition { Id = id, Drop = (ushort)id, Name = name, TexTop = top, TexSide = side,
                TexBottom = bottom, Solid = solid, Transparent = transparent, Hardness = hardness };
        }

        /// Состояние блока (дверь открыта и т.п.) хранится в старших битах id: id = базовый | (состояние << 9).
        public static BlockDefinition Get(ushort id) => defs[id & 0x1FF] ?? defs[0];
    }
}
