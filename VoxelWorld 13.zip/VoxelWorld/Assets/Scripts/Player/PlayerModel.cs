using System.Collections.Generic;
using UnityEngine;
using VoxelWorld.Items;

namespace VoxelWorld.Player
{
    /// «Стив»: блочный персонаж из кубов (оригинальный дизайн). Виден в режиме от третьего лица, анимация ходьбы/удара, надетая броня.
    public class PlayerModel : MonoBehaviour
    {
        Transform root, head, armL, armR, legL, legR; Inventory inv; float ph, swing, armorT; Vector3 last;
        readonly List<Renderer>[] armorR = { new List<Renderer>(), new List<Renderer>(), new List<Renderer>(), new List<Renderer>() };
        static Mesh cube;

        Transform Box(Transform p, Vector3 pos, Vector3 size, Color c, int armorSlot = -1)
        {
            if (cube == null) { var g = GameObject.CreatePrimitive(PrimitiveType.Cube); cube = g.GetComponent<MeshFilter>().sharedMesh; Destroy(g); }
            var o = new GameObject("p"); o.transform.SetParent(p, false); o.transform.localPosition = pos; o.transform.localScale = size;
            o.AddComponent<MeshFilter>().sharedMesh = cube;
            var r = o.AddComponent<MeshRenderer>(); r.sharedMaterial = new Material(Shader.Find("VoxelWorld/ColorUnlit")) { color = c };
            if (armorSlot >= 0) armorR[armorSlot].Add(r);
            return o.transform;
        }

        Transform Pivot(Transform p, Vector3 pos) { var t = new GameObject("pivot").transform; t.SetParent(p, false); t.localPosition = pos; return t; }

        public void Init(Inventory i, CharacterController cc)
        {
            inv = i; last = transform.position;
            root = Pivot(transform, Vector3.zero);
            Color skin = new Color(0.78f, 0.6f, 0.48f), shirt = new Color(0.1f, 0.7f, 0.75f), pants = new Color(0.25f, 0.25f, 0.65f), hair = new Color(0.3f, 0.2f, 0.12f);
            head = Pivot(root, new Vector3(0, 1.5f, 0));
            Box(head, new Vector3(0, 0.25f, 0), new Vector3(0.5f, 0.5f, 0.5f), skin);
            Box(head, new Vector3(0, 0.46f, 0), new Vector3(0.52f, 0.12f, 0.52f), hair);
            Box(head, new Vector3(0, 0.3f, -0.26f), new Vector3(0.52f, 0.4f, 0.06f), hair);
            foreach (float sx in new[] { -0.12f, 0.12f })
            {
                Box(head, new Vector3(sx, 0.27f, 0.255f), new Vector3(0.12f, 0.08f, 0.02f), Color.white);
                Box(head, new Vector3(sx, 0.27f, 0.262f), new Vector3(0.06f, 0.08f, 0.01f), new Color(0.2f, 0.3f, 0.8f));
            }
            Box(head, new Vector3(0, 0.12f, 0.255f), new Vector3(0.2f, 0.04f, 0.02f), new Color(0.5f, 0.3f, 0.25f));
            Box(head, new Vector3(0, 0.25f, 0), new Vector3(0.56f, 0.56f, 0.56f), Color.gray, 0);
            Box(root, new Vector3(0, 1.125f, 0), new Vector3(0.5f, 0.75f, 0.25f), shirt);
            Box(root, new Vector3(0, 1.125f, 0), new Vector3(0.56f, 0.8f, 0.31f), Color.gray, 1);
            armL = Pivot(root, new Vector3(-0.375f, 1.5f, 0)); armR = Pivot(root, new Vector3(0.375f, 1.5f, 0));
            foreach (var a in new[] { armL, armR })
            {
                Box(a, new Vector3(0, -0.1875f, 0), new Vector3(0.25f, 0.375f, 0.25f), shirt);
                Box(a, new Vector3(0, -0.5625f, 0), new Vector3(0.25f, 0.375f, 0.25f), skin);
                Box(a, new Vector3(0, -0.2f, 0), new Vector3(0.3f, 0.42f, 0.3f), Color.gray, 1);
            }
            legL = Pivot(root, new Vector3(-0.125f, 0.75f, 0)); legR = Pivot(root, new Vector3(0.125f, 0.75f, 0));
            foreach (var l in new[] { legL, legR })
            {
                Box(l, new Vector3(0, -0.375f, 0), new Vector3(0.25f, 0.75f, 0.25f), pants);
                Box(l, new Vector3(0, -0.7f, 0.02f), new Vector3(0.26f, 0.12f, 0.29f), new Color(0.35f, 0.35f, 0.38f));
                Box(l, new Vector3(0, -0.25f, 0), new Vector3(0.3f, 0.55f, 0.3f), Color.gray, 2);
                Box(l, new Vector3(0, -0.63f, 0.01f), new Vector3(0.3f, 0.26f, 0.33f), Color.gray, 3);
            }
            Refresh(); SetVisible(false);
        }

        public void SetVisible(bool v) { if (root != null && root.gameObject.activeSelf != v) root.gameObject.SetActive(v); }
        public void SetPitch(float deg) { if (head != null) head.localRotation = Quaternion.Euler(deg, 0, 0); }
        public void Swing() { swing = 0.25f; }

        void Refresh()
        {
            for (int s = 0; s < 4; s++)
            {
                var st = inv.armor[s]; bool on = !st.Empty;
                var d = on ? ItemDatabase.Get(st.id) : null;
                Color c = d != null && d.Tier >= 3 ? new Color(0.3f, 0.9f, 0.85f) : new Color(0.8f, 0.8f, 0.83f);
                foreach (var r in armorR[s]) { r.enabled = on; if (on) r.material.color = c; }
            }
        }

        void Update()
        {
            if (root == null) return;
            float dt = Mathf.Max(Time.deltaTime, 0.0001f);
            Vector3 d = transform.position - last; d.y = 0; last = transform.position;
            float sp = d.magnitude / dt; ph += sp * dt * 3f;
            float a = Mathf.Sin(ph) * Mathf.Clamp01(sp / 3f) * 50f;
            legL.localRotation = Quaternion.Euler(a, 0, 0); legR.localRotation = Quaternion.Euler(-a, 0, 0);
            armL.localRotation = Quaternion.Euler(-a * 0.8f, 0, 0);
            if (swing > 0f) { swing -= dt; armR.localRotation = Quaternion.Euler(-70f - Mathf.Sin(Time.time * 18f) * 40f, 0, 0); }
            else armR.localRotation = Quaternion.Euler(a * 0.8f, 0, 0);
            armorT -= dt; if (armorT <= 0f) { armorT = 0.25f; Refresh(); }
        }
    }
}
