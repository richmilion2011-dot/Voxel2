using UnityEngine;
using VoxelWorld.Blocks;
using VoxelWorld.Audio;
using VoxelWorld.Core;
using VoxelWorld.Gameplay;
using VoxelWorld.Items;
using VoxelWorld.UI;
using VoxelWorld.World;

namespace VoxelWorld.Player
{
    /// Тач: левая часть — джойстик, правая — камера; BREAK держать для добычи; тап по хотбару — выбор слота.
    /// Редактор: WASD, Space, ПКМ+мышь, ЛКМ держать — добыча, E поставить, 1-9 слот, I инвентарь, C режим.
    /// Нужно: Project Settings > Player > Active Input Handling = Both.
    [RequireComponent(typeof(CharacterController))]
    public class PlayerController : MonoBehaviour
    {
        public Transform cam; public ChunkManager world; public Inventory inv; public InventoryUI ui;
        public bool creative; public ChestSystem chests; int alive; float digT, stepDist; string toast; float toastT; public FarmSystem farms; public DayNightCycle day; float atkCd; public FurnaceSystem furnaces; public SurvivalSystem survival;
        bool wasGrounded, landedOnce; float peakY = 110f; Vector3 lastPos;
        Vector3 SpawnPos = new Vector3(8, 110, 8);
        public float speed = 5f, jumpSpeed = 7.5f, gravity = -22f, touchLook = 0.15f, reach = 6f;

        CharacterController cc; float vy, pitch;
        int joyId = -1, lookId = -1, breakId = -1; Vector2 joyStart, joyVec;
        Rect rJump, rBreak, rPlace, rInv, rMode, rView; public PlayerModel model; bool thirdPerson; float lavaT; MinecartEntity cart; bool riding; public bool frozen;
        Vector3Int target; bool hasTarget; float progress;
        ItemStack[] saved;
        static readonly BlockId[] CreativeSet = { BlockId.Grass, BlockId.Dirt, BlockId.Stone, BlockId.Sand,
            BlockId.OakLog, BlockId.OakLeaves, BlockId.Glass, BlockId.Snow, BlockId.Cactus };

        void Awake() { cc = GetComponent<CharacterController>(); }
        void Start() { survival.OnRespawn = DoRespawn; lastPos = transform.position; }

        void Layout()
        {
            float s = Screen.height * 0.17f, m = s * 0.2f;
            rJump = new Rect(Screen.width - s - m, Screen.height - s - m, s, s);
            rBreak = new Rect(Screen.width - 2 * s - 2 * m, Screen.height - s - m, s, s);
            rPlace = new Rect(Screen.width - s - m, Screen.height - 2 * s - 2 * m, s, s);
            rInv = new Rect(Screen.width - s - m, m, s, s * 0.6f);
            rMode = new Rect(Screen.width - 2.6f * s - 2 * m, m, 1.5f * s, s * 0.6f);
            rView = new Rect(Screen.width - s - m, m + s * 0.7f, s, s * 0.5f);
        }

        void ToggleCreative()
        {
            creative = !creative;
            survival.creative = creative;
            if (creative) { survival.health = 20; survival.hunger = 20; }
            ui.creativeUI = creative;
        }

        void Update()
        {
            toastT -= Time.deltaTime;
            if (alive++ < 3) return;
            if (GameSession.Paused) { joyId = lookId = breakId = -1; joyVec = Vector2.zero; return; }
            if (frozen) return;
            Layout();
            if (survival.Dead)
            {
                joyId = lookId = breakId = -1; joyVec = Vector2.zero; progress = 0; hasTarget = false;
                Move(Vector2.zero, false); return;
            }
            if (Input.GetKeyDown(KeyCode.I)) ui.Toggle();
            if (ui.open)
            {
                joyId = lookId = breakId = -1; joyVec = Vector2.zero; progress = 0; hasTarget = false;
                Move(Vector2.zero, false); return;
            }

            Vector2 move = Vector2.zero, look = Vector2.zero; bool jump = false;
            foreach (Touch t in Input.touches)
            {
                Vector2 p = new Vector2(t.position.x, Screen.height - t.position.y);
                bool ended = t.phase == TouchPhase.Ended || t.phase == TouchPhase.Canceled;
                if (t.phase == TouchPhase.Began)
                {
                    bool used = true;
                    if (rJump.Contains(p)) jump = true;
                    else if (rBreak.Contains(p)) breakId = t.fingerId;
                    else if (rPlace.Contains(p)) Place();
                    else if (rInv.Contains(p)) ui.Toggle();
                    else if (rMode.Contains(p)) ToggleCreative();
                    else if (rView.Contains(p)) thirdPerson = !thirdPerson;
                    else
                    {
                        used = false;
                        for (int i = 0; i < 9; i++) if (InventoryUI.HotbarSlot(i).Contains(p)) { ui.selected = i; used = true; }
                        if (PauseMenu.ButtonRect.Contains(p)) used = true;
                    }
                    if (!used)
                    {
                        if (p.x < Screen.width * 0.4f && joyId < 0) { joyId = t.fingerId; joyStart = p; }
                        else if (p.x >= Screen.width * 0.4f && lookId < 0) lookId = t.fingerId;
                    }
                }
                if (t.fingerId == breakId && ended) breakId = -1;
                if (t.fingerId == joyId)
                {
                    Vector2 d = (p - joyStart) / (Screen.height * 0.1f);
                    joyVec = ended ? Vector2.zero : Vector2.ClampMagnitude(new Vector2(d.x, -d.y), 1f);
                    if (ended) joyId = -1;
                }
                if (t.fingerId == lookId) { look += t.deltaPosition * touchLook; if (ended) lookId = -1; }
            }
            move = joyVec;
            bool breaking = breakId >= 0;

            if (Input.touchCount == 0)
            {
                move = new Vector2(Input.GetAxisRaw("Horizontal"), Input.GetAxisRaw("Vertical"));
                if (Input.GetMouseButton(1)) look = new Vector2(Input.GetAxis("Mouse X"), Input.GetAxis("Mouse Y")) * 2f;
                jump = Input.GetKeyDown(KeyCode.Space);
                breaking = Input.GetMouseButton(0);
                if (Input.GetKeyDown(KeyCode.E)) Place();
                if (Input.GetKeyDown(KeyCode.C)) ToggleCreative();
                if (Input.GetKeyDown(KeyCode.V)) thirdPerson = !thirdPerson;
                if (Input.GetKeyDown(KeyCode.Q)) DropSelected();
                for (int i = 0; i < 9; i++) if (Input.GetKeyDown(KeyCode.Alpha1 + i)) ui.selected = i;
            }

            transform.Rotate(0, look.x, 0);
            pitch = Mathf.Clamp(pitch - look.y, -89f, 89f);
            UpdateCamera();
            if (riding)
            {
                if (cart == null) Dismount();
                else
                {
                    cart.Drive(move.y, transform.forward);
                    transform.position = cart.transform.position + Vector3.up * 0.25f;
                    lastPos = transform.position; peakY = transform.position.y; vy = 0f;
                    if (jump) Dismount();
                    return;
                }
            }
            Move(move, jump);
            Mine(breaking);
        }

        void Move(Vector2 move, bool jump)
        {
            Vector3 dir = transform.right * move.x + transform.forward * move.y;
            if (dir.sqrMagnitude > 1f) dir.Normalize();
            if (cc.isGrounded && vy < 0) vy = -2f;
            if (jump && cc.isGrounded) { vy = jumpSpeed; survival.AddExhaustion(0.05f); }
            ushort mid = world.GetBlockWorld(Mathf.FloorToInt(transform.position.x), Mathf.FloorToInt(transform.position.y + 0.5f), Mathf.FloorToInt(transform.position.z));
            bool liquid = mid == (ushort)BlockId.Water || mid == (ushort)BlockId.Lava;
            if (mid == (ushort)BlockId.Ladder) vy = jump ? 3f : move.y > 0.1f ? 2.5f : move.y < -0.1f ? -2.5f : 0f;
            else if (liquid) { vy = Mathf.Lerp(vy, 1.5f, 4f * Time.deltaTime); if (jump) vy = 4f; dir *= 0.6f; }
            else vy += gravity * Time.deltaTime;
            lavaT -= Time.deltaTime;
            if (mid == (ushort)BlockId.Lava && lavaT <= 0f) { lavaT = 0.5f; survival.Damage(3f); }
            cc.Move((dir * speed + Vector3.up * vy) * Time.deltaTime);
            TrackFall();
        }

        bool PlaceBlock(int x, int y, int z, ushort id, BlockDefinition d, Vector3Int hit)
        {
            int f = Mathf.RoundToInt(transform.eulerAngles.y / 90f) & 3;
            switch (d.Shape)
            {
                case Shape.Stair: world.SetBlockWorld(x, y, z, (ushort)(id + f)); return true;
                case Shape.Door:
                    if (world.GetBlockWorld(x, y + 1, z) != 0) return false;
                    world.SetBlockWorld(x, y, z, (ushort)(id | (f << 11)));
                    world.SetBlockWorld(x, y + 1, z, (ushort)(id | ((1 | (f << 2)) << 9)));
                    return true;
                case Shape.Trapdoor: world.SetBlockWorld(x, y, z, (ushort)(id | (((hit.y > y ? 1 : 0) | (f << 2)) << 9))); return true;
                case Shape.Gate: world.SetBlockWorld(x, y, z, (ushort)(id | (f << 11))); return true;
                default: world.SetBlockWorld(x, y, z, id); return true;
            }
        }

        void ToggleOpenable(Vector3Int p, ushort id, BlockDefinition d)
        {
            int st = id >> 9, bs = id & 0x1FF;
            world.SetBlockWorld(p.x, p.y, p.z, (ushort)(bs | ((st ^ 2) << 9)));
            if (d.Shape == Shape.Door)
            {
                int oy = p.y + ((st & 1) != 0 ? -1 : 1); ushort oid = world.GetBlockWorld(p.x, oy, p.z);
                if ((oid & 0x1FF) == bs) world.SetBlockWorld(p.x, oy, p.z, (ushort)(bs | (((oid >> 9) ^ 2) << 9)));
            }
            AudioManager.I?.Play2D(AudioManager.I.place, 0.6f, (st & 2) != 0 ? 0.8f : 1.2f);
        }

        void Ride(MinecartEntity c) { cart = c; riding = true; cc.enabled = false; }

        void Dismount()
        {
            if (cart != null) transform.position = cart.transform.position + Vector3.up * 1.2f;
            riding = false; cart = null; cc.enabled = true; vy = 0f;
        }

        /// Луч по блокам (DDA): видит и несплошные блоки (факел, рельсы, лестница). liquids=false — жидкости пропускаются.
        bool RayBlocks(bool liquids, out Vector3Int hit, out Vector3Int prev)
        {
            Vector3 o = transform.position + Vector3.up * 1.62f, d = cam.forward;
            var p = new Vector3Int(Mathf.FloorToInt(o.x), Mathf.FloorToInt(o.y), Mathf.FloorToInt(o.z));
            hit = p; prev = p;
            var step = new Vector3Int(d.x > 0 ? 1 : -1, d.y > 0 ? 1 : -1, d.z > 0 ? 1 : -1);
            var tD = new Vector3(Mathf.Abs(1f / (Mathf.Abs(d.x) < 1e-6f ? 1e-6f : d.x)), Mathf.Abs(1f / (Mathf.Abs(d.y) < 1e-6f ? 1e-6f : d.y)), Mathf.Abs(1f / (Mathf.Abs(d.z) < 1e-6f ? 1e-6f : d.z)));
            var tM = new Vector3((d.x > 0 ? p.x + 1 - o.x : o.x - p.x) * tD.x, (d.y > 0 ? p.y + 1 - o.y : o.y - p.y) * tD.y, (d.z > 0 ? p.z + 1 - o.z : o.z - p.z) * tD.z);
            for (int i = 0; i < 40; i++)
            {
                int a = tM.x < tM.y && tM.x < tM.z ? 0 : tM.y < tM.z ? 1 : 2;
                if (tM[a] > reach) return false;
                prev = p; p[a] += step[a]; tM[a] += tD[a];
                ushort b = world.GetBlockWorld(p.x, p.y, p.z);
                if (b == 0) continue;
                if (!liquids && (b == (ushort)BlockId.Water || b == (ushort)BlockId.Lava)) continue;
                hit = p; return true;
            }
            return false;
        }

        void UseBucket()
        {
            var s = inv.slots[ui.selected];
            if (!RayBlocks(true, out var hit, out var prev)) return;
            ushort b = world.GetBlockWorld(hit.x, hit.y, hit.z);
            if (s.id == (ushort)ItemId.Bucket)
            {
                if (b != (ushort)BlockId.Water && b != (ushort)BlockId.Lava) return;
                world.SetBlockWorld(hit.x, hit.y, hit.z, 0);
                inv.slots[ui.selected] = new ItemStack { id = (ushort)(b == (ushort)BlockId.Water ? ItemId.WaterBucket : ItemId.LavaBucket), count = 1 };
                AudioManager.I?.Play2D(AudioManager.I.splash, 0.8f, 1f);
            }
            else
            {
                if (world.GetBlockWorld(prev.x, prev.y, prev.z) != 0) return;
                world.SetBlockWorld(prev.x, prev.y, prev.z, s.id == (ushort)ItemId.WaterBucket ? (ushort)BlockId.Water : (ushort)BlockId.Lava);
                inv.slots[ui.selected] = new ItemStack { id = (ushort)ItemId.Bucket, count = 1 };
                AudioManager.I?.Play2D(AudioManager.I.splash, 0.8f, 1.2f);
            }
        }

        void UpdateCamera()
        {
            Quaternion rot = Quaternion.Euler(pitch, 0, 0);
            model?.SetPitch(pitch);
            if (!thirdPerson || model == null)
            {
                cam.localPosition = new Vector3(0, 1.6f, 0); cam.localRotation = rot; model?.SetVisible(false); return;
            }
            Vector3 pivot = transform.position + Vector3.up * 1.6f;
            Vector3 back = transform.rotation * (rot * Vector3.back);
            float d = 4f;
            if (Physics.SphereCast(pivot, 0.2f, back, out var hit, d, ~0, QueryTriggerInteraction.Ignore) && hit.collider.GetComponentInParent<Mob>() == null)
                d = Mathf.Max(0.6f, hit.distance - 0.1f);
            cam.position = pivot + back * d; cam.rotation = transform.rotation * rot; model.SetVisible(true);
        }

        void DropSelected()
        {
            var s = inv.slots[ui.selected];
            if (s.Empty) return;
            var one = new ItemStack { id = s.id, count = 1, dur = s.dur };
            inv.TakeOne(ui.selected); DropStack(one);
        }

        public void DropStack(ItemStack st)
        {
            if (st.Empty) return;
            Vector3 f = transform.forward;
            ItemEntity.Spawn(st, transform.position + Vector3.up * 1.4f + f * 0.5f, f * 4f + Vector3.up * 2f);
        }

        void PlayStep()
        {
            if (AudioManager.I == null) return;
            ushort b = world.GetBlockWorld(Mathf.FloorToInt(transform.position.x), Mathf.FloorToInt(transform.position.y - 0.1f), Mathf.FloorToInt(transform.position.z));
            if (b != 0) AudioManager.I.Play2D(AudioManager.I.StepFor(b), 0.5f, Random.Range(0.9f, 1.1f));
        }

        public void SetCreative(bool v) { if (creative != v) ToggleCreative(); }
        public Vector3 SpawnPoint { get => SpawnPos; set => SpawnPos = value; }
        void Say(string s) { toast = s; toastT = 3f; }

        void Sleep(Vector3Int bed)
        {
            SpawnPos = new Vector3(bed.x + 0.5f, bed.y + 1.05f, bed.z + 0.5f);
            if (day.Light >= 0.35f) { Say("Spawn point set (you can only sleep at night)"); return; }
            if (MobManager.Instance != null && MobManager.Instance.HostileNear(transform.position, 12f)) { Say("You can't sleep: monsters nearby"); return; }
            day.t = 0.03f; Say("Good morning! Spawn point set");
        }

        public float Pitch => pitch;
        public ItemStack[] SurvivalInventory() => (creative && saved != null) ? saved : inv.slots;

        public void SetPosition(Vector3 p, float yaw, float pt)
        {
            cc.enabled = false; transform.position = p; cc.enabled = true;
            transform.rotation = Quaternion.Euler(0, yaw, 0); pitch = pt; cam.localRotation = Quaternion.Euler(pitch, 0, 0);
            vy = 0; landedOnce = false; peakY = p.y; lastPos = p;
        }

        void TrackFall()
        {
            Vector3 d = transform.position - lastPos; d.y = 0;
            survival.AddExhaustion(d.magnitude * 0.01f); lastPos = transform.position;
            bool g = cc.isGrounded; float y = transform.position.y;
            if (g) { stepDist += d.magnitude; if (stepDist > 2.2f) { stepDist = 0; PlayStep(); } }
            bool wet = world.GetBlockWorld(Mathf.FloorToInt(transform.position.x), Mathf.FloorToInt(y + 0.5f), Mathf.FloorToInt(transform.position.z)) == (ushort)BlockId.Water;
            if (wet) peakY = y;
            else if (!g) peakY = Mathf.Max(peakY, y);
            else
            {
                if (!wasGrounded && landedOnce) // первое приземление после спавна не считается
                {
                    float fall = peakY - y;
                    ushort below = world.GetBlockWorld(Mathf.FloorToInt(transform.position.x), Mathf.FloorToInt(y - 0.1f), Mathf.FloorToInt(transform.position.z));
                    if (fall > 3f && below != (ushort)BlockId.Water) survival.Damage(Mathf.Floor(fall - 3f));
                }
                if (!wasGrounded) landedOnce = true;
                peakY = y;
            }
            wasGrounded = g;
        }

        void DoRespawn()
        {
            if (GameSession.Dimension != 0) { DimensionManager.Instance?.GoTo(0, SpawnPos, false); return; }
            cc.enabled = false; transform.position = SpawnPos; cc.enabled = true;
            vy = 0; landedOnce = false; peakY = SpawnPos.y; lastPos = SpawnPos;
        }

        bool Aim(out RaycastHit hit) => Physics.Raycast(transform.position + Vector3.up * 1.62f, cam.forward, out hit, reach);

        void Mine(bool on)
        {
            if (!on) { progress = 0; hasTarget = false; return; }
            if (Aim(out var h))
            {
                var mob = h.collider.GetComponentInParent<Mob>();
                if (mob != null) { Attack(mob); progress = 0; hasTarget = false; return; }
                var dragon = h.collider.GetComponentInParent<EnderDragon>();
                if (dragon != null) { AttackDragon(dragon); progress = 0; hasTarget = false; return; }
                var cartE = h.collider.GetComponentInParent<MinecartEntity>();
                if (cartE != null) { if (cart == cartE) return; inv.Add((ushort)ItemId.Minecart, 1); Destroy(cartE.gameObject); progress = 0; hasTarget = false; return; }
            }
            if (!RayBlocks(false, out var b, out _)) { progress = 0; hasTarget = false; return; }
            if (!hasTarget || b != target) { target = b; hasTarget = true; progress = 0; }
            ushort rawId = world.GetBlockWorld(b.x, b.y, b.z);
            var def = BlockDatabase.Get(rawId);
            if (def.Id == BlockId.Air || def.Id == BlockId.Water || def.Hardness < 0) return;

            var hand = inv.slots[ui.selected];
            var tool = hand.Empty ? null : ItemDatabase.Get(hand.id);
            bool right = tool != null && def.Tool != ToolType.None && tool.Tool == def.Tool;
            bool canHarvest = def.MinTier < 0 || (right && tool.Tier >= def.MinTier);
            float mul = !canHarvest ? 0.3f : right ? tool.Speed : 1f;
            progress += creative ? Time.deltaTime / 0.2f : Time.deltaTime * mul / Mathf.Max(def.Hardness, 0.05f);
            model?.Swing();
            digT -= Time.deltaTime;
            if (digT <= 0f) { digT = 0.25f; AudioManager.I?.Play2D(AudioManager.I.DigFor(def.Id), 0.6f, Random.Range(0.9f, 1.1f)); }
            if (progress < 1f) return;

            AudioManager.I?.Play2D(AudioManager.I.breakClip, 0.8f, Random.Range(0.85f, 1.1f));
            if (def.Id == BlockId.Furnace) furnaces.Remove(b, inv);
            if (def.Id == BlockId.Chest || def.Id == BlockId.LootChest) chests.Remove(b, inv);
            ushort after = FarmSystem.IsCrop(def.Id) ? farms.Harvest(b, def.Id, inv) : (ushort)0;
            world.SetBlockWorld(b.x, b.y, b.z, after);
            if (def.Shape == Shape.Door)
            {
                int oy = b.y + (((rawId >> 9) & 1) != 0 ? -1 : 1); ushort oid = world.GetBlockWorld(b.x, oy, b.z);
                if ((oid & 0x1FF) == (rawId & 0x1FF)) world.SetBlockWorld(b.x, oy, b.z, 0);
            }
            if (!creative)
            {
                if (canHarvest && def.Drop != 0) inv.Add(def.Drop, 1);
                if (def.Id == BlockId.OakLeaves && Random.value < 0.05f) inv.Add((ushort)ItemId.Apple, 1);
                if (def.Id == BlockId.Grass && Random.value < 0.12f) inv.Add((ushort)ItemId.WheatSeeds, 1);
                if (def.Id == BlockId.Gravel && Random.value < 0.25f) inv.Add((ushort)ItemId.Flint, 1);
                survival.AddExhaustion(0.025f);
                if (right && tool.Durability > 0 && --inv.slots[ui.selected].dur <= 0) inv.slots[ui.selected] = default;
            }
            progress = 0; hasTarget = false;
        }

        float CurrentDamage()
        {
            var hand = inv.slots[ui.selected]; var tool = hand.Empty ? null : ItemDatabase.Get(hand.id); float dmg = 1f;
            if (tool != null && tool.Tool != ToolType.None)
            {
                dmg = (tool.Tool == ToolType.Sword ? 4f : tool.Tool == ToolType.Axe ? 3f : 2f) + tool.Tier;
                if (!creative && tool.Durability > 0 && --inv.slots[ui.selected].dur <= 0) inv.slots[ui.selected] = default;
            }
            return dmg;
        }

        void AttackDragon(EnderDragon dr)
        {
            if (Time.time < atkCd) return;
            atkCd = Time.time + 0.5f; model?.Swing(); dr.Hurt(CurrentDamage());
            AudioManager.I?.Play2D(AudioManager.I.hit, 0.8f, 0.7f);
        }

        void Attack(Mob m)
        {
            if (Time.time < atkCd) return;
            atkCd = Time.time + 0.5f;
            var hand = inv.slots[ui.selected];
            var tool = hand.Empty ? null : ItemDatabase.Get(hand.id);
            float dmg = 1f;
            if (tool != null && tool.Tool != ToolType.None)
            {
                dmg = (tool.Tool == ToolType.Sword ? 4f : tool.Tool == ToolType.Axe ? 3f : 2f) + tool.Tier;
                if (!creative && tool.Durability > 0 && --inv.slots[ui.selected].dur <= 0) inv.slots[ui.selected] = default;
            }
            model?.Swing();
            m.Hurt(dmg, transform.position, true);
            AudioManager.I?.Play(AudioManager.I.hit, m.transform.position, 0.8f, Random.Range(0.9f, 1.1f));
            survival.AddExhaustion(0.1f);
        }

        void Place()
        {
            var cur0 = inv.slots[ui.selected];
            var fd = cur0.Empty ? null : ItemDatabase.Get(cur0.id);
            if (fd != null && fd.Food > 0) { if (survival.Eat(fd.Food, fd.Sat)) { inv.TakeOne(ui.selected); AudioManager.I?.Play2D(AudioManager.I.eat, 0.8f, 1f); } return; }
            if (!cur0.Empty && (cur0.id == (ushort)ItemId.Bucket || cur0.id == (ushort)ItemId.WaterBucket || cur0.id == (ushort)ItemId.LavaBucket)) { UseBucket(); return; }
            if (Aim(out var h))
            {
                var vm = h.collider.GetComponentInParent<Mob>();
                if (vm != null)
                {
                    if (vm.type == MobType.Villager) ui.OpenTrade(TradeData.For(vm.profession), TradeData.Name(vm.profession));
                    return;
                }
                var cartE = h.collider.GetComponentInParent<MinecartEntity>();
                if (cartE != null) { Ride(cartE); return; }
            }
            if (!RayBlocks(false, out var qp, out var prevCell)) return;
            ushort qb = world.GetBlockWorld(qp.x, qp.y, qp.z);
            if (qb == (ushort)BlockId.CraftingTable) { ui.Open(true); return; }
            if (qb == (ushort)BlockId.Furnace) { ui.OpenFurnace(furnaces.GetOrCreate(qp)); return; }
            if (qb == (ushort)BlockId.Chest || qb == (ushort)BlockId.LootChest) { ui.OpenChest(chests.GetOrCreate(qp, qb == (ushort)BlockId.LootChest)); return; }
            if (qb == (ushort)BlockId.Bed) { Sleep(qp); return; }
            var qd = BlockDatabase.Get(qb);
            if (qd.Shape == Shape.Door || qd.Shape == Shape.Trapdoor || qd.Shape == Shape.Gate) { ToggleOpenable(qp, qb, qd); return; }
            var st = inv.slots[ui.selected];
            if (!st.Empty && st.id >= ItemDatabase.FirstItem)
            {
                var idef = ItemDatabase.Get(st.id);
                ushort above = world.GetBlockWorld(qp.x, qp.y + 1, qp.z);
                if (idef != null && idef.Tool == ToolType.Hoe && (qb == (ushort)BlockId.Dirt || qb == (ushort)BlockId.Grass) && above == 0)
                {
                    world.SetBlockWorld(qp.x, qp.y, qp.z, (ushort)BlockId.Farmland);
                    AudioManager.I?.Play2D(AudioManager.I.digSoft, 0.7f, 1f);
                    if (!creative && --inv.slots[ui.selected].dur <= 0) inv.slots[ui.selected] = default;
                    return;
                }
                if ((st.id == (ushort)ItemId.FlintAndSteel || st.id == (ushort)ItemId.EyeOfEnder) && qb == (ushort)BlockId.Obsidian)
                {
                    ushort pb = st.id == (ushort)ItemId.FlintAndSteel ? (ushort)BlockId.Portal : (ushort)BlockId.EndPortal;
                    if (PortalSystem.TryLight(world, prevCell, pb))
                    {
                        AudioManager.I?.Play2D(AudioManager.I.breakClip, 0.6f, 1.6f);
                        if (!creative) { if (st.id == (ushort)ItemId.EyeOfEnder) inv.TakeOne(ui.selected); else if (--inv.slots[ui.selected].dur <= 0) inv.slots[ui.selected] = default; }
                    }
                    return;
                }
                if (st.id == (ushort)ItemId.Minecart && qb == (ushort)BlockId.Rail)
                {
                    MinecartEntity.Spawn(new Vector3(qp.x + 0.5f, qp.y + 0.0625f, qp.z + 0.5f));
                    if (!creative) inv.TakeOne(ui.selected);
                    return;
                }
                if (st.id == (ushort)ItemId.WheatSeeds && qb == (ushort)BlockId.Farmland && above == 0)
                {
                    world.SetBlockWorld(qp.x, qp.y, qp.z, (ushort)BlockId.Wheat0); farms.Plant(qp);
                    AudioManager.I?.Play2D(AudioManager.I.place, 0.5f, 1.2f);
                    if (!creative) inv.TakeOne(ui.selected);
                    return;
                }
            }
            if (st.Empty || st.id >= ItemDatabase.FirstItem) return;
            var sdef = BlockDatabase.Get(st.id);
            if (sdef.Shape == Shape.Slab && qb == st.id)
            {
                world.SetBlockWorld(qp.x, qp.y, qp.z, (ushort)sdef.Full);
                AudioManager.I?.Play2D(AudioManager.I.place, 0.7f, 1f);
                if (!creative) inv.TakeOne(ui.selected);
                return;
            }
            int x = prevCell.x, y = prevCell.y, z = prevCell.z;
            if (cc.bounds.Intersects(new Bounds(new Vector3(x + .5f, y + .5f, z + .5f), Vector3.one))) return;
            ushort cur = world.GetBlockWorld(x, y, z);
            if (cur != 0 && cur != (ushort)BlockId.Water) return;
            AudioManager.I?.Play2D(AudioManager.I.place, 0.7f, Random.Range(0.9f, 1.1f));
            if (!PlaceBlock(x, y, z, st.id, sdef, qp)) return;
            if (!creative) inv.TakeOne(ui.selected);
        }

        void OnGUI()
        {
            if (GameSession.Paused) return;
            if (ui != null && ui.open) return;
            Layout();
            float cx = Screen.width / 2f, cy = Screen.height / 2f;
            GUI.Box(new Rect(cx - 8, cy - 8, 16, 16), "+");
            if (toastT > 0f)
            {
                var ts = new GUIStyle(GUI.skin.label) { alignment = TextAnchor.MiddleCenter, fontSize = Screen.height / 26 };
                ts.normal.textColor = Color.white;
                GUI.Label(new Rect(0, Screen.height * 0.12f, Screen.width, 50), toast, ts);
            }
            if (progress > 0f) GUI.Box(new Rect(cx - 60, cy + 24, 120f * Mathf.Clamp01(progress), 10), "");
            GUI.Box(rJump, "JUMP"); GUI.Box(rBreak, "BREAK"); GUI.Box(rPlace, "PLACE");
            GUI.Box(rInv, "INV"); GUI.Box(rView, thirdPerson ? "3RD" : "1ST"); GUI.Box(rMode, creative ? "CREATIVE" : "SURVIVAL");
            if (joyId >= 0) { float r = Screen.height * 0.1f; GUI.Box(new Rect(joyStart.x - r, joyStart.y - r, 2 * r, 2 * r), ""); }
        }
    }
}
