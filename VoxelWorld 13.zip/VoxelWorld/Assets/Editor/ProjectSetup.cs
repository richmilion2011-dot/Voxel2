#if UNITY_EDITOR
using System.IO;
using UnityEditor;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;

namespace VoxelWorld.EditorTools
{
    /// Атлас текстур: пиксель-арт без сглаживания и сжатия.
    public class AtlasImport : AssetPostprocessor
    {
        void OnPreprocessTexture()
        {
            if (!assetPath.EndsWith("Resources/VoxelAtlas.png")) return;
            var ti = (TextureImporter)assetImporter;
            ti.filterMode = FilterMode.Point; ti.mipmapEnabled = false; ti.textureCompression = TextureImporterCompression.Uncompressed;
            ti.maxTextureSize = 1024; ti.alphaIsTransparency = true; ti.npotScale = TextureImporterNPOTScale.None; ti.wrapMode = TextureWrapMode.Clamp;
        }
    }

    /// При открытии проекта: создаёт URP-ассет, добавляет шейдеры в Always Included, включает Input = Both, ландшафтную ориентацию.
    [InitializeOnLoad]
    public static class ProjectSetup
    {
        static ProjectSetup() { EditorApplication.delayCall += Run; }

        [MenuItem("Voxel World/Setup Project")]
        public static void Run()
        {
            bool changed = false;
            if (GraphicsSettings.defaultRenderPipeline == null)
            {
                Directory.CreateDirectory("Assets/Settings");
                var rd = ScriptableObject.CreateInstance<UniversalRendererData>();
                AssetDatabase.CreateAsset(rd, "Assets/Settings/VoxelRenderer.asset");
                var asset = UniversalRenderPipelineAsset.Create(rd);
                AssetDatabase.CreateAsset(asset, "Assets/Settings/VoxelURP.asset");
                GraphicsSettings.defaultRenderPipeline = asset; QualitySettings.renderPipeline = asset; changed = true;
            }
            changed |= AddShader("VoxelWorld/VoxelUnlit");
            changed |= AddShader("VoxelWorld/ColorUnlit");
            var all = AssetDatabase.LoadAllAssetsAtPath("ProjectSettings/ProjectSettings.asset");
            if (all.Length > 0)
            {
                var ps = new SerializedObject(all[0]); var ih = ps.FindProperty("activeInputHandler");
                if (ih != null && ih.intValue != 2)
                { ih.intValue = 2; ps.ApplyModifiedProperties(); changed = true; Debug.LogWarning("Voxel World: Active Input Handling = Both. Перезапустите редактор."); }
            }
            PlayerSettings.defaultInterfaceOrientation = UIOrientation.LandscapeLeft;
            if (changed) AssetDatabase.SaveAssets();
        }

        static bool AddShader(string name)
        {
            var sh = Shader.Find(name); var all = AssetDatabase.LoadAllAssetsAtPath("ProjectSettings/GraphicsSettings.asset");
            if (sh == null || all.Length == 0) return false;
            var gs = new SerializedObject(all[0]); var arr = gs.FindProperty("m_AlwaysIncludedShaders");
            for (int i = 0; i < arr.arraySize; i++) if (arr.GetArrayElementAtIndex(i).objectReferenceValue == sh) return false;
            arr.arraySize++; arr.GetArrayElementAtIndex(arr.arraySize - 1).objectReferenceValue = sh; gs.ApplyModifiedProperties();
            return true;
        }
    }

    /// Меню сборки: WebGL (создаёт index.html, Build/, TemplateData/), Android APK, iOS (Xcode-проект, нужен macOS).
    public static class BuildMenu
    {
        const string Scene = "Assets/Scenes/Main.unity";

        [MenuItem("Voxel World/Build WebGL")]
        public static void WebGL()
        {
            PlayerSettings.WebGL.compressionFormat = WebGLCompressionFormat.Disabled;
            Build(BuildTarget.WebGL, "BuildOutput/WebGL");
        }

        [MenuItem("Voxel World/Build Android APK")]
        public static void Android()
        {
            PlayerSettings.SetScriptingBackend(UnityEditor.Build.NamedBuildTarget.Android, ScriptingImplementation.IL2CPP);
            PlayerSettings.Android.targetArchitectures = AndroidArchitecture.ARM64;
            Build(BuildTarget.Android, "BuildOutput/VoxelWorld.apk");
        }

        [MenuItem("Voxel World/Build iOS (Xcode project)")]
        public static void IOS() { Build(BuildTarget.iOS, "BuildOutput/iOS"); }

        static void Build(BuildTarget target, string path)
        {
            var report = BuildPipeline.BuildPlayer(new BuildPlayerOptions
            { scenes = new[] { Scene }, locationPathName = path, target = target, targetGroup = BuildPipeline.GetBuildTargetGroup(target), options = BuildOptions.None });
            Debug.Log("Voxel World build: " + report.summary.result + " -> " + path);
        }
    }
}
#endif
