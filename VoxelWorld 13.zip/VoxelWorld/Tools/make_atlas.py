import random, zlib, struct, math
random.seed(7)
T, N = 16, 32
W = T * N
px = [[(0, 0, 0, 0)] * W for _ in range(W)]
clamp = lambda v: max(0, min(255, v))
def noisy(base, var):
    d = random.randint(-var, var)
    return (clamp(base[0] + d), clamp(base[1] + d), clamp(base[2] + d), 255)
def put(idx, fn):
    ox, oy = (idx % N) * T, (idx // N) * T
    for y in range(T):
        for x in range(T):
            px[oy + y][ox + x] = fn(x, y)
rag = [random.randint(2, 5) for _ in range(T)]
put(0, lambda x, y: noisy((90, 160, 60), 14))                                   # трава сверху
put(1, lambda x, y: noisy((90, 160, 60), 14) if y < rag[x] else noisy((130, 90, 55), 12))  # трава сбоку
put(2, lambda x, y: noisy((130, 90, 55), 12))                                   # земля
put(3, lambda x, y: noisy((95, 95, 95), 10) if random.random() < 0.12 else noisy((125, 125, 125), 12))  # камень
put(4, lambda x, y: noisy((220, 205, 150), 8))                                  # песок
put(5, lambda x, y: noisy((50, 100, 200), 10))                                  # вода
put(6, lambda x, y: noisy((60, 60, 60), 30))                                    # бедрок
def logtop(x, y):
    r = int(math.hypot(x - 7.5, y - 7.5))
    return noisy((170, 130, 80) if r % 2 == 0 else (140, 100, 60), 6) if r < 8 else noisy((95, 65, 35), 8)
put(7, logtop)                                                                  # бревно сверху
cols = [random.randint(-14, 14) for _ in range(T)]
put(8, lambda x, y: noisy((100 + cols[x], 70 + cols[x], 40 + cols[x]), 5))      # кора
put(9, lambda x, y: (0, 0, 0, 0) if random.random() < 0.22 else noisy((50, 125, 40), 22))  # листва
put(10, lambda x, y: (200, 230, 255, 255) if x in (0, 15) or y in (0, 15) else ((255, 255, 255, 255) if (x + y) in (5, 6, 7) and x < 8 else (0, 0, 0, 0)))  # стекло
put(11, lambda x, y: noisy((240, 245, 250), 6))                                 # снег
put(12, lambda x, y: noisy((30, 120, 40), 8) if x not in (0, 15) and x % 4 != 2 else noisy((15, 80, 25), 8))  # кактус бок
put(13, lambda x, y: noisy((40, 135, 50), 8) if 2 <= x <= 13 and 2 <= y <= 13 else noisy((15, 80, 25), 8))   # кактус верх
def ore(col):
    spots = set()
    for _ in range(5):
        sx, sy = random.randint(1, 13), random.randint(1, 13)
        for dx in (0, 1):
            for dy in (0, 1):
                spots.add((sx + dx, sy + dy))
    return lambda x, y: noisy(col, 10) if (x, y) in spots else (noisy((95, 95, 95), 10) if random.random() < 0.12 else noisy((125, 125, 125), 12))
put(14, ore((30, 30, 30)))                                                      # угольная руда
put(15, ore((210, 160, 120)))                                                   # железная руда
def plank(x, y):
    base = noisy((190, 150, 90), 6)
    return (150, 112, 62, 255) if y % 4 == 0 else base
put(16, plank)                                                                  # доски
put(17, lambda x, y: noisy((200, 160, 95), 6) if 2 <= x <= 13 and 2 <= y <= 13 and (x in (2, 7, 8, 13) or y in (2, 7, 8, 13)) is False else noisy((120, 85, 50), 8))  # верстак сверху
put(18, lambda x, y: noisy((150, 105, 60), 8) if 3 <= x <= 12 and 3 <= y <= 12 else plank(x, y))                # верстак бок
cobble = {}
def cob(x, y):
    k = (x // 4, y // 4)
    if k not in cobble: cobble[k] = random.randint(-22, 22)
    edge = x % 4 == 0 or y % 4 == 0
    return noisy((100 + cobble[k] - (25 if edge else 0),) * 3, 6)
put(19, cob)                                                                    # булыжник
def sprite(idx, pix): put(idx, lambda x, y: pix.get((x, y), (0, 0, 0, 0)))
def shade(c, d): return (clamp(c[0] + d), clamp(c[1] + d), clamp(c[2] + d), 255)
BROWN = (120, 85, 45)
def handle(): return {(3 + i, 12 - i): shade(BROWN, random.randint(-8, 8)) for i in range(9)}
def blob(cx, cy, r, col):
    return {(x, y): shade(col, random.randint(-18, 18)) for x in range(16) for y in range(16) if (x - cx) ** 2 + (y - cy) ** 2 <= r * r}
def tool(kind, col):
    p = handle()
    pts = {'pickaxe': [(7, 4), (8, 3), (9, 2), (10, 2), (11, 2), (12, 3), (13, 4), (13, 5), (12, 4)],
           'axe': [(10, 2), (11, 2), (12, 3), (10, 3), (11, 3), (12, 4), (13, 4), (11, 4), (12, 5), (13, 5)],
           'shovel': [(11, 3), (12, 2), (12, 3), (13, 2), (13, 3), (12, 4), (13, 4), (11, 2)]}
    if kind == 'sword':
        p = {(3, 12): shade(BROWN, 0), (4, 11): shade(BROWN, 0), (4, 9): (90, 90, 90, 255), (5, 10): (90, 90, 90, 255), (6, 11): (90, 90, 90, 255)}
        for i in range(7):
            p[(6 + i, 9 - i)] = shade(col, 10); p[(7 + i, 9 - i)] = shade(col, -20)
    else:
        for q in pts[kind]: p[q] = shade(col, random.randint(-14, 14))
    return p
sprite(20, {(4 + i, 11 - i): shade(BROWN, random.randint(-8, 8)) for i in range(9)})  # палка
sprite(21, blob(8, 8, 4, (35, 35, 35)))                                         # уголь
sprite(22, blob(8, 8, 4, (210, 165, 130)))                                      # сырое железо
WD, ST = (175, 135, 80), (145, 145, 145)
for i, (k, c) in zip(range(23, 31), [('pickaxe', WD), ('pickaxe', ST), ('axe', WD), ('axe', ST), ('shovel', WD), ('shovel', ST), ('sword', WD), ('sword', ST)]):
    sprite(i, tool(k, c))
ap = blob(8, 9, 4, (200, 40, 40))
ap[(8, 4)] = (110, 80, 40, 255); ap[(8, 5)] = (110, 80, 40, 255); ap[(9, 4)] = (60, 150, 50, 255)
sprite(31, ap)                                                                  # яблоко
ingot = {(x, y): shade((215, 195, 185), random.randint(-10, 10) + (15 if y == 5 else 0)) for x in range(3, 13) for y in range(5, 11)}
sprite(32, ingot)                                                               # железный слиток
IR = (215, 215, 220)
for i, (k) in zip(range(33, 37), ['pickaxe', 'axe', 'shovel', 'sword']):
    sprite(i, tool(k, IR))
def furn_side(x, y):
    if 4 <= x <= 11 and 6 <= y <= 13: return (255, 150, 30, 255) if y >= 12 else noisy((30, 30, 30), 6)
    return cob(x, y)
put(37, furn_side)                                                              # печь (бок)
put(38, lambda x, y: noisy((85, 85, 85), 8))                                    # печь (верх)
def meat(base, fat):
    p = blob(8, 8, 4, base)
    for q in [(7, 7), (8, 6), (9, 8), (7, 9)]:
        if q in p: p[q] = shade(fat, random.randint(-8, 8))
    return p
sprite(39, meat((200, 70, 80), (240, 200, 200)))                                # сырая говядина
sprite(40, meat((130, 80, 45), (170, 120, 80)))                                 # жареная говядина
sprite(41, meat((110, 130, 70), (80, 100, 50)))                                 # гнилая плоть
put(42, lambda x, y: noisy((120, 80, 40), 8) if 1 <= x <= 14 and 1 <= y <= 14 else noisy((70, 45, 20), 6))        # сундук сверху
def chest_front(x, y):
    if 7 <= x <= 8 and 6 <= y <= 9: return (200, 200, 205, 255)
    if y in (0, 15) or x in (0, 15) or y == 5: return noisy((70, 45, 20), 6)
    return noisy((135, 90, 45), 8)
put(43, chest_front)                                                            # сундук (бок/перед)
def farmtop(n, col):
    pts = {(random.randrange(1, 15), random.randrange(1, 15)) for _ in range(n)}
    return lambda x, y: noisy(col, 20) if (x, y) in pts else (noisy((80, 55, 30), 8) if x % 4 == 1 else noisy((95, 65, 38), 8))
put(44, farmtop(0, (0, 0, 0))); put(45, farmtop(10, (90, 170, 60))); put(46, farmtop(26, (110, 175, 60)))
put(47, farmtop(50, (150, 170, 60))); put(48, farmtop(80, (225, 190, 70)))                 # грядка и стадии пшеницы
put(49, lambda x, y: (235, 235, 235, 255) if y < 5 else noisy((170, 40, 40), 10))        # кровать сверху
put(50, lambda x, y: noisy((170, 40, 40), 10) if y < 9 else plank(x, y))                 # кровать бок
sprite(51, {(x, y): shade((120, 170, 60), random.randint(-10, 10)) for x, y in [(5, 9), (7, 7), (9, 10), (6, 12), (10, 8), (8, 5), (5, 10), (7, 8)]})  # семена
wh = {}
for i in range(3):
    bxx = 4 + i * 4
    for y in range(3, 14): wh[(bxx + (1 if y < 7 else 0), y)] = shade((225, 190, 70), random.randint(-12, 12))
    for y in range(2, 6): wh[(bxx + 1, y)] = shade((235, 200, 80), 0); wh[(bxx + 2, y)] = shade((215, 180, 60), 0)
sprite(52, wh)                                                                              # пшеница
sprite(53, {(x, y): shade((190, 130, 60), random.randint(-15, 15)) for x in range(16) for y in range(16) if ((x - 8) / 6.5) ** 2 + ((y - 9) / 3.8) ** 2 <= 1})  # хлеб
def hoe(col):
    p = handle()
    for q in [(9, 3), (10, 3), (11, 3), (12, 3), (12, 4), (8, 3)]: p[q] = shade(col, random.randint(-14, 14))
    return p
sprite(54, hoe(WD)); sprite(55, hoe(ST)); sprite(56, hoe(IR))
sprite(57, {(x, y): shade((40, 190, 90) if abs(x - 8) + abs(y - 8) > 2 else (150, 240, 170), random.randint(-12, 12)) for x in range(16) for y in range(16) if abs(x - 8) + abs(y - 8) <= 5})  # изумруд

import sys; sys.path.insert(0, '.')
from blocks_table import ROWS, ITEM_ROWS, TOOL_ITEMS, ARMOR_ITEMS, assign
_specs, _rows, _item_t = assign()
def _logtop(c):
    dk = tuple(int(v * .78) for v in c); bk = tuple(int(v * .5) for v in c)
    def f(x, y):
        r = int(math.hypot(x - 7.5, y - 7.5))
        return noisy(bk, 8) if r >= 8 else noisy(dk if r % 2 else c, 8)
    return f
def _logside(c):
    cols = [random.randint(-18, 18) for _ in range(16)]
    return lambda x, y: noisy(tuple(clamp(v + cols[x]) for v in c), 6)
def _bricks(c, mortar):
    def f(x, y):
        off = ((y // 4) % 2) * 4
        return noisy(mortar, 8) if (y % 4 == 3 or (x + off) % 8 == 7) else noisy(c, 14)
    return f
_pal = [(150, 40, 40), (40, 90, 150), (60, 120, 50), (150, 110, 40), (110, 50, 130)]
def _style(sp):
    k = sp[0]
    if k == "n": return lambda x, y: noisy(sp[1], sp[2])
    if k == "ore": return ore(sp[1])
    if k == "log_top": return _logtop(sp[1])
    if k == "log_side": return _logside(sp[1])
    if k == "leaves": return lambda x, y: (0, 0, 0, 0) if random.random() < .2 else noisy(sp[1], 34)
    if k == "planks": return lambda x, y: noisy(tuple(int(v * .78) for v in sp[1]) if y % 4 == 0 else sp[1], 10)
    if k == "bricks": return _bricks(sp[1], (170, 165, 155) if sp[1][0] > 100 else (35, 15, 18))
    if k == "sbricks": return _bricks(sp[1], (85, 85, 85))
    if k == "sandside": return lambda x, y: noisy((200, 185, 130), 8) if 5 <= y <= 7 else noisy((220, 205, 150), 10)
    if k == "books": return lambda x, y: noisy((115, 85, 50), 6) if y % 8 == 0 else noisy(_pal[(x // 2 + (y // 8) * 3) % 5], 14)
    if k == "lava": return lambda x, y: noisy((230, 90, 20), 40) if (x * 3 + y * 5) % 7 else noisy((255, 200, 60), 30)
    if k == "glow": return lambda x, y: noisy((250, 215, 120), 40) if (x + y) % 3 else noisy((255, 240, 170), 30)
    if k == "ice": return lambda x, y: noisy(sp[1], 14)
    if k == "fringe": return lambda x, y: noisy(sp[1], 14) if y < 3 + (x * 5 % 3) else noisy((130, 90, 55), 26)
    raise Exception(k)
for _sp, _i in _specs.items(): put(_i, _style(_sp))
def _gem(c): return {(x, y): shade(c, 28 if x + y < 14 else -12 + random.randint(-6, 6)) for x in range(16) for y in range(16) if abs(x - 8) + abs(y - 8) <= 5}
def _dust(c): return {(x, y): shade(c, random.randint(-25, 15)) for x in range(16) for y in range(16) if (x - 8) ** 2 + (y - 9) ** 2 <= 16 and random.random() < .6}
def _ingot(c): return {(x, y): shade(c, random.randint(-10, 10) + (15 if y == 5 else 0)) for x in range(3, 13) for y in range(5, 11)}
for r in ITEM_ROWS:
    e, d, kind, c, c2, f, sat = r
    sprite(_item_t[e], {"blob": lambda: blob(8, 8, 4, c), "ingot": lambda: _ingot(c), "gem": lambda: _gem(c), "dust": lambda: _dust(c), "meat": lambda: meat(c, c2)}[kind]())
for e, d, k, kind, _tl, tier in TOOL_ITEMS:
    sprite(_item_t[e], hoe((90, 225, 220)) if kind == "hoe" else tool(kind, (90, 225, 220)))
_ARM = {0: ["................", "................", "....########....", "...##########...", "..############..", "..############..", "..###......###..", "..###......###..", "..##........##.."],
        1: [".###........###.", ".####......####.", ".#####....#####.", ".##############.", ".##############.", ".##############.", "..############..", "..############..", "..############..", "..############..", "...##########..."],
        2: ["................", "..############..", "..############..", "..############..", "..###......###..", "..###......###..", "..###......###..", "..###......###..", "..###......###..", "..###......###.."],
        3: ["................"] * 8 + ["..####....####..", "..####....####..", "..####....####..", "..#####..#####..", "..#####..#####.."]}
for e, d, k, slot, pts, dur, tier, col in ARMOR_ITEMS:
    rows_ = _ARM[slot] + ["." * 16] * (16 - len(_ARM[slot]))
    sprite(_item_t[e], {(x, y): shade(col, 22 - x * 2 + random.randint(-6, 6)) for y, row in enumerate(rows_) for x, ch in enumerate(row) if ch == "#"})

from blocks_table2 import build as _build2
_B2 = _build2()
def _style2(sp):
    k = sp[0]
    T0 = (0, 0, 0, 0)
    if k == "torch":
        def f(x, y):
            if x in (7, 8):
                if y in (6, 7): return (255, 210, 70, 255) if y == 6 else (255, 120, 20, 255)
                if y >= 8: return noisy((120, 85, 45), 14)
            return T0
        return f
    if k == "ladder":
        def f(x, y):
            if x in (2, 3, 12, 13): return noisy((125, 90, 50), 14)
            if y in (2, 3, 7, 8, 12, 13) and 3 < x < 12: return noisy((140, 100, 55), 14)
            return T0
        return f
    if k in ("rail_ns", "rail_ew"):
        def f(x, y):
            a, b = (x, y) if k == "rail_ns" else (y, x)
            if a in (3, 4, 11, 12): return noisy((170, 170, 175), 20)
            if b % 4 in (0, 1): return noisy((110, 80, 45), 14)
            return T0
        return f
    if k == "sglass":
        c = sp[1]
        return lambda x, y: noisy(c, 12) if (x in (0, 15) or y in (0, 15) or (x + y) % 2 == 0) else T0
    return _style(sp)
for _sp, _i in _B2["specs"].items(): put(_i, _style2(_sp))
def _bucket(liq):
    p = {}
    for y in range(4, 14):
        w = 6 - (y - 4) // 3
        for x in range(8 - w, 8 + w): p[(x, y)] = shade((200, 200, 205), random.randint(-14, 14))
    if liq:
        for x in range(4, 12):
            for y in (4, 5): p[(x, y)] = shade(liq, random.randint(-12, 12))
    return p
def _cart():
    p = {}
    for x in range(2, 14):
        for y in range(7, 13): p[(x, y)] = shade((150, 150, 158), random.randint(-12, 12) - (20 if y > 11 else 0))
    for q in [(4, 13), (5, 13), (10, 13), (11, 13)]: p[q] = (40, 40, 44, 255)
    return p
for _e, _d, _k in __import__("blocks_table2").ITEMS2:
    sprite(_B2["items"][_e], {"bucket": lambda: _bucket(None), "bucket_w": lambda: _bucket((50, 100, 200)), "bucket_l": lambda: _bucket((240, 100, 20)), "cart": _cart}[_k]())

from blocks_table3 import build as _build3
_B3 = _build3()
def _style3(sp):
    k = sp[0]; T0 = (0, 0, 0, 0)
    def dk(c, f=.7): return tuple(int(v * f) for v in c)
    if k == "stripes": return lambda x, y: noisy(sp[1] if (x // 2) % 2 == 0 else sp[2], 6)
    if k == "spots": return lambda x, y: noisy(sp[2], 14) if random.random() < sp[3] else noisy(sp[1], 12)
    if k == "glowb": return lambda x, y: noisy(sp[1], 18) if (x * 7 + y * 13) % 5 else noisy(sp[2], 18)
    if k == "frame": return lambda x, y: noisy(sp[2], 6) if (x in (0, 15) or y in (0, 15)) else noisy(sp[1], 8)
    if k == "door_lo":
        c = sp[1]; d = dk(c)
        def f(x, y):
            if x in (0, 15) or y in (0, 15): return noisy(d, 6)
            if 3 <= x <= 12 and (3 <= y <= 6 or 9 <= y <= 13) and (x in (3, 12) or y in (3, 6, 9, 13)): return noisy(d, 6)
            if x == 12 and y in (7, 8): return (50, 50, 50, 255)
            return noisy(c, 10)
        return f
    if k == "door_up":
        c = sp[1]; d = dk(c)
        def f(x, y):
            if x in (0, 15) or y in (0, 15): return noisy(d, 6)
            if 3 <= x <= 12 and 3 <= y <= 9:
                return noisy(d, 6) if (x in (7, 8) or y == 6) else T0
            if x == 12 and y in (13, 14): return (50, 50, 50, 255)
            return noisy(c, 10)
        return f
    if k == "idoor_lo":
        def f(x, y):
            if x in (0, 15) or y in (0, 15): return noisy((120, 120, 128), 6)
            if (x, y) in ((2, 2), (13, 2), (2, 13), (13, 13), (2, 8), (13, 8)): return (90, 90, 96, 255)
            if x == 12 and y in (7, 8): return (50, 50, 50, 255)
            return noisy((205, 205, 212), 10)
        return f
    if k == "idoor_up":
        def f(x, y):
            if x in (0, 15) or y in (0, 15): return noisy((120, 120, 128), 6)
            if 5 <= x <= 10 and 3 <= y <= 8: return noisy((120, 120, 128), 6) if (x in (7, 8) or y == 5) else T0
            return noisy((205, 205, 212), 10)
        return f
    if k == "trap":
        c = sp[1]; d = dk(c)
        return lambda x, y: noisy(d, 6) if (x in (0, 1, 14, 15) or y in (0, 1, 14, 15) or x % 5 == 2 or y % 5 == 2) else noisy(c, 10)
    if k == "itrap":
        return lambda x, y: noisy((120, 120, 128), 6) if (x in (0, 15) or y in (0, 15)) else (T0 if (x % 4 in (1, 2) and y % 4 in (1, 2)) else noisy((205, 205, 212), 10))
    if k in ("door_icon", "idoor_icon"):
        c = sp[1] if k == "door_icon" else (205, 205, 212); d = dk(c)
        def f(x, y):
            if 4 <= x <= 11 and 1 <= y <= 14:
                if x in (4, 11) or y in (1, 14) or y == 7: return noisy(d, 6)
                if 6 <= x <= 9 and 3 <= y <= 5: return (150, 200, 230, 255)
                if x == 10 and y in (9, 10): return (50, 50, 50, 255)
                return noisy(c, 10)
            return T0
        return f
    if k == "gate_icon":
        c = sp[1]; d = dk(c)
        def f(x, y):
            if x in (1, 2, 13, 14) and 3 <= y <= 13: return noisy(d, 6)
            if 3 <= x <= 12 and y in (5, 6, 9, 10): return noisy(c, 10)
            return T0
        return f
    return _style2(sp)
for _sp, _i in _B3["specs"].items(): put(_i, _style3(_sp))

_P = _B3["last"]
put(_P, lambda x, y: (0, 0, 0, 0) if random.random() < .2 else noisy((130, 40, 200) if (x * 3 + y * 5) % 7 else (200, 120, 255), 40))   # портал Незера
put(_P + 1, lambda x, y: (210, 255, 255, 255) if random.random() < .06 else noisy((10, 10, 20), 8))                                    # портал Края
sprite(_P + 2, {(x, y): shade((75, 75, 80), random.randint(-14, 14)) for x in range(16) for y in range(16) if abs(x - 8) * 1.0 + abs(y - 9) * 1.4 <= 6})  # кремень
_fs = {(x, 12 - (x - 3)): shade((200, 200, 205), random.randint(-10, 10)) for x in range(3, 11)}
for _q in [(3, 12), (4, 12), (3, 11), (4, 11), (5, 11)]: _fs[_q] = shade((70, 70, 75), random.randint(-10, 10))
sprite(_P + 3, _fs)                                                                                                                     # огниво
sprite(_P + 4, {(x, y): (shade((30, 30, 40), 0) if (x - 8) ** 2 + (y - 8) ** 2 <= 4 else (shade((255, 255, 255), 0) if (x, y) in ((6, 6), (7, 6)) else shade((40, 160, 120), random.randint(-14, 14)))) for x in range(16) for y in range(16) if (x - 8) ** 2 + (y - 8) ** 2 <= 26})  # глаз Края
raw = b"".join(b"\x00" + b"".join(bytes(p) for p in row) for row in px)
def chunk(t, d):
    c = struct.pack(">I", len(d)) + t + d
    return c + struct.pack(">I", zlib.crc32(t + d) & 0xffffffff)
png = b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", W, W, 8, 6, 0, 0, 0)) + chunk(b"IDAT", zlib.compress(raw, 9)) + chunk(b"IEND", b"")
open("../Assets/Resources/VoxelAtlas.png", "wb").write(png)
print("atlas ok", len(png))
