# Таблица новых блоков и предметов: используется генератором атласа (make_atlas.py) и патчером C#.
def n(c, v=24): return ("n", c, v)
ORE = lambda c: ("ore", c)
# (Enum, Display, top, side|None, bottom|None, hardness, tool, tier, cat, flags[t=прозрачный l=жидкость h=скрыт], drop)
ROWS = []
def R(*a): ROWS.append(a)
R("Granite","Granite",n((150,100,85)),None,None,1.5,"Pickaxe",0,"Natural","",None)
R("Diorite","Diorite",n((188,188,190),28),None,None,1.5,"Pickaxe",0,"Natural","",None)
R("Andesite","Andesite",n((135,135,138)),None,None,1.5,"Pickaxe",0,"Natural","",None)
R("Deepslate","Deepslate",n((70,70,80),18),None,None,3.0,"Pickaxe",0,"Natural","",None)
R("Gravel","Gravel",n((132,126,120),44),None,None,0.6,"Shovel",-1,"Natural","",None)
R("Clay","Clay",n((160,166,182),12),None,None,0.6,"Shovel",-1,"Natural","",None)
R("Mud","Mud",n((72,56,46),12),None,None,0.5,"Shovel",-1,"Natural","",None)
R("RedSand","Red Sand",n((190,100,52),14),None,None,0.5,"Shovel",-1,"Natural","",None)
R("Terracotta","Terracotta",n((176,106,76),10),None,None,1.2,"Pickaxe",0,"Building","",None)
R("PackedIce","Packed Ice",n((150,190,240),12),None,None,0.5,"Pickaxe",-1,"Natural","",None)
R("Ice","Ice",("ice",(140,185,250)),None,None,0.5,"Pickaxe",-1,"Natural","t",None)
R("Moss","Moss Block",n((70,122,48),22),None,None,0.1,"None",-1,"Natural","",None)
R("Mycelium","Mycelium",n((120,90,112),16),("fringe",(120,90,112)),n((130,90,55),26),0.6,"Shovel",-1,"Natural","",None)
R("Obsidian","Obsidian",n((22,16,38),10),None,None,50,"Pickaxe",3,"Natural","",None)
for k,d,c,tier,drop in [("GoldOre","Gold Ore",(235,200,60),2,"RawGold"),("CopperOre","Copper Ore",(200,110,70),1,"RawCopper"),
    ("RedstoneOre","Redstone Ore",(200,30,30),2,"Redstone"),("LapisOre","Lapis Lazuli Ore",(40,70,190),1,"Lapis"),
    ("DiamondOre","Diamond Ore",(90,230,225),2,"Diamond"),("EmeraldOre","Emerald Ore",(50,200,100),2,"Emerald"),
    ("QuartzOre","Nether Quartz Ore",(235,230,225),0,"Quartz")]:
    R(k,d,ORE(c),None,None,3.0,"Pickaxe",tier,"Natural","",("item",drop))
WOODS=[("Birch","Birch",(225,225,215),(215,200,140),(110,160,60)),("Spruce","Spruce",(70,50,30),(115,85,50),(45,95,60)),
       ("Jungle","Jungle",(95,70,35),(170,120,85),(40,140,30)),("Acacia","Acacia",(120,110,100),(185,100,55),(95,140,40)),
       ("DarkOak","Dark Oak",(50,38,22),(65,45,25),(35,95,35))]
for k,d,bark,pl,lf in WOODS:
    R(k+"Log",d+" Log",("log_top",pl),("log_side",bark),("log_top",pl),2.0,"Axe",-1,"Natural","",None)
    R(k+"Planks",d+" Planks",("planks",pl),None,None,2.0,"Axe",-1,"Building","",None)
    R(k+"Leaves",d+" Leaves",("leaves",lf),None,None,0.2,"None",-1,"Natural","t",("none",))
R("Bricks","Bricks",("bricks",(160,70,55)),None,None,2.0,"Pickaxe",0,"Building","",None)
R("StoneBricks","Stone Bricks",("sbricks",(125,125,125)),None,None,1.5,"Pickaxe",0,"Building","",None)
R("Sandstone","Sandstone",n((220,205,150),10),("sandside",),n((220,205,150),10),0.8,"Pickaxe",0,"Building","",None)
for k,d,c in [("White","White",(235,235,235)),("Red","Red",(170,40,40)),("Orange","Orange",(225,125,30)),("Yellow","Yellow",(235,200,40)),
              ("Lime","Lime",(110,190,40)),("Blue","Blue",(50,70,170)),("Purple","Purple",(120,50,160)),("Black","Black",(28,28,32))]:
    R(k+"Wool",d+" Wool",n(c,8),None,None,0.8,"None",-1,"Building","",None)
R("Bookshelf","Bookshelf",("planks",(190,150,90)),("books",),("planks",(190,150,90)),1.5,"Axe",-1,"Functional","",None)
for k,d,c,tier in [("IronBlock","Block of Iron",(215,215,220),1),("GoldBlock","Block of Gold",(240,205,60),2),("DiamondBlock","Block of Diamond",(90,225,220),2),("CoalBlock","Block of Coal",(28,28,30),0)]:
    R(k,d,n(c,8),None,None,5.0,"Pickaxe",tier,"Building","",None)
R("Netherrack","Netherrack",n((110,50,50),24),None,None,0.4,"Pickaxe",0,"Natural","",None)
R("SoulSand","Soul Sand",n((85,68,55),14),None,None,0.5,"Shovel",-1,"Natural","",None)
R("NetherBricks","Nether Bricks",("bricks",(60,25,30)),None,None,2.0,"Pickaxe",0,"Building","",None)
R("Glowstone","Glowstone",("glow",),None,None,0.3,"None",-1,"Building","",None)
R("EndStone","End Stone",n((220,220,160),12),None,None,3.0,"Pickaxe",0,"Natural","",None)
R("Lava","Lava",("lava",),None,None,100,"None",-1,"Natural","lth",("none",))

# предметы: (Enum, Display, kind, color, color2, food, sat)
ITEM_ROWS=[("RawGold","Raw Gold","blob",(205,185,110),None,0,0),("GoldIngot","Gold Ingot","ingot",(240,205,60),None,0,0),
 ("RawCopper","Raw Copper","blob",(200,120,80),None,0,0),("CopperIngot","Copper Ingot","ingot",(210,125,85),None,0,0),
 ("Diamond","Diamond","gem",(90,230,225),None,0,0),("Redstone","Redstone","dust",(210,30,30),None,0,0),
 ("Lapis","Lapis Lazuli","blob",(45,75,200),None,0,0),("Quartz","Nether Quartz","gem",(235,230,225),None,0,0),
 ("Gunpowder","Gunpowder","dust",(110,110,110),None,0,0),
 ("RawPork","Raw Porkchop","meat",(230,140,150),(250,220,220),3,1.8),("CookedPork","Cooked Porkchop","meat",(160,100,70),(190,140,100),8,12.8),
 ("RawChicken","Raw Chicken","meat",(235,200,170),(250,235,215),2,1.2),("CookedChicken","Cooked Chicken","meat",(200,150,80),(225,185,120),6,7.2)]
TOOL_ITEMS=[("Diamond"+a,"Diamond "+a,"tool",k,t,3) for a,k,t in [("Pickaxe","pickaxe","Pickaxe"),("Axe","axe","Axe"),("Shovel","shovel","Shovel"),("Sword","sword","Sword"),("Hoe","hoe","Hoe")]]
PARTS=["Helmet","Chestplate","Leggings","Boots"]
ARMOR_ITEMS=[]
for mat,col,pts,dur,tier in [("Iron",(205,205,212),[2,6,5,2],[165,240,225,195],2),("Diamond",(90,225,220),[3,8,6,3],[363,528,495,429],3)]:
    for i,p in enumerate(PARTS): ARMOR_ITEMS.append((mat+p,mat+" "+p,"armor",i,pts[i],dur[i],tier,col))

def assign():
    specs={}; nxt=[58]
    def t(s):
        if s not in specs: specs[s]=nxt[0]; nxt[0]+=1
        return specs[s]
    rows=[]
    for r in ROWS: rows.append((t(r[2]),t(r[3] or r[2]),t(r[4] or r[2])))
    item_t={}
    for r in ITEM_ROWS+TOOL_ITEMS+ARMOR_ITEMS: item_t[r[0]]=nxt[0]; nxt[0]+=1
    return specs,rows,item_t
