# Этап 2 блоков: цветные блоки, формы (факел, лестница, рельсы, заборы, панели, плиты, ступени), предметы (вёдра, вагонетка).
from blocks_table import assign, ROWS as ROWS1, n
COLORS=[("White","White",(235,235,235)),("Orange","Orange",(225,125,30)),("Magenta","Magenta",(180,60,170)),("LightBlue","Light Blue",(85,160,215)),
 ("Yellow","Yellow",(235,200,40)),("Lime","Lime",(110,190,40)),("Pink","Pink",(235,140,165)),("Gray","Gray",(70,72,78)),
 ("LightGray","Light Gray",(155,155,150)),("Cyan","Cyan",(25,135,145)),("Purple","Purple",(120,50,160)),("Blue","Blue",(50,70,170)),
 ("Brown","Brown",(110,70,40)),("Green","Green",(80,110,40)),("Red","Red",(170,40,40)),("Black","Black",(28,28,32))]
NEWWOOL=[c for c in COLORS if c[0] in ("Magenta","LightBlue","Pink","Gray","LightGray","Cyan","Brown","Green")]
SLABPAR=[("Oak","Oak","Planks"),("Spruce","Spruce","SprucePlanks"),("Birch","Birch","BirchPlanks"),("Jungle","Jungle","JunglePlanks"),
 ("Acacia","Acacia","AcaciaPlanks"),("DarkOak","Dark Oak","DarkOakPlanks"),("Cobble","Cobblestone","Cobblestone"),("Stone","Stone","Stone"),
 ("StoneBrick","Stone Brick","StoneBricks"),("Brick","Brick","Bricks"),("Sandstone","Sandstone","Sandstone"),("NetherBrick","Nether Brick","NetherBricks")]
FENCEPAR=[p for p in SLABPAR if p[0] in ("Oak","Spruce","Birch","Jungle","Acacia","DarkOak","NetherBrick")]
ITEMS2=[("Bucket","Bucket","bucket"),("WaterBucket","Water Bucket","bucket_w"),("LavaBucket","Lava Bucket","bucket_l"),("Minecart","Minecart","cart")]

def build():
    specs1,rows1,item1=assign()
    PT={r[0]:rows1[i] for i,r in enumerate(ROWS1)}
    PT.update({"Planks":(16,16,16),"Cobblestone":(19,19,19),"Stone":(3,3,3),"Glass":(11,11,11)})
    nxt=[max(list(specs1.values())+list(item1.values()))+1]; new={}
    def t(s):
        if s in specs1: return specs1[s]
        if s not in new: new[s]=nxt[0]; nxt[0]+=1
        return new[s]
    cubes=[]
    for k,d,c in NEWWOOL: cubes.append((k+"Wool",d+" Wool",(t(n(c,8)),)*3,0.8,"None",-1,"Building","",None))
    for k,d,c in COLORS: cubes.append((k+"Concrete",d+" Concrete",(t(n(c,5)),)*3,1.8,"Pickaxe",0,"Building","",None))
    for k,d,c in COLORS: cubes.append((k+"Terracotta",d+" Terracotta",(t(n(tuple(int(v*.8) for v in c),10)),)*3,1.2,"Pickaxe",0,"Building","",None))
    for k,d,c in COLORS: cubes.append((k+"StainedGlass",d+" Stained Glass",(t(("sglass",c)),)*3,0.3,"None",-1,"Building","t",("none",)))
    sh=[]  # (enum,disp,shape,(tt,ts,tb),hard,tool,tier,cat,solid,light,facing,full,drop,hidden)
    tt_=t(("torch",)); lad=t(("ladder",)); rn=t(("rail_ns",)); re_=t(("rail_ew",))
    sh.append(("Torch","Torch","Torch",(tt_,)*3,0.0,"None",-1,"Functional",False,9,0,None,None,False))
    sh.append(("Ladder","Ladder","Ladder",(lad,)*3,0.4,"Axe",-1,"Functional",False,0,0,None,None,False))
    sh.append(("Rail","Rail","Rail",(rn,re_,rn),0.7,"Pickaxe",-1,"Functional",False,0,0,None,None,False))
    sh.append(("GlassPane","Glass Pane","Pane",PT["Glass"],0.3,"None",-1,"Building",True,0,0,None,None,False))
    for k,d,c in COLORS:
        g=t(("sglass",c)); sh.append((k+"StainedGlassPane",d+" Stained Glass Pane","Pane",(g,g,g),0.3,"None",-1,"Building",True,0,0,None,None,False))
    for k,d,par in SLABPAR:
        tool="Axe" if "Planks" in par else "Pickaxe"; tier=-1 if tool=="Axe" else 0
        sh.append((k+"Slab",d+" Slab","Slab",PT[par],2.0,tool,tier,"Building",True,0,0,par,None,False))
        for f in range(4):
            sh.append(("%sStairs%d"%(k,f),d+" Stairs","Stair",PT[par],2.0,tool,tier,"Building",True,0,f,None,(k+"Stairs0") if f else None,f>0))
    for k,d,par in FENCEPAR:
        tool="Pickaxe" if "Nether" in k else "Axe"
        sh.append((k+"Fence",d+" Fence","Fence",PT[par],2.0,tool,0 if tool=="Pickaxe" else -1,"Building",True,0,0,None,None,False))
    items={}
    for e,d,kind in ITEMS2: items[e]=nxt[0]; nxt[0]+=1
    assert nxt[0]<=1024, nxt[0]
    return dict(specs=new,cubes=cubes,shaped=sh,items=items,last=nxt[0])
