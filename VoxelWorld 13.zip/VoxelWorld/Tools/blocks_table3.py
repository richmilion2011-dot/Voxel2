# Этап 3: двери, люки, калитки, стены и ещё ~85 декоративных блоков (с нормальными текстурами).
from blocks_table import assign, ROWS as ROWS1, n
import blocks_table2 as T2
PLANKC={"Oak":(190,150,90),"Spruce":(115,85,50),"Birch":(215,200,140),"Jungle":(170,120,85),"Acacia":(185,100,55),"DarkOak":(65,45,25)}
DISP={"Oak":"Oak","Spruce":"Spruce","Birch":"Birch","Jungle":"Jungle","Acacia":"Acacia","DarkOak":"Dark Oak","Iron":"Iron"}

def build():
    b2=T2.build(); specs1,rows1,item1=assign()
    PT={r[0]:rows1[i] for i,r in enumerate(ROWS1)}
    PT.update({"Planks":(16,16,16),"Cobblestone":(19,19,19),"Stone":(3,3,3),"Glass":(11,11,11)})
    known=dict(specs1); known.update(b2['specs'])
    nxt=[b2['last']]; new={}
    def t(s):
        if s in known: return known[s]
        if s not in new: new[s]=nxt[0]; nxt[0]+=1
        return new[s]
    cubes=[]; emissive=[]
    def C(e,d,top,side=None,bot=None,hard=1.5,tool="Pickaxe",tier=0,cat="Building",flags="",drop=None,light=0,emis=False):
        tt=t(top); ts=t(side) if side else tt; tb=t(bot) if bot else tt
        cubes.append((e,d,(tt,ts,tb),hard,tool,tier,cat,flags,drop,light))
        if emis: emissive.append(tt)
    # --- дерево ---
    for k,d,bark,pl,lf in [("Mangrove","Mangrove",(80,50,40),(117,54,48),(60,140,60)),("Cherry","Cherry",(60,40,45),(228,176,170),(235,150,190)),
                           ("Crimson","Crimson",(110,40,70),(110,40,70),None),("Warped","Warped",(30,100,105),(40,110,110),None)]:
        C(k+("Log" if lf else "Stem"),d+(" Log" if lf else " Stem"),("log_top",pl),("log_side",bark),("log_top",pl),2.0,"Axe",-1,"Natural")
        C(k+"Planks",d+" Planks",("planks",pl),hard=2.0,tool="Axe",tier=-1)
        if lf: C(k+"Leaves",d+" Leaves",("leaves",lf),hard=0.2,tool="None",tier=-1,cat="Natural",flags="t",drop=("none",))
    C("BambooBlock","Block of Bamboo",("log_top",(200,180,90)),("log_side",(150,170,60)),("log_top",(200,180,90)),2.0,"Axe",-1,"Natural")
    C("BambooPlanks","Bamboo Planks",("planks",(200,180,90)),hard=2.0,tool="Axe",tier=-1)
    # --- камень ---
    C("PolishedGranite","Polished Granite",("frame",(160,110,95),(135,90,78)))
    C("PolishedDiorite","Polished Diorite",("frame",(200,200,202),(170,170,172)))
    C("PolishedAndesite","Polished Andesite",("frame",(140,140,144),(115,115,119)))
    C("SmoothStone","Smooth Stone",n((160,160,160),6))
    C("MossyCobblestone","Mossy Cobblestone",("spots",(100,100,100),(70,130,50),0.3),hard=2.0)
    C("MossyStoneBricks","Mossy Stone Bricks",("spots",(115,115,115),(70,130,50),0.3))
    C("CrackedStoneBricks","Cracked Stone Bricks",("spots",(120,120,120),(70,70,70),0.15))
    C("ChiseledStoneBricks","Chiseled Stone Bricks",("frame",(130,130,130),(90,90,90)))
    C("Calcite","Calcite",n((225,225,215),8),cat="Natural",hard=0.75)
    C("Tuff","Tuff",n((110,110,100),16),cat="Natural",hard=1.5)
    C("Basalt","Basalt",n((70,70,75),8),("stripes",(70,70,75),(55,55,60)),n((70,70,75),8),cat="Natural",hard=1.25)
    C("Blackstone","Blackstone",n((45,40,45),10),cat="Natural",hard=1.5)
    C("PolishedBlackstone","Polished Blackstone",("frame",(55,50,58),(35,30,38)),hard=2.0)
    C("CryingObsidian","Crying Obsidian",("spots",(30,10,60),(150,60,230),0.15),cat="Natural",hard=50,tier=3,light=10)
    C("DripstoneBlock","Dripstone Block",n((130,100,80),14),cat="Natural",hard=1.5)
    C("CopperBlock","Block of Copper",n((200,110,70),10),hard=3.0,tier=1)
    C("ExposedCopper","Exposed Copper",n((160,125,100),10),hard=3.0,tier=1)
    C("WeatheredCopper","Weathered Copper",n((100,150,120),10),hard=3.0,tier=1)
    C("OxidizedCopper","Oxidized Copper",n((80,170,150),10),hard=3.0,tier=1)
    C("CutCopper","Cut Copper",("frame",(200,115,75),(165,90,55)),hard=3.0,tier=1)
    C("QuartzBlock","Block of Quartz",n((235,230,225),5),hard=0.8)
    C("QuartzPillar","Quartz Pillar",n((235,230,225),5),("stripes",(235,230,225),(215,210,205)),n((235,230,225),5),hard=0.8)
    C("ChiseledQuartz","Chiseled Quartz Block",("frame",(235,230,225),(190,185,180)),hard=0.8)
    C("Purpur","Purpur Block",n((170,120,170),8))
    C("PurpurPillar","Purpur Pillar",n((170,120,170),8),("stripes",(170,120,170),(150,100,150)),n((170,120,170),8))
    C("Prismarine","Prismarine",n((90,160,150),14))
    C("PrismarineBricks","Prismarine Bricks",("bricks",(80,150,140)))
    C("DarkPrismarine","Dark Prismarine",n((50,90,80),10))
    C("SeaLantern","Sea Lantern",("glowb",(200,230,225),(150,200,200)),hard=0.3,tool="None",tier=-1,light=14,emis=True)
    C("RedSandstone","Red Sandstone",n((190,100,52),10),("spots",(190,100,52),(165,80,40),0.12),n((190,100,52),10),cat="Natural",hard=0.8)
    C("BlueIce","Blue Ice",n((60,120,230),10),cat="Natural",hard=2.8)
    C("CoarseDirt","Coarse Dirt",("spots",(110,75,45),(130,125,120),0.25),cat="Natural",hard=0.5,tool="Shovel",tier=-1)
    C("Podzol","Podzol",n((90,60,30),14),("fringe",(90,60,30)),n((130,90,55),26),cat="Natural",hard=0.5,tool="Shovel",tier=-1)
    C("PackedMud","Packed Mud",n((130,100,70),10),hard=1.0)
    C("MudBricks","Mud Bricks",("bricks",(140,110,90)),hard=1.5)
    C("SoulSoil","Soul Soil",n((75,60,50),12),cat="Natural",hard=0.5,tool="Shovel",tier=-1)
    C("NetherWartBlock","Nether Wart Block",n((170,30,30),14),cat="Natural",hard=1.0,tool="None",tier=-1)
    C("WarpedWartBlock","Warped Wart Block",n((20,120,110),14),cat="Natural",hard=1.0,tool="None",tier=-1)
    C("RedNetherBricks","Red Nether Bricks",("bricks",(120,20,20)),hard=2.0)
    C("AncientDebris","Ancient Debris",n((100,70,60),10),("spots",(100,70,60),(150,110,90),0.2),n((100,70,60),10),cat="Natural",hard=30,tier=3)
    C("EndStoneBricks","End Stone Bricks",("sbricks",(220,220,160)),hard=3.0)
    C("Amethyst","Block of Amethyst",n((140,100,190),12),hard=1.5)
    # --- хранилища ---
    for k,d,c in [("LapisBlock","Block of Lapis Lazuli",(30,60,160)),("RedstoneBlock","Block of Redstone",(170,20,20)),("EmeraldBlock","Block of Emerald",(40,190,90))]:
        C(k,d,n(c,8),hard=5.0,tier=2 if k=="EmeraldBlock" else 0)
    # --- фермерские / светящиеся ---
    C("HayBale","Hay Bale",("log_top",(200,170,60)),("stripes",(200,170,60),(170,140,40)),("log_top",(200,170,60)),0.5,"None",-1,"Natural")
    C("Melon","Melon",n((90,140,40),10),("stripes",(100,160,50),(60,110,30)),n((90,140,40),10),1.0,"Axe",-1,"Natural")
    C("Pumpkin","Pumpkin",("log_top",(220,130,20)),("stripes",(225,135,25),(195,105,10)),("log_top",(220,130,20)),1.0,"Axe",-1,"Natural")
    C("JackOLantern","Jack o'Lantern",("glowb",(230,150,30),(180,90,10)),hard=1.0,tool="Axe",tier=-1,light=12,emis=True)
    C("Sponge","Sponge",("spots",(220,210,90),(150,140,50),0.25),hard=0.6,tool="None",tier=-1)
    C("BoneBlock","Bone Block",("log_top",(225,220,200)),("stripes",(225,220,200),(200,195,175)),("log_top",(225,220,200)),2.0)
    C("MagmaBlock","Magma Block",("glowb",(160,50,10),(240,110,20)),cat="Natural",hard=0.5,light=3,emis=True)
    C("Shroomlight","Shroomlight",("glowb",(240,180,100),(200,120,50)),cat="Natural",hard=1.0,tool="None",tier=-1,light=15,emis=True)
    # --- двери, люки, калитки ---
    doors=[]; traps=[]; gates=[]
    for k in ["Oak","Spruce","Birch","Jungle","Acacia","DarkOak","Iron"]:
        if k=="Iron": lo=t(("idoor_lo",)); up=t(("idoor_up",)); ic=t(("idoor_icon",)); tr=t(("itrap",)); hard=5.0; tool="Pickaxe"; tier=0
        else: c=PLANKC[k]; lo=t(("door_lo",c)); up=t(("door_up",c)); ic=t(("door_icon",c)); tr=t(("trap",c)); hard=3.0; tool="Axe"; tier=-1
        doors.append((k+"Door",DISP[k]+" Door",up,lo,ic,hard,tool,tier))
        traps.append((k+"Trapdoor",DISP[k]+" Trapdoor",tr,hard,tool,tier))
        if k!="Iron":
            pl=PT["Planks"][0] if k=="Oak" else PT[k+"Planks"][0]
            gates.append((k+"FenceGate",DISP[k]+" Fence Gate",pl,t(("gate_icon",PLANKC[k])),2.0,"Axe",-1))
    walls=[]
    for k,d,tile in [("CobbleWall","Cobblestone Wall",PT["Cobblestone"][0]),("MossyCobbleWall","Mossy Cobblestone Wall",None),("StoneBrickWall","Stone Brick Wall",PT["StoneBricks"][0]),
                     ("BrickWall","Brick Wall",PT["Bricks"][0]),("SandstoneWall","Sandstone Wall",PT["Sandstone"][0]),("NetherBrickWall","Nether Brick Wall",PT["NetherBricks"][0])]:
        if tile is None: tile=t(("spots",(100,100,100),(70,130,50),0.3))
        walls.append((k,d,tile))
    assert nxt[0]<=1024
    return dict(specs=new,cubes=cubes,emissive=emissive,doors=doors,traps=traps,gates=gates,walls=walls,last=nxt[0])
